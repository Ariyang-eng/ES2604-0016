"""M0 Sanity: run a uniform-random policy for one episode and dump JSON results.

Usage:
    python scripts/m0_sanity/run_random_policy.py \\
        --config configs/m0_sanity.yaml --seed 42 --out results/m0/sanity_seed42.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

# Add src/ to path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from reimbursesim import ReimburseSimEnv, load_scenario  # noqa: E402


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="Scenario YAML path")
    p.add_argument("--seed", type=int, default=42)
    p.add_argument("--out", required=True, help="Output JSON path")
    p.add_argument("--render", action="store_true")
    return p.parse_args()


def main() -> None:
    args = parse_args()
    config = load_scenario(args.config)
    env = ReimburseSimEnv(config)
    rng = np.random.default_rng(args.seed)

    t0 = time.time()
    obs, info = env.reset(seed=args.seed)
    assert obs.shape == (24,), f"Bad obs shape: {obs.shape}"
    assert obs.dtype == np.float32, f"Bad obs dtype: {obs.dtype}"
    assert (obs >= 0).all() and (obs <= 1).all(), "obs out of [0,1]"

    rewards = []
    daily_summaries = []
    for step in range(config.episode_length):
        action = rng.uniform(0.0, 1.0, size=6).astype(np.float32)
        obs, reward, term, trunc, info = env.step(action)
        rewards.append(float(reward))
        daily_summaries.append({
            "day": int(info["day"]),
            "claims_submitted": info["metrics"]["claims_submitted"],
            "claims_resolved": info["metrics"]["claims_resolved"],
            "leakage_rate": info["metrics"]["leakage_rate"],
            "audit_count": info["metrics"]["audit_count"],
            "appeals": info["metrics"]["appeals"],
            "sla_violations": info["metrics"]["sla_violations"],
            "avg_cycle_time": info["metrics"]["avg_cycle_time"],
            "reward": float(reward),
        })
        if args.render:
            env.render()
        # Sanity asserts during loop
        assert obs.shape == (24,)
        assert (obs >= 0).all() and (obs <= 1).all(), f"obs out of [0,1] at day {step}"
        if term:
            break

    wall = time.time() - t0
    summary = info.get("episode_summary", {})

    out = {
        "scenario": config.scenario_name,
        "policy": "random_uniform",
        "seed": args.seed,
        "episode_length": config.episode_length,
        "wall_time_seconds": round(wall, 3),
        "total_reward": float(sum(rewards)),
        "mean_daily_reward": float(np.mean(rewards)),
        "std_daily_reward": float(np.std(rewards)),
        "min_daily_reward": float(np.min(rewards)),
        "max_daily_reward": float(np.max(rewards)),
        "episode_summary": summary,
        "daily_summaries": daily_summaries,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"[M0 sanity OK] wrote {out_path}")
    print(f"  total_claims    = {summary.get('total_claims')}")
    print(f"  total_fraud     = {summary.get('total_fraud_claims')} (amount={summary.get('total_fraud_amount'):.0f})")
    print(f"  leakage_rate    = {summary.get('leakage_rate'):.3f}")
    print(f"  fraud_catch_rate= {summary.get('fraud_catch_rate'):.3f}")
    print(f"  mean_cycle_time = {summary.get('mean_cycle_time'):.2f}")
    print(f"  appeal_rate     = {summary.get('appeal_rate'):.3f}")
    print(f"  total_reward    = {summary.get('total_reward'):.3f}")
    print(f"  wall_time       = {wall:.2f}s")


if __name__ == "__main__":
    main()
