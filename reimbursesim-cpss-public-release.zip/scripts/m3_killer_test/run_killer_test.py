"""M3 killer test: SAC-Full vs SAC-NoSocial on the adaptive environment.

Tests Claim C1 by comparing SAC with and without social observation features.
If NoSocial performs similarly to Full, the CPSS/social-awareness claim fails.

Usage:
    python scripts/m3_killer_test/run_killer_test.py \
        --config configs/default_quarter.yaml \
        --seed 0 --timesteps 50000 \
        --out results/m3/killer_seed0.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from stable_baselines3 import SAC

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.wrappers import NoSocialObservationWrapper


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--timesteps", type=int, default=50000)
    p.add_argument("--eval-episodes", type=int, default=5)
    p.add_argument("--out", required=True)
    p.add_argument("--skip-full", action="store_true", help="Only run NoSocial")
    p.add_argument("--skip-nosocial", action="store_true", help="Only run Full SAC")
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def make_env(config_path: str, seed: int, no_social: bool = False):
    config = load_scenario(config_path)
    env = ReimburseSimEnv(config)
    if no_social:
        env = NoSocialObservationWrapper(env)
    env.reset(seed=seed)
    return env


def evaluate(model, env_factory, n_episodes: int, eval_seeds: list[int]) -> list[dict]:
    eps = []
    for s in eval_seeds[:n_episodes]:
        env = env_factory(s)
        obs, _ = env.reset(seed=s)
        rewards = []
        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s_summary = info.get("episode_summary", {})
        s_summary["seed"] = s
        s_summary["total_reward"] = float(sum(rewards))
        s_summary["mean_reward"] = float(np.mean(rewards))
        eps.append(s_summary)
    return eps


def build_metrics(per_episode: list[dict]) -> dict:
    def agg(key):
        vals = [e.get(key, 0.0) for e in per_episode]
        return {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
            "values": [float(v) for v in vals],
        }

    return {
        key: agg(key)
        for key in [
            "total_reward", "leakage_rate", "mean_cycle_time",
            "cvar_leakage_5pct", "fraud_catch_rate",
            "sla_violation_rate", "appeal_rate", "false_alarm_rate", "audit_count",
        ]
    }


def train_and_eval(
    config_path: str,
    seed: int,
    timesteps: int,
    eval_episodes: int,
    eval_seeds: list[int],
    no_social: bool,
    quiet: bool,
) -> dict:
    variant = "NoSocial" if no_social else "Full"
    train_env = make_env(config_path, seed, no_social=no_social)
    print(f"[SAC-{variant}] training seed={seed}  timesteps={timesteps}")

    t0 = time.time()
    model = SAC(
        "MlpPolicy", train_env,
        learning_rate=3e-4, buffer_size=100000, learning_starts=1000,
        batch_size=256, gamma=0.99, tau=0.005, ent_coef="auto",
        verbose=0 if quiet else 1, seed=seed, device="auto",
    )
    model.learn(total_timesteps=timesteps, progress_bar=False)
    train_wall = time.time() - t0

    per_episode = evaluate(
        model,
        lambda s: make_env(config_path, s, no_social=no_social),
        eval_episodes, eval_seeds,
    )

    result = {
        "variant": variant,
        "train_seed": seed,
        "timesteps": timesteps,
        "train_wall_seconds": round(train_wall, 1),
        "eval_seeds": eval_seeds,
        "metrics": build_metrics(per_episode),
        "per_episode": per_episode,
    }

    m = result["metrics"]
    print(
        f"[SAC-{variant} seed={seed}] reward={m['total_reward']['mean']:.2f}±"
        f"{m['total_reward']['std']:.2f}  "
        f"leak={m['leakage_rate']['mean']:.3f}  "
        f"catch={m['fraud_catch_rate']['mean']:.3f}  "
        f"cvar={m['cvar_leakage_5pct']['mean']:.3f}  "
        f"train={train_wall:.1f}s"
    )
    return result


def main() -> None:
    args = parse_args()
    eval_seeds = [3000 + args.seed * 10 + i for i in range(args.eval_episodes)]

    both = not args.skip_full and not args.skip_nosocial
    results = {}
    total_wall = 0.0
    t_start = time.time()

    if both or not args.skip_full:
        r_full = train_and_eval(
            args.config, args.seed, args.timesteps,
            args.eval_episodes, eval_seeds, no_social=False, quiet=args.quiet,
        )
        results["sac_full"] = r_full

    if both or not args.skip_nosocial:
        r_nosocial = train_and_eval(
            args.config, args.seed, args.timesteps,
            args.eval_episodes, eval_seeds, no_social=True, quiet=args.quiet,
        )
        results["sac_nosocial"] = r_nosocial

    total_wall = time.time() - t_start

    # Comparison summary
    if "sac_full" in results and "sac_nosocial" in results:
        full_m = results["sac_full"]["metrics"]
        nos_m = results["sac_nosocial"]["metrics"]
        delta_leak = nos_m["leakage_rate"]["mean"] - full_m["leakage_rate"]["mean"]
        delta_catch = full_m["fraud_catch_rate"]["mean"] - nos_m["fraud_catch_rate"]["mean"]
        print(
            f"\n[KILLER TEST] Δleak(NoSocial-Full)={delta_leak:+.4f}  "
            f"Δcatch(Full-NoSocial)={delta_catch:+.4f}"
        )
        if delta_leak < 0.02 and delta_catch < 0.02:
            print("  WARNING: NoSocial nearly matches Full → CPSS claim may be weak!")

    out = {
        "scenario": load_scenario(args.config).scenario_name,
        "seed": args.seed,
        "timesteps": args.timesteps,
        "total_wall_seconds": round(total_wall, 1),
        "results": results,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"  wrote {out_path}")


if __name__ == "__main__":
    main()
