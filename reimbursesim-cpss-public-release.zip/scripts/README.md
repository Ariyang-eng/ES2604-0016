# Scripts

The scripts are organized by experiment milestone:

- `m0_sanity/`: simulator smoke tests.
- `m1_baseline/`: rule baselines and DQN baseline evaluation.
- `m2_continuous_rl/`: PPO/DDPG/TD3/SAC pilot training.
- `m3_killer_test/`: social-observation ablation checks.
- `m4_stress/`: stress-scenario evaluation and corrected stress rerun.
- `m5_ablation/`: DQN/SAC/SAC-NoSocial/SAC-NoRisk ablation study.
- `validation/`: simulator distributional validation.
- `m7_figures/`: paper figure generation.

Files whose names start with `_` are local helper scripts and are ignored by Git unless explicitly
added. Remote helper scripts require environment variables for credentials.
