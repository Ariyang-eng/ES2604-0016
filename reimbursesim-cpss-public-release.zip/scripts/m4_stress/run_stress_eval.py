"""M4: Evaluate policies under 5 stress scenarios.

Compares fixed_rule, risk_threshold, SAC, SAC-NoRisk, SAC-NoSocial, DQN
across fraud_burst, month_end, reviewer_shortage, policy_shock, budget_shock.

Usage:
    python scripts/m4_stress/run_stress_eval.py --out results/m4_stress/
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

from stable_baselines3 import SAC, DQN

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.models import ACTION_KEYS, ACTION_RANGES, DEFAULT_POLICY
from reimbursesim.wrappers import (
    DiscretizedActionWrapper,
    NoRiskRewardWrapper,
    NoSocialObservationWrapper,
)

def _cfg(name):
    return str(PROJECT / "configs" / name)

STRESS_CONFIGS = {
    "fraud_burst": _cfg("stress_fraud_burst.yaml"),
    "month_end": _cfg("stress_month_end.yaml"),
    "reviewer_shortage": _cfg("stress_reviewer_shortage.yaml"),
    "policy_shock": _cfg("stress_policy_shock.yaml"),
    "budget_shock": _cfg("stress_budget_shock.yaml"),
}

FIXED_RULE_KNOBS = {
    "random_audit_ratio": 0.15,
    "targeted_audit_weight": 0.5,
    "risk_threshold": 0.6,
    "auto_approval_prob": 0.3,
    "escalation_intensity": 0.2,
    "reviewer_load_temperature": 1.0,
}

METRIC_KEYS = [
    "total_reward", "leakage_rate", "fraud_catch_rate",
    "mean_cycle_time", "cvar_leakage_5pct", "appeal_rate",
    "false_alarm_rate", "sla_violation_rate", "audit_count",
]


def encode_action(knobs: dict[str, float]) -> np.ndarray:
    a = np.zeros(6, dtype=np.float32)
    for i, key in enumerate(ACTION_KEYS):
        lo, hi = ACTION_RANGES[key]
        a[i] = float(np.clip((knobs[key] - lo) / (hi - lo), 0.0, 1.0))
    return a


def eval_fixed_rule(config_path: str, seeds: list[int]) -> list[dict]:
    results = []
    for seed in seeds:
        config = load_scenario(config_path)
        env = ReimburseSimEnv(config)
        obs, _ = env.reset(seed=seed)
        rewards = []
        for _ in range(config.episode_length):
            action = encode_action(FIXED_RULE_KNOBS)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


def eval_risk_threshold(config_path: str, seeds: list[int]) -> list[dict]:
    results = []
    for seed in seeds:
        config = load_scenario(config_path)
        env = ReimburseSimEnv(config)
        obs, _ = env.reset(seed=seed)
        knobs = dict(FIXED_RULE_KNOBS)
        rewards = []
        for _ in range(config.episode_length):
            action = encode_action(knobs)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if info.get("metrics", {}).get("leakage_rate", 0) > 0.2:
                knobs["random_audit_ratio"] = min(0.50, knobs["random_audit_ratio"] + 0.05)
            if obs[2] > 0.85:
                knobs["escalation_intensity"] = max(0.0, knobs["escalation_intensity"] - 0.1)
            if obs[7] > 0.5:
                knobs["risk_threshold"] = max(0.30, knobs["risk_threshold"] - 0.05)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


def eval_model(model, config_path: str, seeds: list[int], wrapper=None) -> list[dict]:
    results = []
    for seed in seeds:
        config = load_scenario(config_path)
        env = ReimburseSimEnv(config)
        if wrapper is not None:
            env = wrapper(env)
        obs, _ = env.reset(seed=seed)
        rewards = []
        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


def aggregate(episodes: list[dict]) -> dict:
    out = {}
    for key in METRIC_KEYS:
        if key == "total_reward":
            vals = [e["total_reward"] for e in episodes]
        else:
            vals = [e.get(key, 0.0) for e in episodes]
        out[key] = {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
        }
    return out


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--train-config", default="configs/default_quarter.yaml")
    p.add_argument("--train-seed", type=int, default=0)
    p.add_argument("--timesteps", type=int, default=50000)
    p.add_argument("--eval-seeds", type=int, nargs="+", default=[100, 101, 102, 103, 104])
    p.add_argument("--out-dir", default="results/m4_stress")
    p.add_argument("--skip-train", action="store_true")
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    eval_seeds = args.eval_seeds
    all_results = {}
    t0 = time.time()

    # Train SAC once on default config
    if not args.skip_train:
        print("[M4] Training SAC on default_quarter ...")
        train_config = load_scenario(args.train_config)
        train_env = ReimburseSimEnv(train_config)
        train_env.reset(seed=args.train_seed)
        model_sac = SAC(
            "MlpPolicy", train_env,
            learning_rate=3e-4, buffer_size=100000, learning_starts=1000,
            batch_size=256, gamma=0.99, tau=0.005, ent_coef="auto",
            verbose=0 if args.quiet else 1, seed=args.train_seed, device="auto",
        )
        model_sac.learn(total_timesteps=args.timesteps, progress_bar=False)
        print(f"  SAC trained in {time.time()-t0:.0f}s")
    else:
        print("[M4] Using pre-trained SAC (--skip-train)")

    # Evaluate all policies on all stress configs
    for stress_name, config_path in STRESS_CONFIGS.items():
        print(f"\n[M4] Evaluating {stress_name} ...")

        config_results = {}

        # Rule baselines (no training needed)
        config_results["fixed_rule"] = aggregate(
            eval_fixed_rule(config_path, eval_seeds)
        )
        config_results["risk_threshold"] = aggregate(
            eval_risk_threshold(config_path, eval_seeds)
        )

        if not args.skip_train:
            # SAC variants
            config_results["SAC"] = aggregate(
                eval_model(model_sac, config_path, eval_seeds)
            )
            config_results["SAC-NoRisk"] = aggregate(
                eval_model(model_sac, config_path, eval_seeds, NoRiskRewardWrapper)
            )
            config_results["SAC-NoSocial"] = aggregate(
                eval_model(model_sac, config_path, eval_seeds, NoSocialObservationWrapper)
            )

        all_results[stress_name] = config_results

        # Print summary
        print(f"  {'Policy':<16} {'Leakage':>8} {'Catch':>8} {'CVaR':>8} {'Cycle':>8}")
        for pol, met in config_results.items():
            print(f"  {pol:<16} {met['leakage_rate']['mean']:8.4f} {met['fraud_catch_rate']['mean']:8.4f} {met['cvar_leakage_5pct']['mean']:8.4f} {met['mean_cycle_time']['mean']:8.2f}")

    wall = time.time() - t0

    out = {
        "description": "M4 stress robustness evaluation",
        "train_config": args.train_config,
        "train_seed": args.train_seed,
        "train_timesteps": args.timesteps,
        "eval_seeds": eval_seeds,
        "wall_seconds": round(wall, 1),
        "results": all_results,
    }

    out_path = out_dir / "stress_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    # Markdown summary
    md = ["# M4 Stress Robustness Results\n", f"Wall time: {wall:.0f}s\n"]
    md.append("| Stress | Policy | Leakage | Catch | CVaR | Cycle |")
    md.append("|--------|--------|---------|-------|------|-------|")
    for stress_name, config_results in all_results.items():
        for pol, met in config_results.items():
            md.append(
                f"| {stress_name} | {pol} | {met['leakage_rate']['mean']:.3f} | "
                f"{met['fraud_catch_rate']['mean']:.3f} | {met['cvar_leakage_5pct']['mean']:.3f} | "
                f"{met['mean_cycle_time']['mean']:.2f} |"
            )

    md_path = out_dir / "summary.md"
    md_path.write_text("\n".join(md), encoding="utf-8")
    print(f"\n  Wrote {out_path} and {md_path}")


if __name__ == "__main__":
    main()
