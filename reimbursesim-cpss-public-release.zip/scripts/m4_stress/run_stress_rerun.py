"""M4 Stress Rerun — independently trained models for each variant.

Key fixes over run_stress_eval.py:
  1. Each variant (SAC-Full, SAC-NoRisk, SAC-NoSocial, DQN) trains its OWN model
     with its own wrapper during training (not just evaluation).
  2. DQN is included with proper DiscretizedActionWrapper.
  3. 3 train seeds per variant, 5 eval seeds per train seed.
  4. Output: results/m4_stress_rerun/

Usage:
    python scripts/m4_stress/run_stress_rerun.py --out results/m4_stress_rerun/
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

from stable_baselines3 import SAC, DQN

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.models import ACTION_KEYS, ACTION_RANGES
from reimbursesim.wrappers import (
    DiscretizedActionWrapper,
    NoRiskRewardWrapper,
    NoSocialObservationWrapper,
)


def _cfg(name):
    return str(PROJECT / "configs" / name)


STRESS_CONFIGS = {
    "fraud_burst": _cfg("stress_fraud_burst.yaml"),
    "month_end": _cfg("stress_month_end.yaml"),
    "reviewer_shortage": _cfg("stress_reviewer_shortage.yaml"),
    "policy_shock": _cfg("stress_policy_shock.yaml"),
    "budget_shock": _cfg("stress_budget_shock.yaml"),
}

FIXED_RULE_KNOBS = {
    "random_audit_ratio": 0.15,
    "targeted_audit_weight": 0.5,
    "risk_threshold": 0.6,
    "auto_approval_prob": 0.3,
    "escalation_intensity": 0.2,
    "reviewer_load_temperature": 1.0,
}

METRIC_KEYS = [
    "total_reward", "leakage_rate", "fraud_catch_rate",
    "mean_cycle_time", "cvar_leakage_5pct", "appeal_rate",
    "false_alarm_rate", "sla_violation_rate", "audit_count",
]

VARIANTS = [
    {
        "name": "SAC-Full",
        "wrapper": None,
        "algo": "SAC",
    },
    {
        "name": "SAC-NoRisk",
        "wrapper": NoRiskRewardWrapper,
        "algo": "SAC",
    },
    {
        "name": "SAC-NoSocial",
        "wrapper": NoSocialObservationWrapper,
        "algo": "SAC",
    },
    {
        "name": "DQN",
        "wrapper": None,
        "algo": "DQN",
    },
]


def encode_action(knobs: dict[str, float]) -> np.ndarray:
    a = np.zeros(6, dtype=np.float32)
    for i, key in enumerate(ACTION_KEYS):
        lo, hi = ACTION_RANGES[key]
        a[i] = float(np.clip((knobs[key] - lo) / (hi - lo), 0.0, 1.0))
    return a


# --- Rule baselines (no training needed) ---

def eval_fixed_rule(config_path: str, seeds: list[int]) -> list[dict]:
    results = []
    for seed in seeds:
        config = load_scenario(config_path)
        env = ReimburseSimEnv(config)
        obs, _ = env.reset(seed=seed)
        rewards = []
        for _ in range(config.episode_length):
            action = encode_action(FIXED_RULE_KNOBS)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


def eval_risk_threshold(config_path: str, seeds: list[int]) -> list[dict]:
    results = []
    for seed in seeds:
        config = load_scenario(config_path)
        env = ReimburseSimEnv(config)
        obs, _ = env.reset(seed=seed)
        knobs = dict(FIXED_RULE_KNOBS)
        rewards = []
        for _ in range(config.episode_length):
            action = encode_action(knobs)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if info.get("metrics", {}).get("leakage_rate", 0) > 0.2:
                knobs["random_audit_ratio"] = min(0.50, knobs["random_audit_ratio"] + 0.05)
            if obs[2] > 0.85:
                knobs["escalation_intensity"] = max(0.0, knobs["escalation_intensity"] - 0.1)
            if obs[7] > 0.5:
                knobs["risk_threshold"] = max(0.30, knobs["risk_threshold"] - 0.05)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


# --- Model evaluation ---

def eval_model(model, config_path: str, seeds: list[int],
               wrapper=None, discretize=False) -> list[dict]:
    results = []
    for seed in seeds:
        config = load_scenario(config_path)
        env = ReimburseSimEnv(config)
        if discretize:
            env = DiscretizedActionWrapper(env, bins=3)
        if wrapper is not None:
            env = wrapper(env)
        obs, _ = env.reset(seed=seed)
        rewards = []
        ep_len = env.unwrapped.config.episode_length if not discretize else env.env.config.episode_length
        for _ in range(ep_len):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


def aggregate(episodes: list[dict]) -> dict:
    out = {}
    for key in METRIC_KEYS:
        if key == "total_reward":
            vals = [e["total_reward"] for e in episodes]
        else:
            vals = [e.get(key, 0.0) for e in episodes]
        out[key] = {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
        }
    return out


def train_one(variant, train_config_path, train_seed, timesteps):
    """Train a single model. Returns (model, train_time, variant_train_wrapper, is_discrete)."""
    config = load_scenario(train_config_path)
    env = ReimburseSimEnv(config)

    is_discrete = (variant["algo"] == "DQN")
    train_wrapper = variant["wrapper"]

    if is_discrete:
        env = DiscretizedActionWrapper(env, bins=3)

    if train_wrapper is not None:
        env = train_wrapper(env)

    env.reset(seed=train_seed)

    if is_discrete:
        model = DQN(
            "MlpPolicy", env,
            learning_rate=5e-4, buffer_size=20000, learning_starts=1000,
            batch_size=64, gamma=0.99, target_update_interval=500,
            train_freq=4, exploration_fraction=0.3, exploration_final_eps=0.05,
            verbose=0, seed=train_seed, device="auto",
        )
    else:
        model = SAC(
            "MlpPolicy", env,
            learning_rate=3e-4, buffer_size=100000, learning_starts=1000,
            batch_size=256, gamma=0.99, tau=0.005, ent_coef="auto",
            verbose=0, seed=train_seed, device="auto",
        )

    t0 = time.time()
    model.learn(total_timesteps=timesteps, progress_bar=False)
    train_time = time.time() - t0

    return model, train_time, is_discrete


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--train-config", default="configs/default_quarter.yaml")
    p.add_argument("--train-seeds", type=int, nargs="+", default=[0, 1, 2])
    p.add_argument("--timesteps", type=int, default=50000)
    p.add_argument("--eval-seeds", type=int, nargs="+", default=[100, 101, 102, 103, 104])
    p.add_argument("--out-dir", default="results/m4_stress_rerun")
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    eval_seeds = args.eval_seeds
    t0 = time.time()

    # Train all models
    trained_models = {}
    for vcfg in VARIANTS:
        vname = vcfg["name"]
        print(f"\n[M4-Rerun] Training {vname} ...", flush=True)
        for train_seed in args.train_seeds:
            model, train_time, is_discrete = train_one(
                vcfg, args.train_config, train_seed, args.timesteps
            )
            key = f"{vname}_seed{train_seed}"
            trained_models[key] = {
                "model": model,
                "train_wall_seconds": round(train_time, 1),
                "is_discrete": is_discrete,
                "variant": vname,
                "variant_wrapper": vcfg["wrapper"],
            }
            print(f"  {key}: {train_time:.0f}s", flush=True)

    # Evaluate: each trained model × each stress config
    all_results = {}

    for stress_name, config_path in STRESS_CONFIGS.items():
        print(f"\n[M4-Rerun] Stress: {stress_name} ...", flush=True)
        config_results = {}

        # Rule baselines (once per stress config)
        config_results["fixed_rule"] = aggregate(
            eval_fixed_rule(config_path, eval_seeds)
        )
        config_results["risk_threshold"] = aggregate(
            eval_risk_threshold(config_path, eval_seeds)
        )

        for key, tdata in trained_models.items():
            model = tdata["model"]
            is_discrete = tdata["is_discrete"]
            wrapper = tdata["variant_wrapper"]

            episodes = eval_model(
                model, config_path, eval_seeds,
                wrapper=wrapper, discretize=is_discrete
            )
            met = aggregate(episodes)
            config_results[key] = met
            print(f"  {key}: leak={met['leakage_rate']['mean']:.4f} "
                  f"catch={met['fraud_catch_rate']['mean']:.4f} "
                  f"cvar={met['cvar_leakage_5pct']['mean']:.4f}", flush=True)

        all_results[stress_name] = config_results

    wall = time.time() - t0

    # Aggregate by variant (mean ± std across train seeds)
    variant_agg = {}
    for vcfg in VARIANTS:
        vname = vcfg["name"]
        # Collect per-seed metrics across stress configs
        all_leak = []
        all_catch = []
        all_cvar = []
        all_cycle = []
        all_reward = []
        for stress_name in STRESS_CONFIGS:
            for seed_idx in args.train_seeds:
                key = f"{vname}_seed{seed_idx}"
                if key in all_results.get(stress_name, {}):
                    m = all_results[stress_name][key]
                    all_leak.append(m["leakage_rate"]["mean"])
                    all_catch.append(m["fraud_catch_rate"]["mean"])
                    all_cvar.append(m["cvar_leakage_5pct"]["mean"])
                    all_cycle.append(m["mean_cycle_time"]["mean"])
                    all_reward.append(m["total_reward"]["mean"])

        if all_leak:
            variant_agg[vname] = {
                "leakage_rate": {"mean": float(np.mean(all_leak)), "std": float(np.std(all_leak, ddof=1))},
                "fraud_catch_rate": {"mean": float(np.mean(all_catch)), "std": float(np.std(all_catch, ddof=1))},
                "cvar_leakage_5pct": {"mean": float(np.mean(all_cvar)), "std": float(np.std(all_cvar, ddof=1))},
                "mean_cycle_time": {"mean": float(np.mean(all_cycle)), "std": float(np.std(all_cycle, ddof=1))},
                "total_reward": {"mean": float(np.mean(all_reward)), "std": float(np.std(all_reward, ddof=1))},
                "n_points": len(all_leak),
            }

    train_times = {k: tdata["train_wall_seconds"] for k, tdata in trained_models.items()}

    out = {
        "description": "M4 stress rerun — independently trained models per variant",
        "train_config": args.train_config,
        "train_seeds": args.train_seeds,
        "train_timesteps": args.timesteps,
        "eval_seeds": eval_seeds,
        "stress_configs": list(STRESS_CONFIGS.keys()),
        "wall_seconds": round(wall, 1),
        "train_wall_seconds": train_times,
        "variant_aggregate": variant_agg,
        "results": all_results,
    }

    out_path = out_dir / "stress_rerun_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"\n  Wrote {out_path}", flush=True)

    # Print summary
    print(f"\n{'Variant':<16} {'Leakage':>10} {'Catch':>8} {'CVaR':>8} {'Cycle':>8} {'Reward':>8}")
    print("-" * 60)
    for vname, m in variant_agg.items():
        print(f"{vname:<16} {m['leakage_rate']['mean']:10.4f} {m['fraud_catch_rate']['mean']:8.4f} "
              f"{m['cvar_leakage_5pct']['mean']:8.4f} {m['mean_cycle_time']['mean']:8.2f} "
              f"{m['total_reward']['mean']:8.1f}")
    print(f"\nTotal wall time: {wall:.0f}s", flush=True)


if __name__ == "__main__":
    main()
