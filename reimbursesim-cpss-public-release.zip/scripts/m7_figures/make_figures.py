"""Generate paper figures from released experiment artifacts.

Usage:
    python scripts/m7_figures/make_figures.py --results-dir results --out-dir results/figures
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    HAS_MPL = True
except ImportError:
    HAS_MPL = False


COLORS = {
    "fixed_rule": "#e74c3c",
    "risk_threshold": "#e67e22",
    "random": "#95a5a6",
    "dqn": "#3498db",
    "ppo": "#2ecc71",
    "ddpg": "#9b59b6",
    "td3": "#f39c12",
    "sac": "#1abc9c",
    "SAC-Full": "#1abc9c",
    "SAC-NoSocial": "#e74c3c",
    "SAC-NoRisk": "#e67e22",
    "DQN": "#3498db",
}
CMAP = matplotlib.colormaps.get_cmap("tab10") if HAS_MPL else None


def load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def save(fig, out_path: Path) -> None:
    fig.savefig(out_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"  Saved {out_path}")


def make_main_comparison(results_dir: Path, out_dir: Path) -> None:
    """Compare rule, discrete-RL, and continuous-RL policies on key metrics."""
    if not HAS_MPL:
        return

    policies = []
    leak_means, leak_stds = [], []
    catch_means, catch_stds = [], []
    cycle_means, cycle_stds = [], []

    rule_files = [
        ("fixed_rule.json", "Fixed Rule"),
        ("risk_threshold.json", "Risk Thr."),
        ("random.json", "Random"),
    ]
    rl_files = [
        ("dqn_b3_seed0.json", "DQN", "m1"),
        ("ppo_seed0.json", "PPO", "m2"),
        ("ddpg_seed0.json", "DDPG", "m2"),
        ("td3_seed0.json", "TD3", "m2"),
        ("sac_seed0.json", "SAC", "m2"),
    ]

    for filename, label in rule_files:
        path = results_dir / "m1" / filename
        if path.exists():
            metrics = load_json(path)["metrics"]
            policies.append(label)
            leak_means.append(metrics["leakage_rate"]["mean"])
            leak_stds.append(metrics["leakage_rate"]["std"])
            catch_means.append(metrics["fraud_catch_rate"]["mean"])
            catch_stds.append(metrics["fraud_catch_rate"]["std"])
            cycle_means.append(metrics["mean_cycle_time"]["mean"])
            cycle_stds.append(metrics["mean_cycle_time"]["std"])

    for filename, label, folder in rl_files:
        path = results_dir / folder / filename
        if path.exists():
            metrics = load_json(path)["metrics"]
            policies.append(label)
            leak_means.append(metrics["leakage_rate"]["mean"])
            leak_stds.append(metrics["leakage_rate"]["std"])
            catch_means.append(metrics["fraud_catch_rate"]["mean"])
            catch_stds.append(metrics["fraud_catch_rate"]["std"])
            cycle_means.append(metrics["mean_cycle_time"]["mean"])
            cycle_stds.append(metrics["mean_cycle_time"]["std"])

    if not policies:
        print("[M7] No main comparison data found")
        return

    fig, axes = plt.subplots(1, 3, figsize=(16, 5))
    x = np.arange(len(policies))
    colors = [COLORS.get(policy.lower().replace(" ", "_").replace(".", ""), CMAP(i)) for i, policy in enumerate(policies)]

    panels = [
        (leak_means, leak_stds, "Leakage Rate", "Leakage Rate (lower is better)"),
        (catch_means, catch_stds, "Fraud Catch Rate", "Fraud Catch Rate (higher is better)"),
        (cycle_means, cycle_stds, "Mean Cycle Time (days)", "Cycle Time (lower is better)"),
    ]
    for ax, (means, stds, ylabel, title) in zip(axes, panels):
        ax.bar(x, means, yerr=stds, color=colors, capsize=4)
        ax.set_xticks(x)
        ax.set_xticklabels(policies, rotation=30, ha="right", fontsize=9)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid(axis="y", alpha=0.3)

    fig.suptitle("ReimburseSim-CPSS: Policy Comparison", fontsize=14, fontweight="bold")
    plt.tight_layout()
    save(fig, out_dir / "main_comparison.png")


def make_social_negative_result(results_dir: Path, out_dir: Path) -> None:
    """Plot Full SAC against the no-social-observation ablation."""
    if not HAS_MPL:
        return

    full_leak, nosocial_leak = [], []
    full_catch, nosocial_catch = [], []

    candidates = [results_dir / "m3" / "killer_seed0.json"]
    candidates.extend(results_dir / "m3_rescue" / f"killer_stress_seed{seed}.json" for seed in range(3))

    for path in candidates:
        if not path.exists():
            continue
        for variant_name, variant_data in load_json(path)["results"].items():
            metrics = variant_data["metrics"]
            if "full" in variant_name.lower():
                full_leak.append(metrics["leakage_rate"]["mean"])
                full_catch.append(metrics["fraud_catch_rate"]["mean"])
            else:
                nosocial_leak.append(metrics["leakage_rate"]["mean"])
                nosocial_catch.append(metrics["fraud_catch_rate"]["mean"])

    if not full_leak:
        print("[M7] No social comparison data found")
        return

    run_count = len(full_leak)
    x = np.arange(run_count)
    width = 0.35
    fig, axes = plt.subplots(1, 2, figsize=(10, 4.5))

    panels = [
        (axes[0], full_leak, nosocial_leak, "Leakage Rate", "Leakage: Full vs NoSocial"),
        (axes[1], full_catch, nosocial_catch, "Fraud Catch Rate", "Fraud Catch: Full vs NoSocial"),
    ]
    for ax, full_values, nosocial_values, ylabel, title in panels:
        ax.bar(x - width / 2, full_values, width, label="SAC-Full", color=COLORS["SAC-Full"], alpha=0.85)
        ax.bar(x + width / 2, nosocial_values, width, label="SAC-NoSocial", color=COLORS["SAC-NoSocial"], alpha=0.85)
        ax.set_xticks(x)
        ax.set_xticklabels([f"Run {idx + 1}" for idx in range(run_count)])
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.legend()
        ax.grid(axis="y", alpha=0.3)

    fig.suptitle("Social Observation: Negative Result", fontsize=14, fontweight="bold")
    plt.tight_layout()
    save(fig, out_dir / "social_negative_result.png")


def make_validation_plots(results_dir: Path, out_dir: Path) -> None:
    """Plot simulator validation summaries."""
    if not HAS_MPL:
        return

    path = results_dir / "validation" / "simulator_validation.json"
    if not path.exists():
        print("[M7] No validation data found")
        return

    data = load_json(path)
    names = list(data.keys())
    fig, axes = plt.subplots(2, 2, figsize=(12, 9))

    ax = axes[0, 0]
    for scenario_name, scenario_data in data.items():
        amount = scenario_data["claim_amount"]
        ax.plot([amount["p05"], amount["median"], amount["p95"]], [0.05, 0.50, 0.95], "o-", label=scenario_name)
    ax.set_xlabel("Claim Amount (CNY)")
    ax.set_ylabel("CDF")
    ax.set_title("Claim Amount Distribution")
    ax.legend(fontsize=8)
    ax.grid(alpha=0.3)
    ax.set_xscale("log")

    ax = axes[0, 1]
    means = [data[name]["daily_volume"]["mean"] for name in names]
    max_values = [data[name]["daily_volume"]["max"] for name in names]
    x = np.arange(len(names))
    width = 0.3
    ax.bar(x - width / 2, means, width, label="Mean", color="#3498db")
    ax.bar(x + width / 2, max_values, width, label="Max", color="#e74c3c")
    ax.set_xticks(x)
    ax.set_xticklabels(names, rotation=20, ha="right", fontsize=8)
    ax.set_ylabel("Claims per Day")
    ax.set_title("Daily Claim Volume")
    ax.legend()

    ax = axes[1, 0]
    for scenario_name, scenario_data in data.items():
        cycle = scenario_data["cycle_time"]
        ax.barh(scenario_name, cycle["mean"], xerr=cycle["std"], label=f"{scenario_name} (max={cycle['max']:.0f}d)")
    ax.set_xlabel("Mean Cycle Time (days)")
    ax.set_title("Cycle Time Distribution")
    ax.grid(axis="x", alpha=0.3)

    ax = axes[1, 1]
    utilizations = [data[name]["reviewer_utilization"]["mean"] for name in names]
    sla_rates = [data[name]["sla_violation_rate"] for name in names]
    ax.scatter(utilizations, sla_rates, s=200, c=["#3498db", "#e74c3c", "#e67e22"][: len(names)])
    for idx, name in enumerate(names):
        ax.annotate(name, (utilizations[idx], sla_rates[idx]), textcoords="offset points", xytext=(5, 5), fontsize=8)
    ax.set_xlabel("Mean Reviewer Utilization")
    ax.set_ylabel("SLA Violation Rate")
    ax.set_title("Utilization vs SLA Violation")
    ax.grid(alpha=0.3)

    fig.suptitle("Simulator Validation", fontsize=14, fontweight="bold")
    plt.tight_layout()
    save(fig, out_dir / "validation_distributions.png")


def make_stress_comparison(results_dir: Path, out_dir: Path) -> None:
    """Plot leakage under each corrected stress scenario."""
    if not HAS_MPL:
        return

    path = results_dir / "m4_stress_rerun" / "stress_results.json"
    if not path.exists():
        print("[M7] No stress results found")
        return

    stress_results = load_json(path).get("results", {})
    stress_names = list(stress_results.keys())
    if not stress_names:
        return

    policy_names = list(stress_results[stress_names[0]].keys())
    fig, axes = plt.subplots(2, 3, figsize=(16, 9))
    axes = axes.flatten()

    for idx, stress_name in enumerate(stress_names):
        if idx >= len(axes):
            break
        ax = axes[idx]
        data = stress_results[stress_name]
        x = np.arange(len(policy_names))
        leaks = [data[policy]["leakage_rate"]["mean"] for policy in policy_names]
        colors = [COLORS.get(policy, COLORS.get(policy.lower(), CMAP(j % 10))) for j, policy in enumerate(policy_names)]

        ax.bar(x, leaks, color=colors)
        ax.set_xticks(x)
        ax.set_xticklabels(policy_names, rotation=30, ha="right", fontsize=7)
        ax.set_ylabel("Leakage Rate")
        ax.set_title(stress_name.replace("_", " ").title())
        ax.grid(axis="y", alpha=0.3)

    for idx in range(len(stress_names), len(axes)):
        axes[idx].set_visible(False)

    fig.suptitle("Policy Performance Under Stress Scenarios", fontsize=14, fontweight="bold")
    plt.tight_layout()
    save(fig, out_dir / "stress_comparison.png")


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", default="results")
    parser.add_argument("--out-dir", default="results/figures")
    return parser.parse_args()


def main() -> None:
    if not HAS_MPL:
        print("[M7] matplotlib not available; install with: pip install matplotlib")
        return

    args = parse_args()
    results_dir = Path(args.results_dir).resolve()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("[M7] Generating figures ...")
    make_main_comparison(results_dir, out_dir)
    make_social_negative_result(results_dir, out_dir)
    make_validation_plots(results_dir, out_dir)
    make_stress_comparison(results_dir, out_dir)
    print("[M7] Done.")


if __name__ == "__main__":
    main()
