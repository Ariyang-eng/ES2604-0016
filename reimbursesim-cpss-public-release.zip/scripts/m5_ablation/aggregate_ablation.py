"""Aggregate M5 ablation results across seeds into ablation_results.json."""
import json
from pathlib import Path
import numpy as np

results_dir = Path(__file__).resolve().parents[2] / "results" / "m5_ablation"

VARIANTS = ["SAC-Full", "SAC-NoSocial", "SAC-NoRisk", "DQN"]
SEEDS = [0, 1, 2]
METRIC_KEYS = [
    "total_reward", "leakage_rate", "fraud_catch_rate",
    "mean_cycle_time", "cvar_leakage_5pct", "appeal_rate",
    "false_alarm_rate", "sla_violation_rate", "audit_count",
]


def main():
    summary = {}
    all_runs = []

    for variant in VARIANTS:
        variant_data = []
        for seed in SEEDS:
            fname = f"{variant.replace('-', '_')}_seed{seed}.json"
            path = results_dir / fname
            if not path.exists():
                print(f"  MISSING: {fname}")
                continue
            with open(path) as f:
                d = json.load(f)
            variant_data.append(d)
            all_runs.append(d)

        if not variant_data:
            continue

        agg = {}
        for key in METRIC_KEYS:
            means = [d["metrics"][key]["mean"] for d in variant_data]
            agg[key] = {
                "mean": float(np.mean(means)),
                "std": float(np.std(means, ddof=1)) if len(means) > 1 else 0.0,
            }
        agg["n_seeds"] = len(variant_data)
        agg["train_wall_seconds"] = float(np.mean([d["train_wall_seconds"] for d in variant_data]))
        summary[variant] = agg

    out = {
        "description": "M5 ablation study: SAC-Full vs SAC-NoSocial vs SAC-NoRisk vs DQN",
        "timesteps": 50000,
        "seeds": SEEDS,
        "eval_seeds": [200, 201, 202, 203, 204],
        "summary": summary,
        "runs": [{
            "variant": d["variant"],
            "seed": d["seed"],
            "leakage": d["metrics"]["leakage_rate"]["mean"],
            "catch": d["metrics"]["fraud_catch_rate"]["mean"],
            "cvar": d["metrics"]["cvar_leakage_5pct"]["mean"],
            "reward": d["metrics"]["total_reward"]["mean"],
        } for d in all_runs],
    }

    out_path = results_dir / "ablation_results.json"
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(f"Wrote {out_path}")

    # Print summary table
    print("\n| Variant | Leakage | Catch | CVaR | Cycle | Reward |")
    print("|---------|---------|-------|------|-------|--------|")
    for v, m in summary.items():
        print(f"| {v} | {m['leakage_rate']['mean']:.4f}±{m['leakage_rate']['std']:.4f} | "
              f"{m['fraud_catch_rate']['mean']:.4f}±{m['fraud_catch_rate']['std']:.4f} | "
              f"{m['cvar_leakage_5pct']['mean']:.4f}±{m['cvar_leakage_5pct']['std']:.4f} | "
              f"{m['mean_cycle_time']['mean']:.3f} | {m['total_reward']['mean']:.1f} |")


if __name__ == "__main__":
    main()
