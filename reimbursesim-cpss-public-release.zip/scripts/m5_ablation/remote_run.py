"""Deploy M5 ablation jobs to a remote GPU server.

Connection settings are read from environment variables and are never stored
in source control:

    REMOTE_HOST, REMOTE_PORT, REMOTE_USER, REMOTE_PASSWORD
"""

import os
import sys
import time
import tarfile
import io
from pathlib import Path

import paramiko

HOST = os.environ.get("REMOTE_HOST")
PORT = int(os.environ.get("REMOTE_PORT", "22"))
USER = os.environ.get("REMOTE_USER", "root")
PASSWD = os.environ.get("REMOTE_PASSWORD")

PROJECT_LOCAL = Path(__file__).resolve().parents[2]
REMOTE_DIR = "/root/reimbursesim"

VARIANTS = ["SAC-Full", "SAC-NoSocial", "SAC-NoRisk", "DQN"]
SEEDS = [0, 1, 2]
TIMESTEPS = 50000

EXCLUDE_DIRS = {"__pycache__", ".git", "results", ".venv", "node_modules", ".mypy_cache"}


def get_ssh():
    if not HOST or not PASSWD:
        raise RuntimeError(
            "Set REMOTE_HOST and REMOTE_PASSWORD before running this script. "
            "REMOTE_PORT and REMOTE_USER are optional."
        )
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(HOST, port=PORT, username=USER, password=PASSWD, timeout=30)
    return ssh


def run_cmd(ssh, cmd, timeout=300):
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=timeout)
    stdout.channel.settimeout(timeout)
    out = stdout.read().decode()
    err = stderr.read().decode()
    rc = stdout.channel.recv_exit_status()
    return rc, out, err


def run_cmd_quick(ssh, cmd, timeout=10):
    """For commands that should return immediately (nohup background)."""
    stdin, stdout, stderr = ssh.exec_command(cmd, timeout=timeout)
    stdout.channel.settimeout(timeout)
    try:
        out = stdout.read().decode()
    except Exception:
        out = ""
    return out.strip()


def create_tarball():
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for root, dirs, files in os.walk(str(PROJECT_LOCAL)):
            dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
            for f in files:
                fpath = os.path.join(root, f)
                if os.path.getsize(fpath) > 2_000_000:
                    continue
                arcname = os.path.relpath(fpath, str(PROJECT_LOCAL))
                tar.add(fpath, arcname=arcname)
    buf.seek(0)
    return buf


def main():
    print("[M5-Remote] Connecting...", flush=True)
    ssh = get_ssh()

    rc, out, err = run_cmd(ssh, "nvidia-smi --query-gpu=name --format=csv,noheader")
    print(f"[GPU] {out.strip()}", flush=True)

    # Create and upload tarball
    print("[M5-Remote] Creating tarball...", flush=True)
    tar_buf = create_tarball()
    tar_size = tar_buf.getbuffer().nbytes
    print(f"[M5-Remote] Tarball size: {tar_size / 1024 / 1024:.1f} MB", flush=True)

    print("[M5-Remote] Uploading...", flush=True)
    sftp = ssh.open_sftp()
    run_cmd(ssh, f"rm -rf {REMOTE_DIR} && mkdir -p {REMOTE_DIR}")
    sftp.putfo(tar_buf, f"{REMOTE_DIR}/project.tar.gz")
    sftp.close()

    # Extract
    print("[M5-Remote] Extracting...", flush=True)
    rc, out, err = run_cmd(ssh, f"cd {REMOTE_DIR} && tar xzf project.tar.gz && rm project.tar.gz")
    if rc != 0:
        print(f"[ERROR] Extract failed: {err[:300]}")
        sys.exit(1)

    # Create results dir
    run_cmd(ssh, f"mkdir -p {REMOTE_DIR}/results/m5_ablation")

    # Check deps
    rc, out, err = run_cmd(ssh, "pip show gymnasium 2>/dev/null | grep Version")
    if not out.strip():
        print("[M5-Remote] Installing gymnasium...", flush=True)
        run_cmd(ssh, "pip install gymnasium pyyaml -q", timeout=120)

    # Write a launcher script on remote and execute it
    n_jobs = len(VARIANTS) * len(SEEDS)
    print(f"[M5-Remote] Launching {n_jobs} experiments...", flush=True)

    # Build launcher script
    lines = ["#!/bin/bash", f"cd {REMOTE_DIR}", ""]
    tags = []
    for variant in VARIANTS:
        for seed in SEEDS:
            tag = f"{variant.replace('-','_')}_seed{seed}"
            tags.append(tag)
            lines.append(
                f"python3 scripts/m5_ablation/train_one.py "
                f"--variant {variant} --seed {seed} --timesteps {TIMESTEPS} "
                f"--out-dir results/m5_ablation "
                f"> /tmp/m5_{tag}.log 2>&1 &"
            )
    lines.append("")
    lines.append("echo $! > /tmp/m5_last_pid")
    lines.append("echo LAUNCHED")
    launcher_script = "\n".join(lines)

    # Upload and run launcher
    sftp2 = ssh.open_sftp()
    with sftp2.open(f"{REMOTE_DIR}/launch_m5.sh", "w") as f:
        f.write(launcher_script)
    sftp2.close()

    rc, out, err = run_cmd(ssh, f"chmod +x {REMOTE_DIR}/launch_m5.sh && bash {REMOTE_DIR}/launch_m5.sh", timeout=30)
    print(f"  Launcher: {out.strip()}", flush=True)

    # Get PIDs of running python processes
    time.sleep(2)
    rc, out, err = run_cmd(ssh, "pgrep -f 'train_one.py' | tr '\\n' ' '")
    pids_str = out.strip()
    print(f"  Running PIDs: {pids_str}", flush=True)

    # Poll until all done (count result JSON files)
    print(f"\n[M5-Remote] Waiting for {n_jobs} jobs...", flush=True)
    t0 = time.time()
    last_count = 0
    while True:
        time.sleep(15)
        rc, out, err = run_cmd(ssh, f"ls {REMOTE_DIR}/results/m5_ablation/*.json 2>/dev/null | wc -l", timeout=15)
        count = int(out.strip()) if out.strip().isdigit() else 0
        if count > last_count:
            elapsed = time.time() - t0
            print(f"  [{count}/{n_jobs}] results ready ({elapsed:.0f}s)", flush=True)
            last_count = count
        if count >= n_jobs:
            break
        elapsed = time.time() - t0
        if elapsed > 1800:
            print(f"[TIMEOUT] 30min exceeded, got {count}/{n_jobs}", flush=True)
            break

    # Print final logs
    print("\n[M5-Remote] Final output:", flush=True)
    for tag in tags:
        rc, out, err = run_cmd(ssh, f"tail -1 /tmp/m5_{tag}.log 2>/dev/null", timeout=10)
        print(f"  {tag}: {out.strip()}", flush=True)

    # Download results
    print("\n[M5-Remote] Downloading results...", flush=True)
    sftp = ssh.open_sftp()
    local_out = PROJECT_LOCAL / "results" / "m5_ablation"
    local_out.mkdir(parents=True, exist_ok=True)

    remote_results = f"{REMOTE_DIR}/results/m5_ablation"
    try:
        for fname in sftp.listdir(remote_results):
            if fname.endswith(".json"):
                sftp.get(f"{remote_results}/{fname}", str(local_out / fname))
                print(f"  Got {fname}", flush=True)
    except Exception as e:
        print(f"  [WARN] Download issue: {e}", flush=True)

    sftp.close()
    ssh.close()
    print("\n[M5-Remote] ALL DONE.", flush=True)


if __name__ == "__main__":
    main()
