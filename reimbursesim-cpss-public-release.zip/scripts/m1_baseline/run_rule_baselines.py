"""M1 rule baselines for ReimburseSim-CPSS.

Runs the non-learning baselines from experiments/BASELINE_MATRIX.md:
    B1 fixed enterprise rule
    B2 reactive risk-threshold heuristic
    B3 random continuous policy

Example:
    python scripts/m1_baseline/run_rule_baselines.py ^
        --config configs/m0_sanity_adaptive.yaml ^
        --seeds 0 1 2 3 4 ^
        --out results/m1/rule_baselines.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from reimbursesim import ReimburseSimEnv, load_scenario  # noqa: E402
from reimbursesim.models import ACTION_KEYS, ACTION_RANGES  # noqa: E402


FIXED_RULE_PHYSICAL = {
    "random_audit_ratio": 0.15,
    "targeted_audit_weight": 0.5,
    "risk_threshold": 0.6,
    "auto_approval_prob": 0.3,
    "escalation_intensity": 0.2,
    "reviewer_load_temperature": 1.0,
}


def encode_action(knobs: dict[str, float]) -> np.ndarray:
    """Encode physical knob values to the env's normalized [0, 1]^6 action."""
    action = np.zeros(len(ACTION_KEYS), dtype=np.float32)
    for i, key in enumerate(ACTION_KEYS):
        lo, hi = ACTION_RANGES[key]
        value = float(np.clip(knobs[key], lo, hi))
        action[i] = (value - lo) / (hi - lo)
    return action


class BaselinePolicy(Protocol):
    name: str

    def reset(self, seed: int) -> None:
        ...

    def act(self, obs: np.ndarray, info: dict) -> np.ndarray:
        ...


@dataclass
class FixedRulePolicy:
    name: str = "B1_fixed_rule"

    def reset(self, seed: int) -> None:  # noqa: ARG002
        return None

    def act(self, obs: np.ndarray, info: dict) -> np.ndarray:  # noqa: ARG002
        return encode_action(FIXED_RULE_PHYSICAL)


@dataclass
class ReactiveRiskThresholdPolicy:
    """B2 heuristic from BASELINE_MATRIX.md.

    It keeps B1 defaults and adjusts three physical knobs using observable
    signals from the previous day's metrics plus the current observation.
    """

    name: str = "B2_risk_threshold"

    def reset(self, seed: int) -> None:  # noqa: ARG002
        self.knobs = dict(FIXED_RULE_PHYSICAL)

    def act(self, obs: np.ndarray, info: dict) -> np.ndarray:
        metrics = info.get("metrics", {})
        recent_leakage = float(metrics.get("leakage_rate", obs[19] if len(obs) > 19 else 0.0))
        reviewer_util = float(obs[2]) if len(obs) > 2 else 0.0
        rolling_risk = float(obs[7]) if len(obs) > 7 else 0.0

        if recent_leakage > 0.2:
            self.knobs["random_audit_ratio"] += 0.05
        if reviewer_util > 0.85:
            self.knobs["escalation_intensity"] -= 0.1
        if rolling_risk > 0.5:
            self.knobs["risk_threshold"] -= 0.05

        return encode_action(self.knobs)


@dataclass
class RandomPolicy:
    name: str = "B3_random_uniform"

    def reset(self, seed: int) -> None:
        self.rng = np.random.default_rng(seed)

    def act(self, obs: np.ndarray, info: dict) -> np.ndarray:  # noqa: ARG002
        return self.rng.uniform(0.0, 1.0, size=len(ACTION_KEYS)).astype(np.float32)


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="Scenario YAML path")
    p.add_argument("--seeds", nargs="+", type=int, default=[0, 1, 2, 3, 4])
    p.add_argument("--out", required=True, help="Output JSON path")
    return p.parse_args()


def run_episode(policy: BaselinePolicy, config_path: str, seed: int) -> dict:
    config = load_scenario(config_path)
    env = ReimburseSimEnv(config)
    policy.reset(seed)

    obs, info = env.reset(seed=seed)
    rewards: list[float] = []
    daily_summaries: list[dict] = []

    for _ in range(config.episode_length):
        action = policy.act(obs, info)
        obs, reward, term, trunc, info = env.step(action)
        rewards.append(float(reward))
        daily_summaries.append({
            "day": int(info["day"]),
            "action": [float(x) for x in action.tolist()],
            "claims_submitted": info["metrics"]["claims_submitted"],
            "claims_resolved": info["metrics"]["claims_resolved"],
            "leakage_rate": info["metrics"]["leakage_rate"],
            "audit_count": info["metrics"]["audit_count"],
            "appeals": info["metrics"]["appeals"],
            "sla_violations": info["metrics"]["sla_violations"],
            "avg_cycle_time": info["metrics"]["avg_cycle_time"],
            "reward": float(reward),
        })
        if term or trunc:
            break

    summary = dict(info.get("episode_summary", {}))
    return {
        "policy": policy.name,
        "seed": seed,
        "episode_length": config.episode_length,
        "total_reward": float(np.sum(rewards)),
        "mean_daily_reward": float(np.mean(rewards)) if rewards else 0.0,
        "std_daily_reward": float(np.std(rewards)) if rewards else 0.0,
        "min_daily_reward": float(np.min(rewards)) if rewards else 0.0,
        "max_daily_reward": float(np.max(rewards)) if rewards else 0.0,
        "episode_summary": summary,
        "daily_summaries": daily_summaries,
    }


def aggregate(runs: list[dict]) -> dict:
    keys = [
        "total_reward",
        "leakage_rate",
        "fraud_catch_rate",
        "mean_cycle_time",
        "appeal_rate",
        "false_alarm_rate",
        "sla_violation_rate",
        "audit_count",
    ]
    out: dict[str, dict[str, float]] = {}
    for key in keys:
        vals = []
        for run in runs:
            if key == "total_reward":
                vals.append(float(run[key]))
            else:
                vals.append(float(run["episode_summary"].get(key, 0.0)))
        out[key] = {
            "mean": float(np.mean(vals)) if vals else 0.0,
            "std": float(np.std(vals)) if vals else 0.0,
            "min": float(np.min(vals)) if vals else 0.0,
            "max": float(np.max(vals)) if vals else 0.0,
        }
    return out


def main() -> None:
    args = parse_args()
    policies: list[BaselinePolicy] = [
        FixedRulePolicy(),
        ReactiveRiskThresholdPolicy(),
        RandomPolicy(),
    ]

    t0 = time.time()
    runs_by_policy: dict[str, list[dict]] = {}
    for policy in policies:
        runs_by_policy[policy.name] = [
            run_episode(policy, args.config, seed) for seed in args.seeds
        ]

    out = {
        "scenario_config": args.config,
        "seeds": args.seeds,
        "baselines": {
            name: {
                "aggregate": aggregate(runs),
                "runs": runs,
            }
            for name, runs in runs_by_policy.items()
        },
        "wall_time_seconds": round(time.time() - t0, 3),
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    print(f"[M1 baselines OK] wrote {out_path}")
    for name, runs in runs_by_policy.items():
        agg = aggregate(runs)
        print(
            f"  {name}: reward={agg['total_reward']['mean']:.3f}±{agg['total_reward']['std']:.3f}, "
            f"leak={agg['leakage_rate']['mean']:.3f}, "
            f"catch={agg['fraud_catch_rate']['mean']:.3f}, "
            f"cycle={agg['mean_cycle_time']['mean']:.2f}"
        )


if __name__ == "__main__":
    main()
