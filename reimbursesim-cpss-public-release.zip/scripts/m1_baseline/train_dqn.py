"""Train SB3 DQN on the discretized ReimburseSim env.

Usage:
    python scripts/m1_baseline/train_dqn.py \\
        --config configs/default_quarter.yaml \\
        --seed 0 --bins 2 --timesteps 50000 \\
        --out results/m1/dqn_seed0.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from stable_baselines3 import DQN  # noqa: E402

from reimbursesim import ReimburseSimEnv, load_scenario  # noqa: E402
from reimbursesim.wrappers import DiscretizedActionWrapper  # noqa: E402


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--bins", type=int, default=2, help="Bins per knob (action space = bins**6)")
    p.add_argument("--timesteps", type=int, default=30000)
    p.add_argument("--eval-episodes", type=int, default=5)
    p.add_argument("--out", required=True)
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def make_env(config, seed: int, bins: int):
    env = ReimburseSimEnv(config)
    env = DiscretizedActionWrapper(env, bins=bins)
    env.reset(seed=seed)
    return env


def evaluate(model, env_factory, n_episodes: int, eval_seeds: list[int]) -> dict:
    eps = []
    for s in eval_seeds[:n_episodes]:
        env = env_factory(s)
        obs, _ = env.reset(seed=s)
        rewards = []
        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(int(action))
            rewards.append(reward)
            if term:
                break
        s_summary = info.get("episode_summary", {})
        s_summary["seed"] = s
        s_summary["total_reward"] = float(sum(rewards))
        s_summary["mean_reward"] = float(np.mean(rewards))
        eps.append(s_summary)
    return eps


def main() -> None:
    args = parse_args()
    config = load_scenario(args.config)

    train_env = make_env(config, args.seed, args.bins)
    print(f"[DQN] action_space={train_env.action_space}, bins={args.bins}")

    t0 = time.time()
    model = DQN(
        "MlpPolicy",
        train_env,
        learning_rate=5e-4,
        buffer_size=20000,
        learning_starts=1000,
        batch_size=64,
        gamma=0.99,
        target_update_interval=500,
        train_freq=4,
        exploration_fraction=0.3,
        exploration_final_eps=0.05,
        verbose=0 if args.quiet else 1,
        seed=args.seed,
        device="cpu",
    )
    model.learn(total_timesteps=args.timesteps, progress_bar=False)
    train_wall = time.time() - t0

    # Evaluate on different seeds (1000+)
    eval_seeds = [1000 + args.seed * 10 + i for i in range(args.eval_episodes)]
    per_episode = evaluate(
        model, lambda s: make_env(config, s, args.bins), args.eval_episodes, eval_seeds
    )

    rewards = [e["total_reward"] for e in per_episode]
    leakage = [e.get("leakage_rate", 0.0) for e in per_episode]
    cycles = [e.get("mean_cycle_time", 0.0) for e in per_episode]
    cvar = [e.get("cvar_leakage_5pct", 0.0) for e in per_episode]
    catch = [e.get("fraud_catch_rate", 0.0) for e in per_episode]

    out = {
        "policy": "dqn",
        "scenario": config.scenario_name,
        "train_seed": args.seed,
        "bins_per_knob": args.bins,
        "discrete_actions": args.bins ** 6,
        "timesteps": args.timesteps,
        "train_wall_seconds": round(train_wall, 1),
        "eval_seeds": eval_seeds,
        "n_eval_episodes": len(per_episode),
        "metrics": {
            "total_reward": {
                "mean": float(np.mean(rewards)),
                "std": float(np.std(rewards, ddof=1)) if len(rewards) > 1 else 0.0,
                "values": [float(r) for r in rewards],
            },
            "leakage_rate": {
                "mean": float(np.mean(leakage)),
                "std": float(np.std(leakage, ddof=1)) if len(leakage) > 1 else 0.0,
                "values": [float(v) for v in leakage],
            },
            "mean_cycle_time": {
                "mean": float(np.mean(cycles)),
                "std": float(np.std(cycles, ddof=1)) if len(cycles) > 1 else 0.0,
                "values": [float(v) for v in cycles],
            },
            "cvar_leakage_5pct": {
                "mean": float(np.mean(cvar)),
                "std": float(np.std(cvar, ddof=1)) if len(cvar) > 1 else 0.0,
                "values": [float(v) for v in cvar],
            },
            "fraud_catch_rate": {
                "mean": float(np.mean(catch)),
                "std": float(np.std(catch, ddof=1)) if len(catch) > 1 else 0.0,
                "values": [float(v) for v in catch],
            },
        },
        "per_episode": per_episode,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(
        f"[DQN seed={args.seed}] reward={out['metrics']['total_reward']['mean']:.2f}±"
        f"{out['metrics']['total_reward']['std']:.2f}  "
        f"leak={out['metrics']['leakage_rate']['mean']:.3f}  "
        f"cycle={out['metrics']['mean_cycle_time']['mean']:.2f}  "
        f"cvar={out['metrics']['cvar_leakage_5pct']['mean']:.3f}  "
        f"train={train_wall:.1f}s"
    )
    print(f"  wrote {out_path}")


if __name__ == "__main__":
    main()
