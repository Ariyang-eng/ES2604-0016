"""Gym wrappers used by the baselines.

DiscretizedActionWrapper exposes a Discrete action space whose size is
``bins ** 6`` so SB3 DQN can train on the continuous-knob env.
"""

from __future__ import annotations

import itertools

import gymnasium as gym
import numpy as np
from gymnasium import spaces


class DiscretizedActionWrapper(gym.Wrapper):
    """Wrap a Box(0,1,(6,)) action space into Discrete(bins**6).

    Each discrete index maps to a unique 6-tuple of bin centers in [0, 1].
    """

    def __init__(self, env: gym.Env, bins: int = 2) -> None:
        super().__init__(env)
        assert env.action_space.shape == (6,), "Expected 6-D Box action"
        self.bins = bins
        # Bin centers: e.g. bins=2 -> [0.25, 0.75]; bins=3 -> [0.166, 0.5, 0.833]
        self._centers = np.array(
            [(i + 0.5) / bins for i in range(bins)], dtype=np.float32
        )
        # Pre-build lookup: index -> 6-vector
        combos = list(itertools.product(range(bins), repeat=6))
        self._lookup = np.array(
            [[self._centers[c] for c in combo] for combo in combos],
            dtype=np.float32,
        )
        self.action_space = spaces.Discrete(len(combos))

    def step(self, action):
        cont = self._lookup[int(action)]
        return self.env.step(cont)


class NoSocialObservationWrapper(gym.ObservationWrapper):
    """Zero out social-signal features (indices 14-18) for B9 SAC-NoSocial.

    obs[14] = perceived_audit_intensity
    obs[15] = reviewer_fatigue_index
    obs[16] = reviewer_strictness_drift
    obs[17] = split_rate_7d
    obs[18] = appeal_rate_7d
    """

    SOCIAL_INDICES = slice(14, 19)

    def __init__(self, env: gym.Env) -> None:
        super().__init__(env)
        self.observation_space = env.observation_space  # unchanged shape

    def observation(self, obs):
        obs = obs.copy()
        obs[self.SOCIAL_INDICES] = 0.0
        return obs


class NoRiskRewardWrapper(gym.RewardWrapper):
    """Remove CVaR penalty from reward for B10 SAC-NoRisk ablation.

    Multiplies the CVaR component of the last step's reward by 0,
    then re-runs compute_reward by patching w_cvar=0 in the env config.
    """

    def __init__(self, env: gym.Env) -> None:
        super().__init__(env)
        self.unwrapped.config.reward_weights["w_cvar"] = 0.0

    def reward(self, reward):
        return reward
