"""Scenario configuration loader for ReimburseSim-CPSS."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


@dataclass
class StressEvent:
    type: str
    trigger_day: int
    duration: int
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class ScenarioConfig:
    scenario_name: str = "default_quarter"
    episode_length: int = 60
    num_departments: int = 5
    num_applicants: int = 200
    num_reviewers: int = 10
    num_managers: int = 2

    applicant_mix: dict[str, float] = field(
        default_factory=lambda: {
            "honest": 0.60,
            "careless": 0.15,
            "strategic_prober": 0.10,
            "opportunistic_splitter": 0.10,
            "fraudulent_burst": 0.05,
        }
    )
    reviewer_mix: dict[str, float] = field(
        default_factory=lambda: {
            "diligent": 0.40,
            "rubber_stamper": 0.20,
            "risk_averse_escalator": 0.25,
            "adaptive": 0.15,
        }
    )

    budget_per_dept: float = 500_000.0
    claim_rate_per_applicant: float = 0.3

    stress_events: list[StressEvent] = field(default_factory=list)

    reward_weights: dict[str, float] = field(
        default_factory=lambda: {
            "w_leak": 1.0,
            "w_cost": 0.3,
            "w_cycle": 0.5,
            "w_fa": 0.2,
            "w_appeal": 0.4,
            "w_morale": 0.2,
            "w_cvar": 0.8,
            "w_throughput": 0.3,
        }
    )

    # Adaptation switch for ablation (M0=False sanity, M3=True killer test)
    enable_social_adaptation: bool = True
    cvar_alpha: float = 0.05
    cvar_buffer_size: int = 20

    random_seed: int | None = None

    def __post_init__(self) -> None:
        # Validate mixes sum to ~1
        for name, mix in [("applicant_mix", self.applicant_mix), ("reviewer_mix", self.reviewer_mix)]:
            total = sum(mix.values())
            if abs(total - 1.0) > 1e-3:
                raise ValueError(f"{name} sums to {total}, expected 1.0")

        # Convert stress_events dicts to dataclasses
        self.stress_events = [
            ev if isinstance(ev, StressEvent) else StressEvent(**ev)
            for ev in self.stress_events
        ]


def load_scenario(path: str | Path) -> ScenarioConfig:
    """Load scenario YAML into ScenarioConfig."""
    path = Path(path)
    with path.open("r", encoding="utf-8") as f:
        data = yaml.safe_load(f)
    # Convert nested stress events
    if "stress_events" in data and data["stress_events"]:
        data["stress_events"] = [StressEvent(**ev) for ev in data["stress_events"]]
    return ScenarioConfig(**data)
