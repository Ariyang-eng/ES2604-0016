"""Data models for ReimburseSim entities."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class ClaimStatus(str, Enum):
    PENDING = "pending"
    UNDER_REVIEW = "under_review"
    APPROVED = "approved"
    REJECTED = "rejected"
    ESCALATED = "escalated"
    APPEALED = "appealed"


class ApplicantType(str, Enum):
    HONEST = "honest"
    CARELESS = "careless"
    STRATEGIC_PROBER = "strategic_prober"
    OPPORTUNISTIC_SPLITTER = "opportunistic_splitter"
    FRAUDULENT_BURST = "fraudulent_burst"


class ReviewerType(str, Enum):
    DILIGENT = "diligent"
    RUBBER_STAMPER = "rubber_stamper"
    RISK_AVERSE_ESCALATOR = "risk_averse_escalator"
    ADAPTIVE = "adaptive"


class CategoryType(str, Enum):
    MEAL = "meal"
    TRAVEL = "travel"
    OFFICE = "office"
    EQUIPMENT = "equipment"
    OTHER = "other"


@dataclass
class Claim:
    claim_id: int
    applicant_id: int
    amount: float
    category: CategoryType
    department: int
    submit_day: int
    risk_score: float = 0.0
    is_fraudulent: bool = False  # ground truth, hidden from policy
    is_split: bool = False
    original_amount: float | None = None
    status: ClaimStatus = ClaimStatus.PENDING
    assigned_reviewer: int | None = None
    resolution_day: int | None = None
    audit_selected: bool = False
    appealed: bool = False
    # Day the claim was first enqueued to a reviewer / escalated. Used to enforce
    # a minimum 1-day processing delay so cycle times reflect the multi-stage
    # lifecycle described in the spec.
    enqueue_day: int | None = None
    escalate_day: int | None = None
    sla_breach_recorded: bool = False  # avoid double-counting in _sla_step


@dataclass
class Department:
    dept_id: int
    budget_total: float
    budget_remaining: float
    headcount: int
    fraud_base_rate: float = 0.05


@dataclass
class Manager:
    manager_id: int
    escalation_queue: list[int] = field(default_factory=list)  # claim ids
    approval_quality: float = 0.85
    pressure_level: float = 0.0
    daily_capacity: int = 30


# Action knob constants (decode [0,1] -> physical range)
ACTION_RANGES = {
    "random_audit_ratio": (0.05, 0.50),
    "targeted_audit_weight": (0.0, 1.0),
    "risk_threshold": (0.3, 0.9),
    "auto_approval_prob": (0.0, 0.8),
    "escalation_intensity": (0.0, 1.0),
    "reviewer_load_temperature": (0.1, 2.0),
}
ACTION_KEYS = list(ACTION_RANGES.keys())


def decode_action(action_vec) -> dict[str, float]:
    """Decode [0,1]^6 action vector to named knob values."""
    knobs: dict[str, float] = {}
    for i, key in enumerate(ACTION_KEYS):
        lo, hi = ACTION_RANGES[key]
        a = float(action_vec[i])
        a = max(0.0, min(1.0, a))
        knobs[key] = lo + a * (hi - lo)
    return knobs


# Risk model weights (per spec)
RISK_WEIGHTS = {
    "amount_percentile": 0.25,
    "category_risk": 0.15,
    "applicant_history": 0.20,
    "split_indicator": 0.15,
    "timing_anomaly": 0.10,
    "dept_fraud_rate": 0.15,
}

CATEGORY_RISK = {
    CategoryType.MEAL: 0.2,
    CategoryType.TRAVEL: 0.5,
    CategoryType.OFFICE: 0.3,
    CategoryType.EQUIPMENT: 0.7,
    CategoryType.OTHER: 0.6,
}

# Default policy parameters
DEFAULT_POLICY = {
    "max_single_claim": 5000.0,
    "auto_approve_ceiling": 500.0,
    "sla_days": 3,
    "sla_hard_limit": 5,
    "appeal_window": 3,
    "repeat_claim_cooldown": 2,
}
