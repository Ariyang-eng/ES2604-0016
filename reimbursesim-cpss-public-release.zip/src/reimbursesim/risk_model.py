"""Risk scoring model for ReimburseSim claims."""

from __future__ import annotations

from collections import defaultdict

import numpy as np

from reimbursesim.models import (
    CATEGORY_RISK,
    Claim,
    Department,
    RISK_WEIGHTS,
)


class RiskModel:
    """Computes risk_score in [0, 1] for each new claim.

    Statefully tracks per-applicant history and amount distribution
    so the score reflects context, not just the single claim.
    """

    def __init__(self, departments: dict[int, Department]) -> None:
        self.departments = departments
        self.applicant_recent_rejections: dict[int, int] = defaultdict(int)
        self.applicant_recent_claims: dict[int, int] = defaultdict(int)
        # Day of last rejection per applicant — used for time-based decay
        self.applicant_last_rejection_day: dict[int, int] = {}
        self.recent_amounts: list[float] = []
        self.amount_window = 200

    def update_amount_window(self, amount: float) -> None:
        self.recent_amounts.append(float(amount))
        if len(self.recent_amounts) > self.amount_window:
            self.recent_amounts.pop(0)

    def amount_percentile(self, amount: float) -> float:
        if not self.recent_amounts:
            return 0.5
        return float((np.array(self.recent_amounts) < amount).mean())

    def score(self, claim: Claim, rng: np.random.Generator) -> float:
        amt_p = self.amount_percentile(claim.amount)
        cat_r = CATEGORY_RISK[claim.category]
        history = min(1.0, self.applicant_recent_rejections[claim.applicant_id] / 5.0)
        split = 1.0 if claim.is_split else 0.0
        # timing_anomaly: rough proxy via recent submission frequency
        timing = min(1.0, self.applicant_recent_claims[claim.applicant_id] / 10.0)
        dept = self.departments.get(claim.department)
        dept_rate = dept.fraud_base_rate if dept else 0.05
        noise = float(rng.normal(0.0, 0.05))

        score = (
            RISK_WEIGHTS["amount_percentile"] * amt_p
            + RISK_WEIGHTS["category_risk"] * cat_r
            + RISK_WEIGHTS["applicant_history"] * history
            + RISK_WEIGHTS["split_indicator"] * split
            + RISK_WEIGHTS["timing_anomaly"] * timing
            + RISK_WEIGHTS["dept_fraud_rate"] * (dept_rate / 0.2)  # normalize
            + noise
        )
        # Update windows
        self.update_amount_window(claim.amount)
        self.applicant_recent_claims[claim.applicant_id] += 1
        return float(np.clip(score, 0.0, 1.0))

    def record_outcome(self, claim: Claim, was_rejected: bool, day: int) -> None:
        if was_rejected:
            self.applicant_recent_rejections[claim.applicant_id] += 1
            self.applicant_last_rejection_day[claim.applicant_id] = day

    def daily_decay(self, day: int | None = None) -> None:
        """Time-based decay: claim count decays by 1/step, rejections decay if
        last rejection was >5 days ago."""
        for k in list(self.applicant_recent_claims.keys()):
            self.applicant_recent_claims[k] = max(
                0, self.applicant_recent_claims[k] - 1
            )
        if day is None:
            return
        for k, last_day in list(self.applicant_last_rejection_day.items()):
            if day - last_day >= 5 and self.applicant_recent_rejections.get(k, 0) > 0:
                self.applicant_recent_rejections[k] = max(
                    0, self.applicant_recent_rejections[k] - 1
                )
                # Reset clock if fully decayed
                if self.applicant_recent_rejections[k] == 0:
                    self.applicant_last_rejection_day.pop(k, None)
                else:
                    self.applicant_last_rejection_day[k] = day
