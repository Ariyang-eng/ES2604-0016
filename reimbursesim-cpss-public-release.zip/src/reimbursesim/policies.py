"""Hand-coded policies for M1 baselines.

These are NOT learned. They produce a 6-dim action vector each step.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


# Spec-aligned default knob values (encoded into [0,1] using ACTION_RANGES inverse)
# B1 Fixed Rule defaults from BASELINE_MATRIX.md
B1_KNOBS = {
    "random_audit_ratio": 0.15,   # decoded from [0.05, 0.50]
    "targeted_audit_weight": 0.5, # [0,1]
    "risk_threshold": 0.6,        # [0.3, 0.9]
    "auto_approval_prob": 0.3,    # [0, 0.8]
    "escalation_intensity": 0.2,  # [0,1]
    "reviewer_load_temperature": 1.0,  # [0.1, 2.0]
}

ACTION_KEYS_LOCAL = [
    "random_audit_ratio",
    "targeted_audit_weight",
    "risk_threshold",
    "auto_approval_prob",
    "escalation_intensity",
    "reviewer_load_temperature",
]
ACTION_RANGES_LOCAL = {
    "random_audit_ratio": (0.05, 0.50),
    "targeted_audit_weight": (0.0, 1.0),
    "risk_threshold": (0.3, 0.9),
    "auto_approval_prob": (0.0, 0.8),
    "escalation_intensity": (0.0, 1.0),
    "reviewer_load_temperature": (0.1, 2.0),
}


def encode_knobs(knobs: dict[str, float]) -> np.ndarray:
    """Inverse of decode_action: convert physical knob values to [0,1]^6."""
    a = np.zeros(6, dtype=np.float32)
    for i, key in enumerate(ACTION_KEYS_LOCAL):
        lo, hi = ACTION_RANGES_LOCAL[key]
        a[i] = float(np.clip((knobs[key] - lo) / (hi - lo), 0.0, 1.0))
    return a


@dataclass
class FixedRulePolicy:
    """B1: static knobs from BASELINE_MATRIX.md."""

    name: str = "fixed_rule"

    def reset(self, seed: int | None = None) -> None:  # noqa: ARG002
        pass

    def act(self, obs: np.ndarray) -> np.ndarray:  # noqa: ARG002
        return encode_knobs(B1_KNOBS)


@dataclass
class RandomPolicy:
    """B3: uniform random over the 6-dim action space."""

    name: str = "random"
    rng: np.random.Generator | None = None

    def reset(self, seed: int | None = None) -> None:
        self.rng = np.random.default_rng(seed)

    def act(self, obs: np.ndarray) -> np.ndarray:  # noqa: ARG002
        if self.rng is None:
            self.rng = np.random.default_rng()
        return self.rng.uniform(0.0, 1.0, size=6).astype(np.float32)


@dataclass
class RiskThresholdPolicy:
    """B2: reactive rule policy that adjusts knobs based on observed signals.

    Uses observation indices defined in metrics.build_observation:
        obs[19] = recent_leakage_7d
        obs[2]  = reviewer_utilization
        obs[7]  = fraud_risk_score_mean
    """

    name: str = "risk_threshold"
    base: dict[str, float] = field(default_factory=lambda: dict(B1_KNOBS))

    def reset(self, seed: int | None = None) -> None:  # noqa: ARG002
        pass

    def act(self, obs: np.ndarray) -> np.ndarray:
        knobs = dict(self.base)
        # If recent leakage > 0.2 -> raise random_audit_ratio by 0.05
        if float(obs[19]) > 0.2:
            knobs["random_audit_ratio"] = min(0.50, knobs["random_audit_ratio"] + 0.05)
        # If reviewer_utilization > 0.85 -> drop escalation_intensity by 0.1
        if float(obs[2]) > 0.85:
            knobs["escalation_intensity"] = max(0.0, knobs["escalation_intensity"] - 0.1)
        # If avg risk score > 0.5 -> drop risk_threshold by 0.05
        if float(obs[7]) > 0.5:
            knobs["risk_threshold"] = max(0.30, knobs["risk_threshold"] - 0.05)
        return encode_knobs(knobs)
