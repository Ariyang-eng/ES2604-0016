"""Applicant agent behaviors (5 types) for ReimburseSim-CPSS.

All applicants follow the same interface:
    generate_claims(day, knobs, rng) -> list[Claim]
    adapt(observed_outcomes, day, perceived_signals) -> None

Adaptation is gated by ``enable_adaptation`` so the same code path runs in
both static (M0/M1) and adaptive (M3) modes.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any

import numpy as np

from reimbursesim.models import (
    ApplicantType,
    CategoryType,
    Claim,
    ClaimStatus,
)

CATEGORY_LIST = list(CategoryType)


@dataclass
class Applicant:
    applicant_id: int
    department: int
    type: ApplicantType
    submission_rate: float = 0.3  # Poisson lambda

    # Adaptive state
    perceived_audit_intensity: float = 0.5
    consecutive_approvals: int = 0
    consecutive_rejections: int = 0
    perceived_threshold: float = 1000.0  # for strategic prober
    days_since_burst: int = 0
    pending_split_remainders: list[float] = field(default_factory=list)

    # Toggle: when False, ``adapt`` is a no-op (M0/M1 sanity & ablation A1)
    enable_adaptation: bool = True

    # Tracking
    recent_outcomes: list[bool] = field(default_factory=list)  # True=approved

    def _sample_amount(self, rng: np.random.Generator, multiplier: float = 1.0) -> float:
        """Default amount distribution: LogNormal(mu=6.0, sigma=0.8) (median ~400 CNY)."""
        return float(np.exp(rng.normal(6.0, 0.8)) * multiplier)

    def _sample_category(self, rng: np.random.Generator) -> CategoryType:
        # Honest distribution skewed to meal/office
        probs = np.array([0.35, 0.20, 0.25, 0.10, 0.10])
        return CATEGORY_LIST[int(rng.choice(len(CATEGORY_LIST), p=probs))]

    def generate_claims(
        self,
        day: int,
        knobs: dict[str, float],
        rng: np.random.Generator,
        next_claim_id: int,
    ) -> list[Claim]:
        """Dispatch to type-specific generator."""
        if self.type == ApplicantType.HONEST:
            return self._gen_honest(day, rng, next_claim_id)
        if self.type == ApplicantType.CARELESS:
            return self._gen_careless(day, rng, next_claim_id)
        if self.type == ApplicantType.STRATEGIC_PROBER:
            return self._gen_strategic(day, knobs, rng, next_claim_id)
        if self.type == ApplicantType.OPPORTUNISTIC_SPLITTER:
            return self._gen_splitter(day, knobs, rng, next_claim_id)
        if self.type == ApplicantType.FRAUDULENT_BURST:
            return self._gen_burst(day, knobs, rng, next_claim_id)
        return []

    # ----- Type-specific generators ------------------------------------

    def _gen_honest(self, day: int, rng: np.random.Generator, nid: int) -> list[Claim]:
        n = rng.poisson(self.submission_rate)
        claims = []
        for i in range(int(n)):
            claims.append(
                Claim(
                    claim_id=nid + i,
                    applicant_id=self.applicant_id,
                    amount=self._sample_amount(rng),
                    category=self._sample_category(rng),
                    department=self.department,
                    submit_day=day,
                    is_fraudulent=False,
                )
            )
        return claims

    def _gen_careless(self, day: int, rng: np.random.Generator, nid: int) -> list[Claim]:
        # Mostly legitimate but error_rate=0.15
        n = rng.poisson(self.submission_rate)
        claims = []
        # adaptive: after rejection, error_rate halved for 5 claims
        recent_rej = sum(1 for o in self.recent_outcomes[-5:] if not o)
        error_rate = 0.075 if (recent_rej > 0 and self.enable_adaptation) else 0.15
        for i in range(int(n)):
            is_err = rng.random() < error_rate
            amount = self._sample_amount(rng, multiplier=1.5 if is_err else 1.0)
            claims.append(
                Claim(
                    claim_id=nid + i,
                    applicant_id=self.applicant_id,
                    amount=amount,
                    category=self._sample_category(rng),
                    department=self.department,
                    submit_day=day,
                    # "errors" are not fraud but trigger rejections / false alarms
                    is_fraudulent=False,
                )
            )
        return claims

    def _gen_strategic(
        self, day: int, knobs: dict[str, float], rng: np.random.Generator, nid: int
    ) -> list[Claim]:
        n = rng.poisson(self.submission_rate)
        claims = []
        # NOTE: enable_adaptation only freezes perceived_threshold updates (in adapt()).
        # The strategic probing behaviour itself remains — otherwise the social-ablation
        # would also remove all fraud, conflating two effects.
        for i in range(int(n)):
            # Backoff after recent rejection
            if self.consecutive_rejections > 0 and i < 3:
                target = self.perceived_threshold * 0.8
            else:
                # Probe at 90-110% of perceived threshold
                target = self.perceived_threshold * float(rng.uniform(0.9, 1.1))
            amount = max(50.0, target * float(rng.uniform(0.85, 1.05)))
            # Inflated -> count as fraudulent with prob 0.3
            is_fraud = rng.random() < 0.3
            claims.append(
                Claim(
                    claim_id=nid + i,
                    applicant_id=self.applicant_id,
                    amount=amount,
                    category=self._sample_category(rng),
                    department=self.department,
                    submit_day=day,
                    is_fraudulent=is_fraud,
                )
            )
        return claims

    def _gen_splitter(
        self, day: int, knobs: dict[str, float], rng: np.random.Generator, nid: int
    ) -> list[Claim]:
        claims = []
        # Emit pending split remainders first
        next_nid = nid
        while self.pending_split_remainders:
            amount = self.pending_split_remainders.pop(0)
            claims.append(
                Claim(
                    claim_id=next_nid,
                    applicant_id=self.applicant_id,
                    amount=amount,
                    category=self._sample_category(rng),
                    department=self.department,
                    submit_day=day,
                    is_split=True,
                    is_fraudulent=True,
                )
            )
            next_nid += 1
            if rng.random() > 0.6:  # spread across days
                break

        n = rng.poisson(self.submission_rate)
        for i in range(int(n)):
            # Splitter always splits when its frozen perceived_audit_intensity supports it.
            # When enable_adaptation=False, perceived_audit_intensity stays at the initial
            # value (0.5), so split_prob = sigmoid(0) = 0.5 -- splitters still attack but
            # do not adapt the rate to the policy.
            split_prob = 1.0 / (1.0 + math.exp((self.perceived_audit_intensity - 0.5) * 6.0))
            do_split = rng.random() < split_prob
            if do_split:
                original = float(np.exp(rng.normal(8.0, 0.5)))  # ~3000 CNY
                pieces = int(rng.integers(2, 5))
                shares = rng.dirichlet(np.ones(pieces)) * original
                # First piece this day, rest queued
                first = float(shares[0])
                for s in shares[1:]:
                    self.pending_split_remainders.append(float(s))
                claims.append(
                    Claim(
                        claim_id=next_nid,
                        applicant_id=self.applicant_id,
                        amount=first,
                        category=self._sample_category(rng),
                        department=self.department,
                        submit_day=day,
                        is_split=True,
                        original_amount=original,
                        is_fraudulent=True,  # policy violation
                    )
                )
                next_nid += 1
            else:
                claims.append(
                    Claim(
                        claim_id=next_nid,
                        applicant_id=self.applicant_id,
                        amount=self._sample_amount(rng),
                        category=self._sample_category(rng),
                        department=self.department,
                        submit_day=day,
                        is_fraudulent=False,
                    )
                )
                next_nid += 1
        return claims

    def _gen_burst(
        self, day: int, knobs: dict[str, float], rng: np.random.Generator, nid: int
    ) -> list[Claim]:
        claims = []
        # Adaptive ON: reactive burst (low audit -> burst, high audit -> dormant).
        # Adaptive OFF: deterministic schedule (every ~20 days) so the population still
        # contains fraudulent burst events, but they no longer respond to policy.
        if self.enable_adaptation:
            burst_now = (
                self.perceived_audit_intensity < 0.4
                and self.consecutive_approvals > 2
                and self.days_since_burst > 7
            )
        else:
            burst_now = self.days_since_burst >= 20
        if burst_now:
            n = int(rng.integers(3, 6))
            multiplier = float(rng.uniform(3.0, 10.0))
            for i in range(n):
                claims.append(
                    Claim(
                        claim_id=nid + i,
                        applicant_id=self.applicant_id,
                        amount=self._sample_amount(rng, multiplier=multiplier),
                        category=self._sample_category(rng),
                        department=self.department,
                        submit_day=day,
                        is_fraudulent=True,
                    )
                )
            self.days_since_burst = 0
        else:
            n = rng.poisson(self.submission_rate * 0.5)
            for i in range(int(n)):
                claims.append(
                    Claim(
                        claim_id=nid + i,
                        applicant_id=self.applicant_id,
                        amount=self._sample_amount(rng),
                        category=self._sample_category(rng),
                        department=self.department,
                        submit_day=day,
                        is_fraudulent=False,
                    )
                )
        self.days_since_burst += 1
        return claims

    # ----- Adaptation --------------------------------------------------

    def update_outcome(self, claim: Claim) -> None:
        """Record claim resolution."""
        approved = claim.status == ClaimStatus.APPROVED
        self.recent_outcomes.append(approved)
        if len(self.recent_outcomes) > 20:
            self.recent_outcomes.pop(0)
        if approved:
            self.consecutive_approvals += 1
            self.consecutive_rejections = 0
        else:
            self.consecutive_rejections += 1
            self.consecutive_approvals = 0
            # strategic prober updates threshold downward
            if self.type == ApplicantType.STRATEGIC_PROBER and self.enable_adaptation:
                self.perceived_threshold *= 0.85

    def adapt(
        self,
        day: int,
        global_audit_intensity: float,
        max_approved_amount_recent: float,
    ) -> None:
        """Update perceived audit intensity and threshold (called daily)."""
        if not self.enable_adaptation:
            return
        # EMA update of perceived audit intensity (alpha=0.4 for faster adaptation)
        self.perceived_audit_intensity = (
            0.6 * self.perceived_audit_intensity + 0.4 * global_audit_intensity
        )
        # strategic prober updates perceived threshold every 5 days
        if (
            self.type == ApplicantType.STRATEGIC_PROBER
            and day % 5 == 0
            and max_approved_amount_recent > 0
        ):
            self.perceived_threshold = (
                0.7 * self.perceived_threshold + 0.3 * max_approved_amount_recent
            )
