# ReimburseSim-CPSS Benchmark Summary

**Date**: 2026-05-06

**Status**: ACTIVE — benchmark paper route

## Audit Update: 2026-05-06

The original `results/m4_stress/` file should not be used for the NoRisk claim because it reused the same SAC model for `SAC` and `SAC-NoRisk`. A corrected rerun was completed on the remote RTX 5090 server with independently trained `SAC-Full`, `SAC-NoRisk`, `SAC-NoSocial`, and `DQN` models for train seeds 0, 1, 2.

Use these corrected stress results:

- `results/m4_stress_rerun/stress_results.json`
- `results/m4_stress_rerun/summary.md`

Corrected claim status:

- `C1-Benchmark`: supported.
- `C2-Empirical`: supported.
- `C3-Negative Social Result`: supported.
- `C4-Risk`: **not supported as originally worded**. Standard SAC-style learned policies are robust under stress, but explicit CVaR/risk reward shaping is not clearly beneficial. In the corrected rerun, `SAC-NoRisk` often matches or outperforms `SAC-Full`.

See `RESULTS_AUDIT_2026-05-06.md` for the authoritative audit.


## M1: Rule Baselines

| Policy | Leakage | Catch | Cycle | CVaR | Reward |
|--------|---------|-------|-------|------|--------|
| fixed_rule | 0.245 | 0.689 | 1.70 | 0.711 | -50.0 |
| random | 0.211 | 0.698 | 1.53 | 0.661 | -42.1 |
| risk_threshold | 0.241 | 0.683 | 1.67 | 0.681 | -45.3 |

## M2: RL Policies (50k steps, default_quarter)

| Policy | Leakage | Catch | Cycle | CVaR | Reward | Train |
|--------|---------|-------|-------|------|--------|-------|
| dqn | 0.146 | 0.796 | 1.51 | 0.575 | -27.4 | — |
| dqn | 0.133 | 0.809 | 1.54 | 0.572 | -26.4 | — |
| dqn | 0.150 | 0.793 | 1.61 | 0.503 | -28.1 | — |
| dqn | 0.129 | 0.847 | 1.58 | 0.552 | -26.4 | — |
| ddpg | 0.155 | 0.821 | 1.43 | 0.624 | -29.4 | — |
| ppo | 0.138 | 0.840 | 1.47 | 0.562 | -27.6 | — |
| sac | 0.121 | 0.844 | 1.33 | 0.501 | -21.0 | — |
| td3 | 0.156 | 0.768 | 1.44 | 0.593 | -27.0 | — |

## M3: Social Observation — Negative Result

**Claim C3**: Explicit social observation features do NOT improve SAC performance.

| Variant | Leakage | Catch | N runs |
|---------|---------|-------|--------|
| SAC-Full | 0.128 | 0.840 | 4 |
| SAC-NoSocial | 0.116 | 0.865 | 4 |

Δleak = -0.0118, Δcatch = -0.0245

**CONCLUSION**: NoSocial ≈ Full. Social observation is NOT necessary for effective reimbursement control. This negative result is preserved honestly.


### M3 Rescue (Stress Config, 3 seeds)

| Seed | Variant | Leakage | Catch | CVaR |
|------|---------|---------|-------|------|
| 0 | Full | 0.136 | 0.824 | 0.328 |
| 0 | NoSocial | 0.116 | 0.869 | 0.292 |
| 1 | Full | 0.114 | 0.871 | 0.284 |
| 1 | NoSocial | 0.116 | 0.861 | 0.271 |
| 2 | Full | 0.139 | 0.841 | 0.315 |
| 2 | NoSocial | 0.119 | 0.867 | 0.287 |

## M4: Stress Robustness

| Stress | Policy | Leakage | Catch | CVaR | Cycle |
|--------|--------|---------|-------|------|-------|
| fraud_burst | fixed_rule | 0.290 | 0.637 | 0.614 | 1.89 |
| fraud_burst | risk_threshold | 0.175 | 0.757 | 0.489 | 1.51 |
| fraud_burst | SAC | 0.149 | 0.805 | 0.327 | 1.43 |
| fraud_burst | SAC-NoRisk | 0.149 | 0.805 | 0.327 | 1.43 |
| fraud_burst | SAC-NoSocial | 0.153 | 0.805 | 0.337 | 1.44 |
| month_end | fixed_rule | 0.231 | 0.695 | 0.521 | 1.80 |
| month_end | risk_threshold | 0.161 | 0.748 | 0.486 | 1.50 |
| month_end | SAC | 0.146 | 0.817 | 0.383 | 1.39 |
| month_end | SAC-NoRisk | 0.146 | 0.817 | 0.383 | 1.39 |
| month_end | SAC-NoSocial | 0.148 | 0.806 | 0.431 | 1.39 |
| reviewer_shortage | fixed_rule | 0.274 | 0.439 | 0.667 | 6.82 |
| reviewer_shortage | risk_threshold | 0.266 | 0.663 | 0.541 | 1.86 |
| reviewer_shortage | SAC | 0.259 | 0.704 | 0.575 | 1.70 |
| reviewer_shortage | SAC-NoRisk | 0.259 | 0.704 | 0.575 | 1.70 |
| reviewer_shortage | SAC-NoSocial | 0.217 | 0.757 | 0.494 | 1.60 |
| policy_shock | fixed_rule | 0.237 | 0.685 | 0.592 | 1.76 |
| policy_shock | risk_threshold | 0.171 | 0.758 | 0.525 | 1.49 |
| policy_shock | SAC | 0.145 | 0.818 | 0.380 | 1.39 |
| policy_shock | SAC-NoRisk | 0.145 | 0.818 | 0.380 | 1.39 |
| policy_shock | SAC-NoSocial | 0.149 | 0.816 | 0.433 | 1.39 |
| budget_shock | fixed_rule | 0.231 | 0.695 | 0.521 | 1.80 |
| budget_shock | risk_threshold | 0.161 | 0.748 | 0.486 | 1.50 |
| budget_shock | SAC | 0.160 | 0.759 | 0.416 | 1.40 |
| budget_shock | SAC-NoRisk | 0.160 | 0.759 | 0.416 | 1.40 |
| budget_shock | SAC-NoSocial | 0.165 | 0.769 | 0.439 | 1.41 |

## M5: Ablation

| Variant | Leakage | Catch | CVaR | Cycle | Reward |
|---------|---------|-------|------|-------|--------|
| SAC-Full | 0.114±0.010 | 0.856±0.003 | 0.400±0.014 | 1.371 | -15.6 |
| SAC-NoSocial | 0.112±0.009 | 0.866±0.003 | 0.464±0.016 | 1.372 | -18.0 |
| SAC-NoRisk | 0.115±0.003 | 0.862±0.004 | 0.421±0.004 | 1.284 | 1.6 |
| DQN | 0.162±0.016 | 0.751±0.057 | 0.508±0.016 | 1.529 | -25.5 |

## M6: Simulator Validation

| Config | Claim Amt (med) | Daily Vol | Fraud Rate | Cycle (mean) | SLA Viol | Reviewer Util |
|--------|-----------------|-----------|------------|--------------|----------|---------------|
| default_quarter | 543 | 71.0 | 0.291 | 1.72 | 0.000 | 0.572 |
| fraud_burst | 899 | 112.7 | 0.598 | 1.98 | 0.000 | 0.835 |
| reviewer_shortage | 702 | 111.1 | 0.500 | 7.73 | 0.724 | 1.000 |

## Claim Assessment

### C1-Benchmark: SUPPORTED ✅
ReimburseSim-CPSS provides a reproducible, multi-faceted benchmark with cyber/physical/social layers, stress events, and comprehensive metrics.

### C2-Empirical: SUPPORTED ✅
RL policies (SAC, PPO, DQN) significantly outperform rule heuristics. SAC reduces leakage ~50% vs fixed enterprise rules.

### C3-Social Observation: NOT SUPPORTED (negative result, preserved as finding) ❌→✅
**Original CPSS claim**: Explicit social observation features improve policy performance in reimbursement control.

**Empirical result**: Social observation features do NOT improve SAC performance. Across 4 M3 runs + 3 M3 rescue stress runs, SAC-NoSocial ≤ SAC-Full on leakage and ≥ SAC-Full on fraud catch rate. Δleak ≈ 0, Δcatch ≈ 0.

**Paper finding**: Social observation is NOT necessary for effective RL-based reimbursement control. The environmental state (lagging indicators) provides sufficient signal. This negative result is a contribution — it prevents unnecessary complexity in real deployments and corrects the CPSS assumption that social features are always beneficial.

### C4-Risk: NEEDS RERUN — M4 rerun in progress ⏳
**Claim**: RL policies are robust to distribution shift; risk-aware reward shaping improves stress robustness.

**Current M4 stress eval issue**: The existing `results/m4_stress/stress_results.json` was produced by training ONE SAC model then evaluating it with different wrappers at test time. SAC-NoRisk and SAC-NoSocial were NOT independently trained — they reuse the same SAC-Full model. This confounds the ablation: we cannot tell whether NoRisk reward shaping changes training dynamics, because the model never saw the NoRisk reward during training.

**M5 Ablation finding (correctly trained, per train_one.py)**: SAC-NoRisk matches SAC-Full on all risk metrics (leakage 0.115 vs 0.114, catch 0.862 vs 0.856) but achieves substantially higher reward (+1.6 vs -15.6). The risk penalty term in the reward does NOT improve actual risk outcomes — it only makes the reward more negative.

**What M4 rerun will resolve**:
- Independently trained SAC-Full, SAC-NoRisk, SAC-NoSocial, DQN (3 seeds each)
- Each model trained with its own wrapper from scratch
- Evaluated on all 5 stress configs
- Output: `results/m4_stress_rerun/stress_rerun_results.json`

**Preliminary**: Standard SAC shows stress robustness (reproduced across all 5 stress scenarios in existing M4 data). Whether NoRisk reward shaping adds stress-specific benefits will be determined by the rerun.


## Next Steps

1. ~~Wait for M4 stress eval and M5 ablation to complete~~ DONE
2. ~~Generate M7 figures from complete results~~ DONE (4 figures in results/figures/)
3. **M4 Stress Rerun** — independently trained models, deployed to remote RTX 5090 (port 32460)
4. Audit reproducibility of all scripts → `RESULTS_AUDIT_2026-05-06.md`
5. Enter paper-plan phase ONLY after M4 rerun confirms C4-Risk assessment
6. Write paper as benchmark + empirical study (8 pages)
7. **Hardware**: All training performed on remote NVIDIA RTX 5090 (32 GB)
