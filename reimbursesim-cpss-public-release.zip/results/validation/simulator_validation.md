# M6 Simulator Validation

## default_quarter

- Claim amount: mean=1064, median=543, std=1429, p95=4183, max=29780
- Daily volume: mean=71.0, max=100
- Fraud rate: 0.291
- Cycle time: mean=1.72, p95=3.0, max=4
- Leakage: mean=0.2344 ± 0.0361
- Reviewer util: mean=0.572, max=0.728
- SLA violation: 0.0000

## fraud_burst

- Claim amount: mean=2209, median=899, std=3077, p95=9308, max=53870
- Daily volume: mean=112.7, max=157
- Fraud rate: 0.598
- Cycle time: mean=1.98, p95=3.0, max=5
- Leakage: mean=0.2980 ± 0.0218
- Reviewer util: mean=0.835, max=0.894
- SLA violation: 0.0000

## reviewer_shortage

- Claim amount: mean=1484, median=702, std=2018, p95=6072, max=43983
- Daily volume: mean=111.1, max=145
- Fraud rate: 0.500
- Cycle time: mean=7.73, p95=25.0, max=36
- Leakage: mean=0.2185 ± 0.0433
- Reviewer util: mean=1.000, max=1.000
- SLA violation: 0.7237
