# ReimburseSim-CPSS: Simulator Specification

**Date**: 2026-05-03
**Version**: 0.1 (design spec, not yet implemented)
**Project**: ddpg_cpss_finance_reimbursement

---

## Simulator Scope

ReimburseSim-CPSS is a discrete-time, episodic simulation environment for enterprise reimbursement workflow control. It models the parallel interaction between:

- **Cyber layer**: ERP workflow engine, rule engine, risk scoring model, audit policy executor
- **Physical/Financial layer**: invoices, budgets, payment windows, SLA constraints, cash-flow
- **Social layer**: adaptive applicants, reviewers, finance staff, managers

The simulator exposes a Gymnasium-compatible interface for RL agent training and evaluation.

**Not in scope (v0.1)**: real ERP integration, natural language claim parsing, multi-currency, inter-company reimbursement, tax computation.

---

## Entities

### Claim

The atomic unit of the simulation. Each claim represents one reimbursement request.

| Field | Type | Description |
|-------|------|-------------|
| claim_id | int | Unique identifier |
| applicant_id | int | Submitting employee |
| amount | float | Claimed amount (CNY) |
| category | enum | meal/travel/office/equipment/other |
| department | int | Department ID |
| submit_day | int | Day submitted within episode |
| risk_score | float [0,1] | Computed by risk model |
| is_fraudulent | bool | Ground truth (hidden from policy) |
| is_split | bool | Whether this is part of a split claim |
| original_amount | float | Pre-split amount (if split) |
| status | enum | pending/under_review/approved/rejected/escalated/appealed |
| assigned_reviewer | int | Reviewer ID (null if unassigned) |
| resolution_day | int | Day resolved (null if pending) |
| audit_selected | bool | Whether selected for audit |

### Applicant

| Field | Type | Description |
|-------|------|-------------|
| applicant_id | int | Unique identifier |
| department | int | Department ID |
| type | enum | honest/careless/strategic_prober/opportunistic_splitter/fraudulent_burst |
| submission_rate | float | Claims per day (Poisson lambda) |
| perceived_audit_intensity | float [0,1] | Applicant's estimate of audit strictness |
| consecutive_approvals | int | Streak of approved claims |
| adaptation_state | dict | Type-specific internal state |

### Reviewer

| Field | Type | Description |
|-------|------|-------------|
| reviewer_id | int | Unique identifier |
| type | enum | diligent/rubber_stamper/risk_averse_escalator/adaptive |
| capacity | int | Max claims per day |
| current_load | int | Claims in queue |
| fatigue_level | float [0,1] | Accumulated fatigue |
| accuracy | float [0,1] | Current detection accuracy (affected by fatigue) |
| strictness | float [0,1] | Current approval threshold |
| days_overloaded | int | Consecutive days above 80% utilization |

### Department

| Field | Type | Description |
|-------|------|-------------|
| dept_id | int | Unique identifier |
| budget_total | float | Quarterly budget |
| budget_remaining | float | Remaining budget |
| headcount | int | Number of employees |
| fraud_base_rate | float | Baseline fraud probability |

### Manager

| Field | Type | Description |
|-------|------|-------------|
| manager_id | int | Unique identifier |
| escalation_queue | int | Pending escalated claims |
| approval_quality | float [0,1] | Decision accuracy (degrades under overload) |
| pressure_level | float [0,1] | Current throughput pressure |

---

## Event Lifecycle

A claim follows this lifecycle within each daily step:

```
[Submit] -> [Risk Score] -> [Route Decision] -> [Process] -> [Resolve]
```

Detailed flow:

1. **Submission**: Applicants generate claims based on type-specific behavior and adaptation state
2. **Risk Scoring**: Each claim receives risk_score = f(amount, category, dept, applicant_history, split_flag)
3. **Routing Decision** (controlled by policy action):
   - If risk_score < risk_threshold AND random() < auto_approval_prob: AUTO-APPROVE
   - If selected for random audit (prob = random_audit_ratio): AUDIT
   - If selected for targeted audit (prob = targeted_audit_weight * risk_score): AUDIT
   - Otherwise: ASSIGN to reviewer (load-balanced by reviewer_load_temperature)
4. **Review Process**:
   - Reviewer examines claim; detection depends on reviewer.accuracy and claim.is_fraudulent
   - If reviewer decides to escalate (based on type + escalation_intensity): ESCALATE to manager
   - Otherwise: APPROVE or REJECT
5. **Escalation**: Manager reviews; quality depends on manager.approval_quality
6. **Resolution**: Claim marked approved/rejected; metrics updated
7. **Appeal**: Rejected applicants may appeal (prob depends on type and perceived fairness)

---

## Applicant Types (Detailed Behavior)

### Honest (default 60%)
- Submits legitimate claims at steady rate
- Amount drawn from LogNormal(mu=6.0, sigma=0.8) (median ~400 CNY)
- No adaptation to policy changes
- Appeal probability on rejection: 0.05

### Careless (default 15%)
- Submits mostly legitimate claims but with occasional errors (missing receipts, wrong category)
- Error rate: 0.15 per claim
- After rejection: error_rate *= 0.5 for next 5 claims (temporary improvement)
- Not intentionally fraudulent; errors may trigger false alarms

### Strategic Prober (default 10%)
- Starts with small legitimate claims to establish history
- Gradually increases amount toward perceived threshold
- Adaptation: every 5 days, updates perceived_threshold = EMA(max_approved_amount, alpha=0.3)
- If rejected: backs off by 20% for 3 claims, then resumes probing
- Fraud probability: 0.3 per claim (inflated amounts, not fabricated)

### Opportunistic Splitter (default 10%)
- Splits large claims into multiple smaller ones to avoid audit
- Split decision: split_prob = sigmoid(-(perceived_audit_intensity - 0.5) * 3)
- When splitting: original claim divided into 2-4 sub-claims across consecutive days
- Each sub-claim individually legitimate but total exceeds policy limits
- Fraud probability: 0.2 (policy violation, not fabrication)

### Fraudulent Burst (default 5%)
- Mostly dormant; submits legitimate claims at low rate
- Burst trigger: perceived_audit_intensity < 0.3 AND consecutive_approvals > 3
- During burst: submits 3-5 fabricated claims over 2-3 days
- Burst amount: 3-10x normal claim size
- After burst: goes dormant for 10-20 days
- Fraud probability during burst: 1.0

---

## Reviewer Types (Detailed Behavior)

### Diligent (default 40%)
- Base accuracy: 0.90 (probability of correctly identifying fraud)
- Fatigue model: after days_overloaded > 5, accuracy -= 0.02 per additional day (floor 0.70)
- Processing speed: 8 claims/day at full accuracy, 12 claims/day with reduced accuracy
- Escalation rate: 0.10 (escalates ambiguous cases)

### Rubber-Stamper (default 20%)
- Base accuracy: 0.60
- When utilization > 0.8: approval_rate -> 0.95, accuracy -> 0.30
- Processing speed: 15 claims/day (fast but inaccurate under load)
- Escalation rate: 0.02 (rarely escalates)

### Risk-Averse Escalator (default 25%)
- Base accuracy: 0.80
- Escalation rate: 0.30 + 0.2 * recent_fraud_rate (increases when fraud is detected)
- Processing speed: 6 claims/day (slow due to caution)
- Creates escalation backlog pressure on managers

### Adaptive (default 15%)
- Base accuracy: 0.75
- Strictness adapts: strictness = EMA(manager_feedback_signal, alpha=0.2)
- If manager overturns their decisions frequently: becomes more conservative
- If manager confirms their decisions: maintains current level
- Processing speed: 10 claims/day

---

## Finance/Manager Pressure Model

### Month-End Throughput Pressure
- For day_of_month > 20: pressure = (day - 20) / 10
- Effect: managers prioritize speed over accuracy; approval_quality -= 0.1 * pressure
- Effect: implicit signal to reviewers to process faster

### Budget Tightening
- When dept.budget_remaining / dept.budget_total < 0.3:
  - approval_strictness += 0.2
  - Large claims (> 2x median) get extra scrutiny
- When budget_remaining < 0.1: emergency mode, all claims > threshold require manager approval

### Policy Shock (Exogenous)
- Triggered by scenario config at specified days
- Effect: audit_ratio forced to minimum 0.30 for shock_duration days
- Represents external compliance event (e.g., regulatory audit, fraud scandal)

### Manager Overload
- When escalation_queue > 2 * daily_capacity:
  - approval_quality -= 0.15
  - Processing delay += 1 day per 50% overload
- Creates feedback loop: more escalation -> worse manager decisions -> more appeals

---

## Reimbursement Policy Model

Default policy parameters (can be overridden by scenario config):

| Parameter | Default | Description |
|-----------|---------|-------------|
| max_single_claim | 5000 CNY | Claims above this always require review |
| auto_approve_ceiling | 500 CNY | Claims below this eligible for auto-approval |
| sla_days | 5 | Target resolution time |
| sla_hard_limit | 10 | Maximum allowed resolution time |
| appeal_window | 3 days | Time allowed to file appeal |
| category_limits | dict | Per-category daily/monthly limits |
| repeat_claim_cooldown | 2 days | Minimum days between same-category claims |

---

## Audit/Risk Model

### Risk Scoring Function

```
risk_score = w1 * amount_percentile
           + w2 * category_risk_weight
           + w3 * applicant_history_score
           + w4 * split_indicator
           + w5 * timing_anomaly
           + w6 * dept_fraud_rate
           + noise ~ N(0, 0.05)
```

Default weights: w1=0.25, w2=0.15, w3=0.20, w4=0.15, w5=0.10, w6=0.15

### Audit Selection

Two-stage audit selection per daily step:

1. **Random audit**: each non-auto-approved claim selected with prob = random_audit_ratio
2. **Targeted audit**: among remaining, select top-k by risk_score * targeted_audit_weight

Total audit capacity per day = num_reviewers * avg_capacity * audit_fraction

---

## Control Interface

The RL agent interacts with the environment through a Gymnasium-compatible API:

```python
class ReimburseSim(gymnasium.Env):
    observation_space = Box(low=0, high=1, shape=(24,))
    action_space = Box(low=0, high=1, shape=(6,))

    def reset(self, seed=None, options=None) -> tuple[obs, info]:
        # Initialize episode: reset budget, agents, queues
        # Returns initial observation and info dict

    def step(self, action) -> tuple[obs, reward, terminated, truncated, info]:
        # 1. Decode action to control knobs
        # 2. Generate new claims from applicants
        # 3. Score and route claims
        # 4. Process claims through reviewers
        # 5. Handle escalations and appeals
        # 6. Update agent adaptation states
        # 7. Compute reward and observation
        # 8. Check termination (end of quarter)

    def render(self) -> None:
        # Optional: print daily summary
```

---

## Environment Step Function (Pseudocode)

```
def step(action):
    # Decode action
    knobs = decode_action(action)  # maps [0,1]^6 to actual ranges

    # 1. Applicant behavior: generate today's claims
    for applicant in applicants:
        claims = applicant.generate_claims(day, knobs)
        claim_queue.extend(claims)

    # 2. Risk scoring
    for claim in new_claims:
        claim.risk_score = risk_model.score(claim)

    # 3. Routing
    for claim in pending_claims:
        if claim.risk_score < knobs.risk_threshold and random() < knobs.auto_approval_prob:
            auto_approve(claim)
        elif random() < knobs.random_audit_ratio:
            assign_to_audit(claim, knobs)
        elif claim.risk_score * knobs.targeted_audit_weight > targeted_threshold:
            assign_to_audit(claim, knobs)
        else:
            assign_to_reviewer(claim, knobs.reviewer_load_temperature)

    # 4. Reviewer processing
    for reviewer in reviewers:
        reviewer.process_queue(knobs.escalation_intensity)
        reviewer.update_fatigue()

    # 5. Manager processing
    for manager in managers:
        manager.process_escalations()

    # 6. Appeal processing
    process_appeals()

    # 7. Applicant adaptation
    for applicant in applicants:
        applicant.adapt(observed_outcomes)

    # 8. Reviewer adaptation
    for reviewer in reviewers:
        reviewer.adapt(manager_feedback)

    # 9. Compute metrics
    metrics = compute_daily_metrics()
    reward = compute_reward(metrics, knobs)
    obs = compute_observation()
    terminated = (day >= episode_length)

    return obs, reward, terminated, False, metrics
```

---

## Reward Function (Detailed)

```
R_t = - w_leak * (fraud_amount_missed / total_fraud_amount)
      - w_cost * (num_manual_audits / total_claims) * cost_per_audit
      - w_cycle * max(0, avg_cycle_time - sla_target) / sla_target
      - w_fa * (false_alarms / total_audits)
      - w_appeal * (appeals_filed / total_resolved)
      - w_morale * morale_penalty
      - w_cvar * CVaR_alpha(leakage_buffer)
      + w_throughput * (claims_resolved / claims_submitted)
```

Where:
- morale_penalty = 0.3 * reviewer_overload_fraction + 0.3 * false_alarm_rate + 0.4 * appeal_rate
- CVaR_alpha computed over a rolling buffer of last 20 daily leakage values
- All terms normalized to [0, 1] range before weighting

---

## Observation Schema (dim=24)

All features normalized to [0, 1].

| Index | Feature | Computation |
|-------|---------|-------------|
| 0 | pending_claims | len(pending_queue) / max_queue_size |
| 1 | avg_queue_age | mean(day - claim.submit_day for pending) / sla_hard_limit |
| 2 | reviewer_utilization | mean(reviewer.current_load / reviewer.capacity) |
| 3 | escalation_backlog | sum(manager.escalation_queue) / max_escalation |
| 4 | remaining_budget_ratio | mean(dept.budget_remaining / dept.budget_total) |
| 5 | monthly_spend_velocity | total_approved_amount_7d / (budget_total / 60 * 7) |
| 6 | cash_flow_pressure | 1 if any dept budget_remaining < 0.1 else ratio |
| 7 | fraud_risk_score_mean | mean(claim.risk_score for pending) |
| 8 | high_value_ratio | count(amount > 2*median) / total_pending |
| 9 | cross_dept_ratio | count(cross_dept_claims) / total_pending |
| 10 | repeat_offender_ratio | count(applicant with >2 rejections) / total_applicants |
| 11 | current_audit_ratio | audits_today / claims_today |
| 12 | targeted_audit_hit_rate | true_positives / targeted_audits (7d rolling) |
| 13 | false_alarm_rate_7d | false_positives / total_audits (7d rolling) |
| 14 | perceived_audit_intensity | mean(applicant.perceived_audit_intensity) |
| 15 | reviewer_fatigue_index | mean(reviewer.fatigue_level) |
| 16 | reviewer_strictness_drift | std(reviewer.strictness) |
| 17 | applicant_split_rate_7d | split_claims_7d / total_claims_7d |
| 18 | appeal_rate_7d | appeals_7d / resolutions_7d |
| 19 | recent_leakage_7d | missed_fraud_amount_7d / total_fraud_amount_7d |
| 20 | cvar_leakage_estimate | CVaR_0.05 over leakage_buffer |
| 21 | sla_violation_rate_7d | sla_violations_7d / resolutions_7d |
| 22 | policy_shock_flag | 1.0 if policy shock active, else 0.0 |
| 23 | day_of_month_normalized | day_of_month / 30 |

---

## Action Schema (dim=6)

Agent outputs a_t in [0, 1]^6. Decoded to actual ranges:

| Index | Knob | Decode | Actual Range |
|-------|------|--------|-------------|
| 0 | random_audit_ratio | 0.05 + a[0] * 0.45 | [0.05, 0.50] |
| 1 | targeted_audit_weight | a[1] | [0.0, 1.0] |
| 2 | risk_threshold | 0.3 + a[2] * 0.6 | [0.3, 0.9] |
| 3 | auto_approval_prob | a[3] * 0.8 | [0.0, 0.8] |
| 4 | escalation_intensity | a[4] | [0.0, 1.0] |
| 5 | reviewer_load_temperature | 0.1 + a[5] * 1.9 | [0.1, 2.0] |

---

## Scenario Config Format

Each scenario is a YAML file:

```yaml
scenario_name: "default_quarter"
episode_length: 60  # working days
num_departments: 5
num_applicants: 200
num_reviewers: 10
num_managers: 2

applicant_mix:
  honest: 0.60
  careless: 0.15
  strategic_prober: 0.10
  opportunistic_splitter: 0.10
  fraudulent_burst: 0.05

reviewer_mix:
  diligent: 0.40
  rubber_stamper: 0.20
  risk_averse_escalator: 0.25
  adaptive: 0.15

budget_per_dept: 500000  # CNY per quarter
claim_rate_per_applicant: 0.3  # claims per day (Poisson lambda)

stress_events:
  - type: "fraud_burst"
    trigger_day: 30
    duration: 5
    params:
      burst_multiplier: 3.0
  - type: "policy_shock"
    trigger_day: 45
    duration: 10
    params:
      min_audit_ratio: 0.30

reward_weights:
  w_leak: 1.0
  w_cost: 0.3
  w_cycle: 0.5
  w_fa: 0.2
  w_appeal: 0.4
  w_morale: 0.2
  w_cvar: 0.8
  w_throughput: 0.3

random_seed: null  # set for reproducibility
```

---

## Logging Schema

Each episode produces a structured log:

```yaml
episode_log:
  seed: int
  scenario: str
  policy: str
  total_claims: int
  total_fraud_claims: int
  total_fraud_amount: float
  metrics_per_day:
    - day: int
      claims_submitted: int
      claims_resolved: int
      fraud_missed: int
      fraud_caught: int
      leakage_amount: float
      audit_count: int
      false_alarms: int
      appeals: int
      sla_violations: int
      avg_cycle_time: float
      action: list[float]  # 6-dim action taken
  episode_summary:
    total_leakage_rate: float
    cvar_leakage: float
    mean_cycle_time: float
    sla_violation_rate: float
    appeal_rate: float
    false_alarm_rate: float
    manual_audit_cost: float
    throughput: float
    total_reward: float
```

---

## Validation Strategy

### Layer 1: Face Validity
- Encode real enterprise reimbursement policies (category limits, approval tiers, SLA)
- Verify claim amount distributions match public salary/expense statistics
- Verify category proportions match industry reports

### Layer 2: Process Validity
- Calibrate cycle time distributions against public BPM/helpdesk event logs
- Verify queue dynamics produce realistic utilization patterns
- Compare approval/rejection ratios with published audit statistics

### Layer 3: Behavioral Validity
- Sensitivity sweep over applicant type mix: verify monotonic relationships
  - More strategic probers -> higher leakage (if policy is static)
  - More diligent reviewers -> lower leakage but higher cost
- Verify adaptation dynamics produce expected equilibria
  - Strategic probers converge to threshold boundary
  - Rubber-stampers degrade under sustained high load
- Report parameter ranges where conclusions hold vs. break
