# Stress Tests

**Date**: 2026-05-03
**Project**: ddpg_cpss_finance_reimbursement

---

## Overview

8 stress tests designed to probe policy robustness under realistic adversarial and operational shocks. Each test modifies specific simulator dynamics and measures whether the policy degrades gracefully or catastrophically.

All stress tests are injected via scenario config. The core step function is unchanged.

---

## S1: Fraud Burst

**Trigger**: At day T (configurable, default T=30), all fraudulent_burst applicants simultaneously enter burst mode regardless of their perceived_audit_intensity. Additionally, 10% of strategic_prober applicants switch to burst behavior.

**Changed dynamics**:
- Fraud claim rate increases 3-5x for burst_duration days (default 5)
- Burst claims are high-value (3-10x median)
- Concentrated in 1-2 departments (simulating coordinated fraud)

**Expected failure mode**: Policies with low audit_ratio or high auto_approval_prob will miss the burst. Leakage spikes. If policy is slow to react, cumulative fraud damage is large.

**Metric**: CVaR_0.05(leakage) over the burst window and 10 days after

**Acceptance criterion**: CVaR-aware policy (B8 with CVaR) reduces burst-window leakage by >=20% vs risk-neutral policy (B10), while mean cycle time increases <=10%

**Which claim it tests**: C2 (risk-sensitive governance)

---

## S2: Month-End Surge

**Trigger**: Days 20-30 of each month (last third of month). Claim submission rate increases 2x across all applicant types. Managers face throughput pressure.

**Changed dynamics**:
- All applicants double submission rate
- Manager throughput_pressure = (day - 20) / 10
- Manager approval_quality degrades by 0.1 * pressure
- Implicit pressure on reviewers to process faster (rubber_stamper behavior amplified)
- Strategic probers exploit the chaos: increase probing intensity by 50%

**Expected failure mode**: SLA violations spike. Reviewer quality degrades. Strategic probers exploit reduced scrutiny. Queue overflow if policy does not adapt escalation and auto-approval.

**Metric**: SLA violation rate (days 20-30), appeal rate, leakage rate during surge

**Acceptance criterion**: Adaptive policy keeps SLA violation rate <= 0.15 during surge (vs >= 0.25 for fixed rule). Leakage does not increase by more than 50% during surge.

**Which claim it tests**: C2 (tail risk under operational stress)

---

## S3: Policy Tightening

**Trigger**: At day T (default T=25), external compliance event forces minimum audit_ratio = 0.30 for 10 days. Simulates regulatory audit or fraud scandal response.

**Changed dynamics**:
- Policy action for random_audit_ratio is clipped to min 0.30 (overrides agent decision)
- All applicants observe the tightening: perceived_audit_intensity jumps to 0.8
- Strategic probers immediately back off (reduce submission rate by 50%)
- Opportunistic splitters pause splitting
- Fraudulent burst actors go fully dormant
- After shock ends: applicants gradually test whether intensity has returned to normal

**Expected failure mode**: During shock: cost spikes (too many audits), reviewer overload, SLA violations. After shock: if policy relaxes too fast, strategic applicants exploit the relaxation window.

**Metric**: Adaptation speed (days to return to pre-shock performance), leakage in 10-day window after shock ends, total audit cost during shock

**Acceptance criterion**: CPSS-aware policy recovers to pre-shock leakage within 5 days after shock ends. Social-unaware policy takes >10 days or overshoots.

**Which claim it tests**: C1 (social awareness enables faster adaptation), C2 (managing shock aftermath)

---

## S4: Reviewer Shortage / Overload

**Trigger**: At day T (default T=20), 40% of reviewers become unavailable (simulating sick leave, training, or reassignment). Lasts 10 days.

**Changed dynamics**:
- Available reviewer capacity drops by 40%
- Remaining reviewers face utilization > 0.9
- Rubber-stamper behavior amplifies across all remaining reviewers
- Fatigue accumulates faster (2x rate)
- Escalation backlog grows (managers also overloaded)
- Queue age increases rapidly

**Expected failure mode**: Queue overflow. SLA violations spike. Reviewer accuracy degrades. If policy does not increase auto_approval_prob or decrease escalation_intensity, system gridlocks.

**Metric**: Queue overflow (pending > 3x normal), SLA violation rate, leakage rate during shortage

**Acceptance criterion**: Adaptive policy keeps queue overflow < 2x normal by adjusting auto_approval and load_temperature. Leakage increase <= 30% (acceptable tradeoff for maintaining throughput).

**Which claim it tests**: C1 (social-aware policy detects reviewer fatigue and adapts)

---

## S5: Department Budget Shock

**Trigger**: At day T (default T=35), one department (20% of applicants) has budget_remaining drop to 5% due to unexpected large approved claim or accounting correction.

**Changed dynamics**:
- Affected department enters emergency mode: all claims > 1000 CNY require manager approval
- Applicants in affected department increase submission urgency (try to get claims through before freeze)
- Strategic probers in other departments exploit attention shift
- Finance pressure increases globally (other departments fear similar shock)

**Expected failure mode**: Bottleneck in affected department. Spillover effects as attention shifts. Strategic exploitation in unaffected departments.

**Metric**: Budget violation rate (claims approved beyond budget), leakage in non-affected departments, overall SLA

**Acceptance criterion**: Policy prevents budget overrun in affected department while maintaining leakage control in other departments. Cross-department leakage increase <= 20%.

**Which claim it tests**: C2 (risk-sensitive governance under financial shock)

---

## S6: Threshold Probing by Strategic Applicants

**Trigger**: Gradual. Starting from day 10, strategic_prober fraction increases from 0.10 to 0.30 over 20 days (simulating word-of-mouth learning among employees about audit patterns).

**Changed dynamics**:
- More applicants actively probe audit thresholds
- Probers share information: perceived_threshold converges across probers (simulated via shared EMA with slower decay)
- Probing becomes more sophisticated: probers test multiple categories and timing patterns
- If policy is static, probers converge to just-below-threshold amounts

**Expected failure mode**: Static policies get systematically exploited. Leakage increases monotonically as probers learn the threshold. If policy oscillates, probers exploit the oscillation pattern.

**Metric**: Leakage rate trend over 20-day probing window, threshold convergence speed of probers, policy action variance

**Acceptance criterion**: CPSS-aware policy maintains leakage rate < 0.20 throughout probing window by dynamically adjusting risk_threshold and targeted_audit_weight. Social-unaware policy shows monotonically increasing leakage.

**Which claim it tests**: C1 (strategic gaming resistance is the core claim)

---

## S7: Collusive Reviewer-Applicant Pattern

**Trigger**: At day T (default T=15), 1 reviewer (rubber_stamper type) and 5 applicants form a simplified collusive pattern. The reviewer always approves claims from these applicants regardless of risk score.

**Changed dynamics**:
- Colluding applicants increase claim amounts by 2x and submission rate by 1.5x
- Colluding reviewer routes their claims to self (if load_temperature allows)
- Colluding reviewer maintains normal behavior for other claims (to avoid detection)
- Risk model does not directly detect collusion (it sees individual claim features)
- Detection signal: anomalous approval rate for specific reviewer-applicant pairs

**Expected failure mode**: If policy relies only on claim-level risk scores, collusion is invisible. Leakage from colluding group is high. Only policies that monitor reviewer-level approval patterns can detect anomaly.

**Metric**: Collusion detection rate (fraction of colluding claims caught by audit), total leakage from colluding group, false alarm rate on non-colluding claims

**Acceptance criterion**: Policy with targeted_audit_weight > 0.5 catches >= 40% of colluding claims through statistical anomaly in reviewer patterns. This is a stretch goal; partial detection is acceptable for v0.1.

**Which claim it tests**: C1 (strategic gaming resistance), C2 (tail risk from organized fraud)

**Note**: This is a simplified collusion model. Full collusion detection would require graph-level analysis beyond the current observation space. The paper should acknowledge this limitation.

---

## S8: Mixed Honest/Careless/Strategic Population Shift

**Trigger**: Gradual shift over the entire episode. Applicant type distribution changes from default (60/15/10/10/5) to stressed (30/10/25/20/15) over 60 days.

**Changed dynamics**:
- Honest fraction decreases from 0.60 to 0.30
- Strategic prober fraction increases from 0.10 to 0.25
- Opportunistic splitter fraction increases from 0.10 to 0.20
- Fraudulent burst fraction increases from 0.05 to 0.15
- Careless fraction decreases from 0.15 to 0.10
- Shift is linear: each day, fractions interpolate between start and end values

**Expected failure mode**: Policies trained on default mix degrade as population shifts. Social-unaware policies cannot detect the shift. Fixed rules become increasingly inadequate.

**Metric**: Performance degradation curve (leakage, SLA, appeal rate over time), adaptation lag (days until policy adjusts to new population)

**Acceptance criterion**: CPSS-aware policy shows <= 30% performance degradation at episode end vs episode start. Social-unaware policy shows >= 50% degradation. CPSS-aware policy begins adapting within 10 days of shift onset.

**Which claim it tests**: C1 (robustness to non-stationary social dynamics)

---

## Stress Test Summary Table

| ID | Name | Trigger Type | Duration | Primary Metric | Claim | Priority |
|----|------|-------------|----------|---------------|-------|----------|
| S1 | Fraud Burst | Point event | 5 days | CVaR(leakage) | C2 | MUST-RUN |
| S2 | Month-End Surge | Periodic | 10 days/month | SLA violation rate | C2 | MUST-RUN |
| S3 | Policy Tightening | Point event | 10 days + aftermath | Adaptation speed | C1, C2 | MUST-RUN |
| S4 | Reviewer Shortage | Point event | 10 days | Queue overflow | C1 | MUST-RUN |
| S5 | Budget Shock | Point event | Until quarter end | Budget violation | C2 | MUST-RUN |
| S6 | Threshold Probing | Gradual | 20 days | Leakage trend | C1 | MUST-RUN |
| S7 | Collusive Pattern | Point event | Until quarter end | Detection rate | C1, C2 | NICE-TO-HAVE |
| S8 | Population Shift | Gradual | Full episode | Degradation curve | C1 | MUST-RUN |

---

## Stress Test Execution Protocol

1. Each stress test runs on top of the default scenario config
2. Only the specified dynamics change; all other parameters remain at default
3. Each test runs with 5 seeds per policy
4. Compare: B1 (fixed rule), B8 (SAC full), B9 (SAC-NoSocial), B10 (SAC-NoRisk)
5. Report: mean +/- std for primary metric, paired comparison across seeds
6. Visualize: time-series plots showing metric evolution before/during/after stress event
