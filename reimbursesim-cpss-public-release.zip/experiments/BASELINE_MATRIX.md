# Baseline Matrix

**Date**: 2026-05-03
**Project**: ddpg_cpss_finance_reimbursement

---

## Overview

12 baselines organized into 6 families. Every baseline exists to test a specific claim or provide a reference bound. No padding baselines.

---

## B1: Fixed Rule Heuristic

**Purpose**: Represents the status quo in most enterprises. If RL cannot beat fixed rules, there is no practical contribution.

**Input features**: None (static parameters)

**Action space**: Fixed constants: random_audit_ratio=0.15, targeted_audit_weight=0.5, risk_threshold=0.6, auto_approval_prob=0.3, escalation_intensity=0.2, reviewer_load_temperature=1.0

**Training data**: None (no learning)

**Expected strength**: Stable, predictable, easy to explain to stakeholders. Performs reasonably under stationary conditions.

**Expected weakness**: Cannot adapt to changing applicant behavior, seasonal patterns, or stress events. Performance degrades under strategic adaptation.

**Why reviewers will ask for it**: Every BPM/DSS paper needs a rule-based enterprise baseline. Without it, reviewers will question practical relevance.

---

## B2: Risk Threshold Heuristic

**Purpose**: A smarter rule baseline that adjusts audit intensity based on observed risk scores. Tests whether simple reactive rules suffice.

**Input features**: rolling_avg_risk_score, recent_leakage_rate, reviewer_utilization

**Action space**: Rule-based mapping:
- If recent_leakage > 0.2: increase random_audit_ratio by 0.05
- If reviewer_utilization > 0.85: decrease escalation_intensity by 0.1
- If rolling_risk_score > 0.5: decrease risk_threshold by 0.05
- Other knobs: fixed at B1 defaults
- Clipped to valid ranges after each adjustment

**Training data**: None (reactive rules, no learning)

**Expected strength**: Adapts to obvious signals. Represents what a competent finance team would do manually.

**Expected weakness**: Reactive, not predictive. Cannot anticipate strategic behavior. Adjustments are slow and may oscillate.

**Why reviewers will ask for it**: Tests whether simple domain heuristics already solve the problem. If B2 matches RL, the RL contribution is questionable.

---

## B3: Random Audit Policy

**Purpose**: Lower bound. Establishes the worst reasonable policy.

**Input features**: None

**Action space**: Each step, sample all 6 knobs uniformly from their valid ranges.

**Training data**: None

**Expected strength**: None. This is a reference floor.

**Expected weakness**: No coherent strategy. High variance, poor on all metrics.

**Why reviewers will ask for it**: Standard lower bound in policy comparison studies.

---

## B4: DQN with Discretized Controls

**Purpose**: Tests whether continuous action space is necessary (Claim C3). If DQN matches continuous RL, the continuous-control claim fails.

**Input features**: Full 24-dim observation vector

**Action space**: Each of 6 knobs discretized into N bins.
- Coarse variant (B4a): N=5 bins per knob, total 5^6 = 15625 discrete actions
- Fine variant (B4b): N=10 bins per knob, total 10^6 = 1M actions (use action embedding or factored DQN)
- For B4b, use Branching DQN (BDQ) to handle combinatorial explosion: 6 independent Q-heads, one per knob

**Training data**: Same episodes as continuous RL agents

**Expected strength**: DQN is well-understood, stable with replay buffer. Coarse discretization may suffice if knob interactions are weak.

**Expected weakness**: Loses fine-grained control. Cannot represent smooth policy surfaces. Combinatorial explosion with fine bins. May fail when knobs are coupled (e.g., audit_ratio and risk_threshold interact).

**Why reviewers will ask for it**: Standard ablation for continuous vs discrete control. BPM literature often uses discrete interventions.

---

## B5: PPO

**Purpose**: Strong general-purpose RL baseline. PPO is the default choice in many applied RL papers.

**Input features**: Full 24-dim observation vector

**Action space**: Continuous [0,1]^6 with Gaussian policy (clipped)

**Training data**: On-policy; requires more environment interactions than off-policy methods

**Expected strength**: Robust to hyperparameters. Stable training. Good at handling multi-objective rewards.

**Expected weakness**: Sample-inefficient compared to off-policy methods. May underperform SAC/TD3 in continuous control with complex reward landscapes.

**Why reviewers will ask for it**: PPO is the most widely used RL algorithm. Omitting it would be a glaring gap.

---

## B6: DDPG

**Purpose**: Original candidate algorithm. Must be included but not assumed to be best.

**Input features**: Full 24-dim observation vector

**Action space**: Continuous [0,1]^6 with deterministic policy + OU noise for exploration

**Training data**: Off-policy replay buffer (1M transitions)

**Expected strength**: Designed for continuous control. Off-policy efficiency.

**Expected weakness**: Known instability issues. Sensitive to hyperparameters. Often outperformed by TD3/SAC. Overestimation bias in Q-function.

**Why reviewers will ask for it**: Named in the original project title. Must be tested honestly. If DDPG is worst among continuous RL, that is a valid finding (STOP-4 triggers narrative removal, not paper failure).

---

## B7: TD3

**Purpose**: Stronger deterministic continuous-control baseline. Addresses DDPG's known weaknesses.

**Input features**: Full 24-dim observation vector

**Action space**: Continuous [0,1]^6 with deterministic policy + clipped Gaussian noise

**Training data**: Off-policy replay buffer (1M transitions)

**Expected strength**: Twin Q-networks reduce overestimation. Delayed policy updates improve stability. Generally outperforms DDPG.

**Expected weakness**: Still deterministic; may underperform SAC in stochastic environments. Exploration may be insufficient in early training.

**Why reviewers will ask for it**: Standard improvement over DDPG. If TD3 >> DDPG, it validates the choice to not center the paper on DDPG.

---

## B8: SAC

**Purpose**: State-of-the-art continuous RL baseline. Expected strongest RL performer.

**Input features**: Full 24-dim observation vector

**Action space**: Continuous [0,1]^6 with stochastic policy (squashed Gaussian)

**Training data**: Off-policy replay buffer (1M transitions)

**Expected strength**: Entropy regularization provides robust exploration. Automatic temperature tuning. Strong in multi-objective settings. Handles stochastic environments well.

**Expected weakness**: Slightly more complex to implement. May over-explore in simple scenarios.

**Why reviewers will ask for it**: SAC is the strongest modern continuous RL baseline. Omitting it would be a serious gap.

---

## B9: Social-Unaware RL (SAC-NoSocial)

**Purpose**: Critical ablation for Claim C1. Tests whether the social/CPSS layer matters.

**Input features**: 24-dim observation BUT with social signals zeroed out:
- perceived_audit_intensity = 0
- reviewer_fatigue_index = 0
- reviewer_strictness_drift = 0
- applicant_split_rate_7d = 0
- appeal_rate_7d = 0
(Features 14-18 set to 0; remaining 19 features used)

**Action space**: Continuous [0,1]^6 (same as SAC)

**Training data**: Same episodes, same adaptive environment. Agent simply cannot observe social signals.

**Expected strength**: If social signals are noise, this should match full SAC.

**Expected weakness**: Cannot anticipate or respond to strategic applicant behavior. Blind to reviewer fatigue and adaptation.

**Why reviewers will ask for it**: This is THE killer test. If SAC-NoSocial matches SAC-Full in the adaptive environment, the entire CPSS/social-awareness claim collapses. This baseline must be run with the same hyperparameters and seeds as SAC-Full.

---

## B10: Risk-Neutral RL (SAC-NoRisk)

**Purpose**: Ablation for Claim C2. Tests whether CVaR/risk-sensitive objective matters.

**Input features**: Full 24-dim observation vector

**Action space**: Continuous [0,1]^6 (same as SAC)

**Training data**: Same episodes. Reward function with w_cvar = 0 (no CVaR penalty).

**Expected strength**: Optimizes mean performance without tail-risk penalty. May achieve better average metrics.

**Expected weakness**: Vulnerable to tail events. Higher variance in leakage under stress scenarios.

**Why reviewers will ask for it**: Standard ablation for risk-sensitive RL. If risk-neutral SAC has similar tail performance, the CVaR contribution is not justified.

---

## B11: SCOPE-Style Sequential Causal Intervention

**Purpose**: Non-RL alternative. Tests whether causal sequential optimization from process logs is sufficient.

**Input features**: Simulated event logs (converted from episode traces)

**Action space**: Discrete intervention decisions at each process step (audit/no-audit, escalate/no-escalate). Adapted from SCOPE (arXiv 2512.17629) framework.

**Training data**: Collected episode logs from rule-based policy runs. Uses observational causal inference to estimate intervention effects.

**Expected strength**: Does not require online interaction. Leverages causal structure. May be preferred by BPM reviewers familiar with process mining.

**Expected weakness**: Assumes access to sufficient log data. Cannot handle continuous coupled controls natively. May not adapt to non-stationary strategic behavior (trained on historical logs).

**Why reviewers will ask for it**: SCOPE is a 2025 near-neighbor that claims sequential causal optimization can replace RL for process interventions. Must be addressed directly. If SCOPE outperforms RL given sufficient logs, the paper should acknowledge this and position RL as the online/adaptive alternative.

---

## B12: Oracle / Upper-Bound Policy

**Purpose**: Establishes theoretical performance ceiling. Helps calibrate how close RL policies get to optimal.

**Input features**: Full observation + ground truth fraud labels (cheating: knows which claims are fraudulent)

**Action space**: Continuous [0,1]^6

**Implementation**: Greedy policy that audits all fraudulent claims and auto-approves all legitimate ones. Sets audit_ratio to exact fraud rate, risk_threshold to perfectly separate fraud/legitimate.

**Expected strength**: Perfect fraud detection. Minimal unnecessary audits. Optimal throughput.

**Expected weakness**: Not achievable in practice (requires omniscience). Serves only as reference.

**Why reviewers will ask for it**: Upper bound helps readers assess the gap between achievable and optimal performance. Common in evaluation frameworks.

---

## Summary Comparison Table

| ID | Baseline | Family | Action Type | Social-Aware | Risk-Sensitive | Tests Claim |
|----|----------|--------|-------------|-------------|----------------|-------------|
| B1 | Fixed Rule | Heuristic | Static | No | No | Reference |
| B2 | Risk Threshold | Heuristic | Reactive | Partial | Partial | C1, C3 |
| B3 | Random | Lower Bound | Random | No | No | Reference |
| B4a | DQN-Coarse | Discrete RL | Discrete-5 | Yes | Yes | C3 |
| B4b | DQN-Fine (BDQ) | Discrete RL | Discrete-10 | Yes | Yes | C3 |
| B5 | PPO | Policy Gradient | Continuous | Yes | Yes | C3 |
| B6 | DDPG | Continuous RL | Continuous | Yes | Yes | C3 |
| B7 | TD3 | Continuous RL | Continuous | Yes | Yes | C3 |
| B8 | SAC | Continuous RL | Continuous | Yes | Yes | C3 |
| B9 | SAC-NoSocial | Ablation | Continuous | **No** | Yes | **C1** |
| B10 | SAC-NoRisk | Ablation | Continuous | Yes | **No** | **C2** |
| B11 | SCOPE-style | Causal | Discrete | Partial | No | C1, C3 |
| B12 | Oracle | Upper Bound | Continuous | Omniscient | Omniscient | Reference |
