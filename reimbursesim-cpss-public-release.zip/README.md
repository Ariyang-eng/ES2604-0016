# ReimburseSim-CPSS

ReimburseSim-CPSS is a Gymnasium-compatible benchmark for studying reinforcement-learning
policies in enterprise reimbursement workflow control. The simulator models a stylized
reimbursement process with operational queues, reviewer capacity, departmental budgets, adaptive
applicants, and stress scenarios.

The repository supports the paper:

**ReimburseSim-CPSS: A Reproducible Computational Benchmark and Experimental Procedure for
Reinforcement-Learning Policies in Enterprise Reimbursement Workflow Control**

## What This Repository Contains

- `src/reimbursesim/`: simulator package and Gymnasium environment.
- `configs/`: default and stress-scenario YAML configurations.
- `scripts/`: training, evaluation, aggregation, validation, and figure-generation scripts.
- `results/`: released result artifacts used by the paper tables and figures.
- `paper/`: LaTeX source and generated PDFs for the manuscript.
- `experiments/`: benchmark specification notes used to define the implementation.

## Current Empirical Claims

The released results support a benchmark and empirical-study framing, not a new-algorithm claim.

- RL policies outperform rule heuristics on the default scenario.
- SAC-style policies outperform DQN on leakage across the released stress scenarios.
- Explicit social observation features do **not** reliably improve performance in this benchmark.
- CVaR reward shaping does **not** reliably improve tail-risk leakage in this benchmark.

These negative findings are scoped to ReimburseSim-CPSS, the released configurations, and the
training budgets used here. They should not be read as general claims against social features or
risk-sensitive reinforcement learning.

## Installation

```bash
python -m venv .venv
. .venv/Scripts/activate   # Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -e .
```

For remote GPU helper scripts:

```bash
pip install -e ".[remote]"
```

## Quick Smoke Test

```bash
python scripts/m0_sanity/run_random_policy.py --config configs/m0_sanity.yaml
```

## Reproduce Core Tables

Rule baselines:

```bash
python scripts/m1_baseline/run_rule_baselines.py --config configs/default_quarter.yaml --out-dir results/m1
```

M5 ablation:

```bash
python scripts/m5_ablation/run_ablation.py --out-dir results/m5_ablation --timesteps 50000
```

M4 stress rerun:

```bash
python scripts/m4_stress/train_one_stress.py --variant SAC-Full --seed 0 --out-dir results/m4_stress_rerun
python scripts/m4_stress/aggregate_stress_rerun.py --results-dir results/m4_stress_rerun
```

Figures:

```bash
python scripts/m7_figures/make_figures.py --results-dir results --out-dir results/figures
```

## Remote GPU Runs

Remote helper scripts read connection settings from environment variables:

```bash
set REMOTE_HOST=example.org
set REMOTE_PORT=22
set REMOTE_USER=root
set REMOTE_PASSWORD=...
```

No credentials are stored in this repository.

## Paper Build

```bash
cd paper
latexmk -pdf -interaction=nonstopmode -halt-on-error main.tex
latexmk -pdf -interaction=nonstopmode -halt-on-error main_springer.tex
```

`main_springer.tex` is the current Springer-targeted entry point. It still contains author,
declaration, and artifact URL placeholders that must be filled before journal submission.
