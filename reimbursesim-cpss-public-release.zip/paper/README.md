# ReimburseSim-CPSS Paper Draft

This directory contains the LaTeX source for the benchmark paper

> **ReimburseSim-CPSS: A Reproducible Benchmark for Reinforcement Learning in Enterprise Reimbursement Control**

The paper is a benchmark + empirical-study draft, **not** a new-algorithm paper. It uses the M1, M2, M3, corrected M4 stress rerun, M5 ablation, and M6 validation artifacts under `../results/`.

## Files

```
paper/
  main.tex                    # entry point (twocolumn, letter, 10pt)
  references.bib              # bibliography
  README.md                   # this file
  sections/
    abstract.tex
    introduction.tex
    related_work.tex
    simulator.tex
    experimental_setup.tex
    results.tex
    discussion.tex
    conclusion.tex
```

Figures are pulled from `../results/figures/` via `\graphicspath` in `main.tex`. The four headline figures used are:

* `main_comparison.png`
* `social_negative_result.png`
* `stress_comparison.png`
* `validation_distributions.png`

## How to compile

The paper compiles with TeX Live 2026 (or any reasonably recent distribution) and standard packages (`amsmath`, `booktabs`, `graphicx`, `hyperref`, `multirow`, `enumitem`, `microtype`).

From inside `paper/`:

```bash
pdflatex -interaction=nonstopmode main.tex
bibtex main
pdflatex -interaction=nonstopmode main.tex
pdflatex -interaction=nonstopmode main.tex
```

Or with `latexmk`:

```bash
latexmk -pdf main.tex
```

Output: `main.pdf`. The current build produces a clean PDF with no overfull boxes; expect some "Underfull \hbox" typographical warnings in dense paragraphs and one font-shape substitution warning (`T1/lmr/bx/sc`), which are cosmetic.

## Where the result tables come from

| Table / Figure | Source artifact |
|---|---|
| Table~1 (main comparison) | `results/m1/`, `results/m2/`, `results/m5_ablation/ablation_results.json`, `results/BENCHMARK_SUMMARY.md` |
| Table~2 (stress rerun) | `results/m4_stress_rerun/stress_results.json`, `results/m4_stress_rerun/summary.md` |
| Table~3 (ablation) | `results/m5_ablation/ablation_results.json` |
| Table~4 (simulator validation) | `results/validation/simulator_validation.md` |
| Fig.~1 (social negative) | `results/figures/social_negative_result.png` |
| Fig.~2 (stress) | `results/figures/stress_comparison.png` |
| Fig.~3 (main) | `results/figures/main_comparison.png` |
| Fig.~4 (validation) | `results/figures/validation_distributions.png` |

The corrected M4 stress rerun is the public source for the C4 (CVaR reward shaping) result. The corrected scripts live at `../scripts/m4_stress/train_one_stress.py` and `../scripts/m4_stress/aggregate_stress_rerun.py`.

## Claims actually supported by the draft

The paper is written around the following audited claim set. **Do not weaken them in the other direction either** --- both the positives and the negatives are intentional.

* **C1 (Benchmark, supported):** ReimburseSim-CPSS is a reproducible Gymnasium-compatible benchmark for enterprise reimbursement control. The simulator, configs, training scripts, and figures are released.
* **C2 (Empirical, supported):** RL policies (SAC, PPO, DDPG, TD3, DQN) outperform fixed-rule, random, and risk-threshold baselines on `default_quarter` and across all five stress scenarios. SAC roughly halves leakage relative to the fixed-rule baseline.
* **C3 (Negative social result, preserved):** Explicit social observation features (perceived audit intensity, reviewer fatigue, strictness drift, applicant split rate, appeal rate) do **not** reliably help in this benchmark. `SAC-NoSocial` matches or slightly outperforms `SAC-Full` across all available seeds.
* **C4 (CVaR reward shaping, negative):** Explicit CVaR/risk reward shaping does **not** reliably improve tail-risk leakage in this benchmark. When `SAC-NoRisk` is independently trained against the unshaped reward, it matches or outperforms `SAC-Full` on leakage and CVaR in all five stress scenarios. Earlier reports were caused by reusing one trained SAC model and only switching the eval-time wrapper.

## What the draft deliberately does **not** claim

* That CPSS / social observation improves performance.
* That CVaR / risk reward shaping improves tail risk.
* That DDPG is the core innovation. The paper is benchmark + empirical study; DDPG is one of several baselines.
* That the simulator is fully realistic or validated against a specific organization.
* That social features are useless in general; the negative finding is scoped to this simulator and these training budgets.
* That CVaR-aware RL is unhelpful in general; the negative finding is about *reward shaping*, not about distributional / chance-constrained / CVaR-objective methods, which are listed as future work.
* That the system is deployment-ready.

## TODOs for the next pass

The draft is intended to be a working benchmark paper that can be tightened and submitted with one more revision pass. Concrete remaining TODOs:

1. **Tighten to 8 pages.** Current build is ~10 pages including bibliography. The most compressible sections are the simulator entity tables (Section~3) and the `Limitations and Future Work` block (Section~6.5). Reducing the entity bullet list and merging two stress scenarios into one row of Table~2 would each save roughly half a page.
2. **Multi-seed PPO/DDPG/TD3.** The M2 numbers in Table~1 are single-seed pilot runs. Three-seed reruns are easy on the same RTX 5090 setup and would let us drop the "M2 pilot" qualifier. The script template is `scripts/m4_stress/train_one_stress.py`, generalized over algorithm.
3. **Per-seed rule baselines.** The rule heuristics in Table~1 are reported on the released M1 evaluation episode without per-training-seed variance. Re-running them across three seeded episodes would let us drop the "Seeds = 1" caveat for those rows.
4. **Single-knob ablation.** The baseline matrix lists a single-knob SAC ablation; it is not in the released results and is currently absent from the paper. If we want a stronger statement about which control dimensions matter, we should run that.
5. **Optional: oracle and SCOPE-style baselines.** Both are listed as future work in Section~6.5. A simple oracle (audit any claim with `is_fraudulent=True`) is implementable today; a SCOPE-style baseline is more involved.
6. **Anonymisation / venue style.** The draft uses a generic `article` two-column layout. For a specific venue (KDD, ICDM, AAAI, NeurIPS Datasets & Benchmarks), swap the preamble in `main.tex` for that venue's `*.sty` and re-check the page budget.
7. **Citations.** `references.bib` follows the audit instructions: real authors, titles, and venues, no fabricated DOIs. Some entries (especially Bellemare 2017, Park & Song 2020) are intentionally minimal; replace with the canonical published-form entries before submission.
8. **Figures.** The four PNGs in `../results/figures/` are PNGs; for camera-ready, regenerate them as PDF/SVG via `scripts/m7_figures/make_figures.py`.

## Authoritative reference

For the public repository, the source of truth is the combination of `../results/BENCHMARK_SUMMARY.md`, the JSON artifacts under `../results/`, and the corresponding scripts under `../scripts/`.
