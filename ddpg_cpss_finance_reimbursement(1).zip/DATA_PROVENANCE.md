# Data and Source Provenance

## Synthetic Results

The result files contain simulator episode metrics and statistical summaries. They do not contain identifiable employee claims or company financial records.

Public-reference configurations compare designed claim-amount distributions. They are not estimates of enterprise fraud prevalence. The BPI Challenge 2020 reference dataset is available from its original provider:

https://doi.org/10.4121/uuid:52fb97d4-4588-43c9-9d04-3604d4613b51

Raw BPI event logs and third-party publications are not included. Consult the provider's terms before obtaining or redistributing third-party material.

## Source Identity

The original evaluated runtime has the aggregate source identifier:

```text
9f04de872f4f912f90be9349a15865cb7088c281b7dbc38cc9436d89163d3fae
```

The 47 files listed in `research/R2_supplement/freeze/runtime/revision/source_manifest_formal.json` retain their original contents. Legacy scripts are retained as part of that source snapshot; the commands in `REPRODUCTION.md` describe the R2 training protocol.

Primary JSON reports have local path prefixes removed from string metadata. Experimental numbers are unchanged. The original comparison, capacity-constrained training, and parameter-sensitivity evaluations are separate cohorts.

## Excluded Artifacts

Weights, checkpoints, and detailed step logs are not included. Repeating model inference requires the corresponding authorized artifacts. The included CSV files support statistical reanalysis without those weights.

Software and result licensing remain subject to confirmation by the copyright holders.
