"""Exclusive-output cap5 training; frozen R2 dynamics, CPU primary backend."""
from pathlib import Path
import argparse,json,hashlib,sys,time,os,importlib.metadata
from dataclasses import asdict
O=Path(__file__).resolve().parent;F=O/'freeze/runtime'
sys.path[:0]=[str(F/'src'),str(F/'scripts/r1')]
from train import make_env
from reimbursesim.config import load_scenario

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify_core():
    m=json.loads((F/'revision/source_manifest_formal.json').read_text())
    for p,h in m['files'].items():assert sha(F/p)==h,p
    return m
def append(p,row):
    with p.open('a') as f:f.write(json.dumps(row,allow_nan=False)+'\n')
def env(variant,cap=5):
    return make_env(variant,'default_quarter',cap,configs={'default_quarter':load_scenario(F/'configs/default_quarter.yaml')})
def evaluate(model,variant,seed,cap=5):
    e=env(variant,cap);o,_=e.reset(seed=seed);daily=[]
    while True:
        act,_=model.predict(o,deterministic=True);o,r,d,t,info=e.step(act)
        a=info['metrics']['audit_count'];assert cap is None or a<=cap
        daily.append({'day':info['day'],'audits':a,'reward':r})
        if d or t:
            assert d and not t and len(daily)==60
            row={'eval_seed':seed,'summary':info['episode_summary'],'daily':daily,'cap':cap}
            assert row['summary']['audit_count']==sum(x['audits'] for x in daily)
            e.close();return row
def train(variant,seed,steps=500000,smoke=False):
    import torch
    from stable_baselines3 import SAC,PPO,DQN
    from stable_baselines3.common.callbacks import BaseCallback
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    if not smoke:assert steps>=500000 and seed in range(5)
    verify_core()
    out=O/('smoke' if smoke else 'cap5_training')/f'{variant}_seed{seed}'
    out.mkdir(parents=True,exist_ok=False)
    start=time.time();cls={'SAC-Full':SAC,'PPO':PPO,'DQN':DQN}[variant]
    kwargs={'policy_kwargs':{'net_arch':[64,64]},'learning_rate':3e-4,'seed':seed,'device':'cpu','verbose':0}
    if variant=='PPO':kwargs.update(n_steps=512,batch_size=64)
    else:kwargs.update(buffer_size=100000,learning_starts=1000,batch_size=128,train_freq=1,gradient_steps=1)
    metadata={'status':'RUNNING','variant':variant,'train_seed':seed,'training_cap':5,'evaluation_cap':5,'requested_steps':steps,'device':'cpu','kwargs':kwargs,'core_source':verify_core()['sha256'],'worker_sha256':sha(Path(__file__)),'config':asdict(env(variant).unwrapped.config),'curve_seeds':list(range(100,105)),'test_seeds':list(range(200,202 if smoke else 300)),'packages':{x:importlib.metadata.version(x) for x in ['torch','stable-baselines3','gymnasium','numpy']}}
    (out/'run.json').write_text(json.dumps(metadata,indent=2))
    class Curves(BaseCallback):
        def _on_step(self):
            for info in self.locals.get('infos',[]):
                assert info['metrics']['audit_count']<=5
                if 'episode_summary' in info:append(out/'training_episodes.jsonl',{'steps':self.num_timesteps,'summary':info['episode_summary']})
            if self.num_timesteps%25000==0:
                rows=[evaluate(self.model,variant,s) for s in range(100,105)]
                append(out/'learning_curve.jsonl',{'steps':self.num_timesteps,'episodes':rows})
                self.model.save(out/f'checkpoint_{self.num_timesteps}.zip')
                print(json.dumps({'steps':self.num_timesteps,'seconds':time.time()-start}),flush=True)
            return True
    e=env(variant);model=cls('MlpPolicy',e,**kwargs);model.learn(total_timesteps=steps,callback=Curves())
    model.save(out/'final_model.zip');metadata['actual_steps']=int(model.num_timesteps)
    # Check archive's own counter, not merely the requested CLI argument.
    import zipfile
    with zipfile.ZipFile(out/'final_model.zip') as z:
        data=json.loads(z.read('data'));assert data['num_timesteps']==metadata['actual_steps'] and data['seed']==seed
    for s in metadata['test_seeds']:
        row=evaluate(model,variant,s);row.update(variant=variant,train_seed=seed,train_steps=metadata['actual_steps'],training_condition='cap5_trained');append(out/'evaluation.jsonl',row)
    verify_core();metadata.update(status='COMPLETED',wall_seconds=time.time()-start,model_sha256=sha(out/'final_model.zip'))
    (out/'run.json').write_text(json.dumps(metadata,indent=2));(out/'COMPLETED').write_text(metadata['model_sha256'])
    e.close();print(json.dumps({'completed':str(out),'seconds':metadata['wall_seconds']}),flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--variant',choices=['SAC-Full','PPO','DQN'],required=True);p.add_argument('--seed',type=int,required=True);p.add_argument('--steps',type=int,default=500000);p.add_argument('--smoke',action='store_true');a=p.parse_args()
    train(a.variant,a.seed,a.steps,a.smoke)
