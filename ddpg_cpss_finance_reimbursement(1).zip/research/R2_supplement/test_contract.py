"""Real native-cap contract tests; no production changes."""
import unittest,copy,json
from dataclasses import asdict
import numpy as np
from worker import env,verify_core

class CapacityContract(unittest.TestCase):
    def test_frozen_source(self):verify_core()
    def test_only_cap_changes(self):
        a=asdict(env('SAC-Full',None).unwrapped.config);b=asdict(env('SAC-Full',5).unwrapped.config)
        changed=[k for k in a if a[k]!=b[k]];self.assertEqual(changed,['audit_cap_per_day'])
    def test_train_eval_factories_identical(self):
        for v in ['SAC-Full','PPO','DQN']:
            a,b=env(v),env(v)
            self.assertEqual(type(a),type(b));self.assertEqual(asdict(a.unwrapped.config),asdict(b.unwrapped.config))
            oa,_=a.reset(seed=7100);ob,_=b.reset(seed=7100);np.testing.assert_array_equal(oa,ob)
            for _ in range(60):
                action=63 if v=='DQN' else np.ones(6,dtype=np.float32)
                ra=a.step(action);rb=b.step(action)
                np.testing.assert_array_equal(ra[0],rb[0]);self.assertEqual(ra[1:],rb[1:])
                self.assertLessEqual(ra[4]['metrics']['audit_count'],5)
            self.assertTrue(ra[2]);self.assertFalse(ra[3]);a.close();b.close()
    def test_cap_binds_all_variants_and_metrics(self):
        for v in ['SAC-Full','PPO','DQN']:
            a=env(v);a.reset(seed=7101);audits=[]
            for day in range(60):
                _,_,d,t,i=a.step(63 if v=='DQN' else np.ones(6,dtype=np.float32))
                audits.append(i['metrics']['audit_count']);self.assertLessEqual(audits[-1],5)
            self.assertEqual(len(audits),60);self.assertEqual(max(audits),5)
            s=i['episode_summary'];self.assertEqual(sum(audits),s['audit_count']);self.assertIn('unresolved_fraud_amount',s)
            if s['resolved_fraud_amount']>0:self.assertAlmostEqual(s['leakage_rate'],s['total_leakage_amount']/s['resolved_fraud_amount'])
            if s['resolved_fraud_claims']>0:self.assertAlmostEqual(s['fraud_catch_rate'],a.unwrapped.summary.fraud_caught/s['resolved_fraud_claims'])
            a.close()
if __name__=='__main__':unittest.main(verbosity=2)
