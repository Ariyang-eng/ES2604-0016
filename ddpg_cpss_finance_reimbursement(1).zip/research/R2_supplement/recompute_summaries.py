"""Portable CSV-only reanalysis; no models, SSH, or archived absolute paths."""
from pathlib import Path
import csv, argparse
from statistics_core import aggregate, aligned

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--input',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--draws',type=int,default=5000)
    p.add_argument('--reference',type=Path,help='Published summary CSV, to reproduce its exact RNG stream and intervals')
    a=p.parse_args();groups={}
    with a.input.open(encoding='utf-8',newline='') as f:
        for r in csv.DictReader(f):
            key=(r['algorithm'],r['training_condition'],r['profile'])
            r['train_seed']=int(r['train_seed']) if r['train_seed'] else None
            r['eval_seed']=int(r['eval_seed']);r['leakage']=float(r['leakage'])
            groups.setdefault(key,[]).append(r)
    out=[];reference=[]
    if a.reference:
        with a.reference.open(encoding='utf-8',newline='') as f:reference=list(csv.DictReader(f))
    for key,rs in sorted(groups.items()):
        trains=[None] if key[0]=='fixed_rule' else list(range(5))
        ev=sorted({r['eval_seed'] for r in rs})
        matrix=aligned(rs,'leakage',trains,ev)
        rng_seed=7315
        if reference:
            matches=[r for r in reference if r['metric']=='leakage' and (r.get('policy')==key[0]+'/'+key[1] if 'policy' in r else r['algorithm']==key[0] and r['profile']==key[2])]
            assert len(matches)==1 and int(matches[0]['bootstrap_draws'])==a.draws
            rng_seed=int(matches[0]['bootstrap_seed'])
        stat=aggregate(matrix,draws=a.draws,seed=rng_seed)
        out.append(dict(algorithm=key[0],training_condition=key[1],profile=key[2],
                        leakage=stat['mean'],ci95_low=stat['ci95'][0],
                        ci95_high=stat['ci95'][1],independent_trainings=stat['training_seeds'],
                        rollouts=stat['rollouts']))
    a.output.parent.mkdir(parents=True,exist_ok=True)
    with a.output.open('x',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
    print('RECOMPUTED',len(out))

if __name__=='__main__':main()
