"""Figures from complete derived CSVs only; all seeds remain visible."""
from pathlib import Path
import csv
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
O=Path(__file__).resolve().parent
P=O/'figures';P.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'savefig.dpi':300})
COLORS={'SAC-Full':'#267a58','PPO':'#b43562','DQN':'#346ab2','fixed_rule':'#222222','SAC-NoSocial':'#9b7200'}
def read(name):
    with (O/name).open(newline='',encoding='utf-8') as f:return list(csv.DictReader(f))
def sensitivity():
    rows=read('R2_SENSITIVITY_SUMMARY.csv')
    fig,axes=plt.subplots(1,3,figsize=(13,4),sharey=True,layout='constrained')
    profiles=[['mix_low','base','mix_high'],['accuracy_low','base','accuracy_high'],['ema_slow','base','ema_fast']]
    for ax,ps,title in zip(axes,profiles,['Fraud-capable mixture','Reviewer accuracy shift','Perception EMA alpha']):
        for v,color in COLORS.items():
            rs=[next(r for r in rows if r['profile']==p and r['algorithm']==v and r['metric']=='leakage') for p in ps]
            ys=np.array([float(r['mean'])*100 for r in rs]);lo=np.array([float(r['ci95_low'])*100 for r in rs]);hi=np.array([float(r['ci95_high'])*100 for r in rs])
            ax.errorbar(range(3),ys,yerr=[ys-lo,hi-ys],label=v,c=color,marker='o',capsize=2,lw=1)
        ax.set_xticks(range(3),['Low','Base','High']);ax.set_title(title);ax.grid(axis='y',alpha=.2)
    axes[0].set_ylabel('Resolved-cohort leakage (%)')
    axes[-1].legend(fontsize=8,loc='best')
    fig.suptitle('Frozen uncapped-trained models under cap 5: distribution shifts\n95% crossed bootstrap intervals; CUDA inference cohort')
    fig.savefig(P/'sensitivity_leakage.png');plt.close(fig)
def cap5():
    rows=read('CAP5_POLICY_SUMMARY.csv');seeds=read('CAP5_SEED_MEANS.csv')
    fig,ax=plt.subplots(figsize=(9,5),layout='constrained')
    labels=[]
    for n,r in enumerate(x for x in rows if x['metric']=='leakage'):
        policy=r['policy'];v,condition=policy.split('/');labels.append(policy.replace('/','\n'))
        y=float(r['mean'])*100;low=float(r['ci95_low'])*100;high=float(r['ci95_high'])*100
        ax.errorbar(n,y,yerr=[[y-low],[high-y]],fmt='o',color=COLORS[v],capsize=4)
        ss=[float(s['leakage'])*100 for s in seeds if s['policy']==policy]
        ax.scatter(n+np.linspace(-.1,.1,len(ss)),ss,s=12,c=COLORS[v],alpha=.55)
    ax.set_xticks(range(len(labels)),labels,fontsize=8);ax.set_ylabel('Leakage (%)');ax.grid(axis='y',alpha=.2)
    ax.set_title('Same daily cap, not equal total labor cost\nDots: training-seed means; bars: crossed-bootstrap 95% CI')
    fig.savefig(P/'cap5_policy_comparison.png');plt.close(fig)
    fig,ax=plt.subplots(figsize=(10,5),layout='constrained')
    for policy in dict.fromkeys(s['policy'] for s in seeds):
        v,condition=policy.split('/');marker={'cap5_trained':'o','uncapped_trained':'^','tuned_rule':'s'}[condition]
        ss=[s for s in seeds if s['policy']==policy]
        xs=[float(s['audit_count']) for s in ss];ys=[float(s['leakage'])*100 for s in ss]
        ax.scatter(xs,ys,c=COLORS[v],marker=marker,s=22,alpha=.5)
        ax.scatter(np.mean(xs),np.mean(ys),c=COLORS[v],marker=marker,s=75,edgecolors='black',linewidths=.6,label=policy.replace('/',' '))
    ax.legend(loc='upper left',bbox_to_anchor=(1.01,1),fontsize=8,frameon=False)
    ax.set_xlabel('Actual dedicated audits per 60-day episode');ax.set_ylabel('Leakage (%)')
    ax.set_title('Observed operating points, not an estimated Pareto frontier\nLarge: policy mean; small: training-seed mean')
    ax.grid(alpha=.2);fig.savefig(P/'cap5_audits_leakage.png');plt.close(fig)
    curve=read('CAP5_LEARNING_CURVES.csv')
    fig,axes=plt.subplots(2,3,figsize=(12,6),layout='constrained',sharex=True)
    for j,v in enumerate(['SAC-Full','PPO','DQN']):
        for seed in range(5):
            rs=[r for r in curve if r['algorithm']==v and int(r['train_seed'])==seed]
            for k,metric in enumerate(['reward','leakage']):
                axes[k,j].plot([int(r['steps']) for r in rs],[float(r[metric])*(100 if metric=='leakage' else 1) for r in rs],label=f'Seed {seed}',alpha=.8,lw=1)
        axes[0,j].set_title(v);axes[1,j].set_xlabel('Training steps');axes[1,j].ticklabel_format(axis='x',style='sci',scilimits=(0,0))
    axes[0,0].set_ylabel('Validation reward');axes[1,0].set_ylabel('Validation leakage (%)');axes[0,-1].legend(fontsize=7)
    fig.suptitle('Five fixed validation seeds/checkpoint; no test-based checkpoint selection\nFinite-budget curves do not establish asymptotic convergence')
    fig.savefig(P/'cap5_validation_curves.png');plt.close(fig)
if __name__=='__main__':
    if (O/'R2_SENSITIVITY_SUMMARY.csv').exists():sensitivity()
    if (O/'CAP5_POLICY_SUMMARY.csv').exists():cap5()
    print('PLOTS_COMPLETE')
