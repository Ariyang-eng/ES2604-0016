"""OAT inference-only shifts; production runtime and saved models remain unchanged."""
from pathlib import Path
import argparse,json,sys,time,copy,hashlib,csv
from types import MethodType
import numpy as np
from worker import F,O,make_env,verify_core,append,sha
sys.path.insert(0,str(F/'analysis'))
from supplement_20261029 import make_config,install_audit_ema
from reimbursesim.reviewers import Reviewer
from reimbursesim.policies import encode_knobs

import os
OLD=Path(os.environ['R2_BASELINE_ROOT'])
class ShiftedReviewer(Reviewer):
    @property
    def accuracy(self):return float(np.clip(super().accuracy+self._accuracy_shift,.01,.99))
def install_accuracy(e,shift):
    for r in e.unwrapped.reviewers:r.__class__=ShiftedReviewer;r._accuracy_shift=shift
def configured(variant,profile):
    p=json.loads((O/'plan.json').read_text())['sensitivity_profiles'][profile]
    j={'scenario':'default_quarter','cap':5,'variant':variant,'interventions':p}
    return make_config(j)
def roll(predict,variant,profile,seed):
    c=configured(variant,profile);e=make_env('SAC-Full' if variant=='fixed_rule' else variant,'default_quarter',5,configs={'default_quarter':c})
    o,_=e.reset(seed=seed);p=json.loads((O/'plan.json').read_text())['sensitivity_profiles'][profile]
    if 'audit_ema_alpha' in p:install_audit_ema(e,p['audit_ema_alpha'])
    if 'reviewer_accuracy_shift' in p:install_accuracy(e,p['reviewer_accuracy_shift'])
    daily=[]
    while True:
        action=predict(o);o,r,d,t,i=e.step(action);assert i['metrics']['audit_count']<=5
        daily.append({'day':i['day'],'audits':i['metrics']['audit_count'],'reward':r})
        if d or t:
            assert d and not t and len(daily)==60
            row={'eval_seed':seed,'summary':i['episode_summary'],'daily':daily};e.close();return row
def run(v,seed,profile,device):
    import torch
    from stable_baselines3 import SAC,PPO,DQN
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    verify_core();out=O/'sensitivity_results'/f'{v}_{seed}_{profile}';out.mkdir(parents=True,exist_ok=False)
    t=time.time();p=json.loads((O/'plan.json').read_text())
    if v=='fixed_rule':
        src=OLD/'results/rules/fixed_rule/cap_5';m=json.loads((src/'metadata.json').read_text());assert m['validation_seeds']==list(range(100,105)) and m['evaluation_seeds']==list(range(200,300))
        knobs=json.loads((src/'selected.json').read_text())['knobs'];a=encode_knobs(knobs);predict=lambda _:a;modelhash=sha(src/'selected.json')
    else:
        src=OLD/'results/formal'/f'{v}_seed{seed}'
        assert (src/'COMPLETED').read_text().strip()==verify_core()['sha256']
        evidence=list(csv.DictReader((O/'TRAINING_EVIDENCE.csv').open()))
        h=next(r['model_sha256'] for r in evidence if r['variant']==v and r['backend']=='cpu' and int(r['train_seed'])==seed)
        assert sha(src/'final_model.zip')==h
        cls={'PPO':PPO,'DQN':DQN}.get(v,SAC);model=cls.load(src/'final_model.zip',device=device)
        assert str(model.device).startswith(device)
        predict=lambda o:model.predict(o,deterministic=True)[0];modelhash=h
    metadata={'variant':v,'train_seed':seed,'profile':profile,'interventions':p['sensitivity_profiles'][profile],'training_distribution':'uncapped default CPU training; no retraining','test_cap':5,'inference_device':device,'model_or_rule_sha256':modelhash,'config':configured(v,profile).__dict__,'seeds':list(range(2000,2100)),'status':'RUNNING','worker_sha256':sha(Path(__file__))}
    # Dataclass configs can contain nested stress objects; principal scenario has none.
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2))
    for s in metadata['seeds']:
        row=roll(predict,v,profile,s);row.update(variant=v,train_seed=seed,profile=profile,inference_device=device);append(out/'episodes.jsonl',row)
    verify_core();metadata.update(status='COMPLETED',wall_seconds=time.time()-t,results_sha256=sha(out/'episodes.jsonl'))
    (out/'metadata.json').write_text(json.dumps(metadata,indent=2));(out/'COMPLETED').write_text(metadata['results_sha256'])
    print('COMPLETE',out.name,metadata['wall_seconds'],flush=True)
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--variant',required=True);p.add_argument('--seed',type=int,default=-1);p.add_argument('--profile',required=True);p.add_argument('--device',default='cuda');a=p.parse_args();run(a.variant,a.seed,a.profile,a.device)
