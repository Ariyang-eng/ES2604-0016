"""Separate, fixed-model R1 tail, settlement and design-sensitivity evaluation."""

import argparse
from copy import deepcopy
from dataclasses import asdict
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import time
from types import MethodType

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts/r1"))

from reimbursesim.applicants import Applicant
from reimbursesim.config import load_scenario
from reimbursesim.models import ClaimStatus
from reimbursesim.policies import encode_knobs
from train import make_env, source_manifest

SOURCE = "9f04de872f4f912f90be9349a15865cb7088c281b7dbc38cc9436d89163d3fae"
STRESS = ["default_quarter", "stress_fraud_burst", "stress_reviewer_shortage"]
CAPS = [None, 5, 10, 20, 40]
DEFAULT_ONLY = ["SAC-NoSocial", "PPO", "DQN"]
SENSITIVITIES = {"mix_low": {"fraud_capable_mix_factor": 0.5},
                 "mix_high": {"fraud_capable_mix_factor": 1.5},
                 "ema_slow": {"audit_ema_alpha": 0.1},
                 "ema_fast": {"audit_ema_alpha": 0.7}}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def atomic_json(path, value):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def build_jobs(smoke=False):
    jobs = []
    def add(phase, backend, variant, train_seed, scenario, cap, n, seed_start, sensitivity=None):
        sensitivity = sensitivity or "base"
        key = "_".join(map(str, [phase, backend, variant, train_seed, scenario,
                                  "unlimited" if cap is None else f"cap{cap}", sensitivity]))
        jobs.append(dict(key=key, phase=phase, backend=backend, variant=variant,
            train_seed=train_seed, scenario=scenario, cap=cap, episodes=n,
            seed_start=seed_start, sensitivity=sensitivity,
            interventions=SENSITIVITIES.get(sensitivity, {}), settlement_max_days=30 if phase == "settlement" else 0))
    for phase, n, start in [("tail", 1000, 1000), ("settlement", 100, 200)]:
        for variant in ["SAC-Full", "SAC-NoRisk", *DEFAULT_ONLY, "fixed_rule"]:
            scenarios = STRESS if variant in {"SAC-Full", "SAC-NoRisk", "fixed_rule"} else STRESS[:1]
            for seed in [None] if variant == "fixed_rule" else range(5):
                for scenario in scenarios:
                    for cap in CAPS:
                        add(phase, "cpu", variant, seed, scenario, cap, n, start)
    for variant in ["SAC-Full", "SAC-NoRisk", "SAC-NoSocial"]:
        for seed in range(5):
            for cap in CAPS:
                add("tail", "cuda", variant, seed, "default_quarter", cap, 1000, 1000)
    for variant in ["SAC-Full", "SAC-NoRisk", "SAC-NoSocial", "fixed_rule"]:
        for seed in [None] if variant == "fixed_rule" else range(5):
            for name in SENSITIVITIES:
                for cap in [None, 10]:
                    add("sensitivity", "cpu", variant, seed, "default_quarter", cap, 100, 2000, name)
    assert len({j["key"] for j in jobs}) == len(jobs) == 683
    if smoke:
        chosen = []
        for phase, backend, variant, sensitivity in [
            ("tail", "cpu", "DQN", "base"), ("tail", "cpu", "PPO", "base"),
            ("tail", "cpu", "SAC-NoSocial", "base"), ("tail", "cpu", "SAC-NoRisk", "base"),
            ("tail", "cuda", "SAC-Full", "base"), ("tail", "cuda", "SAC-NoSocial", "base"),
            ("settlement", "cpu", "SAC-Full", "base"),
            ("settlement", "cpu", "fixed_rule", "base"),
            ("sensitivity", "cpu", "SAC-NoSocial", "ema_slow"),
            ("sensitivity", "cpu", "SAC-Full", "mix_high")]:
            smoke_cap = None if backend == "cuda" else 5
            j = next(j for j in jobs if (j["phase"], j["backend"], j["variant"], j["sensitivity"])
                     == (phase, backend, variant, sensitivity) and j["cap"] == 5
                     ) if phase not in {"sensitivity", "tail"} else next(j for j in jobs if
                     (j["phase"], j["backend"], j["variant"], j["sensitivity"], j["cap"])
                     == (phase, backend, variant, sensitivity, 10 if phase == "sensitivity" else smoke_cap))
            chosen.append(dict(j, key="smoke_" + j["key"], episodes=2, seed_start=200))
        return chosen
    return jobs


def make_config(job):
    config = load_scenario(ROOT / "configs" / f"{job['scenario']}.yaml")
    config.audit_cap_per_day = job["cap"]
    if job["variant"] == "SAC-NoRisk":
        config.reward_weights["w_rolling_max"] = 0.0
    factor = job.get("interventions", {}).get("fraud_capable_mix_factor")
    if factor is not None:
        if factor not in {0.5, 1.5}:
            raise ValueError("Only declared mixture factors are allowed")
        for name in ["strategic_prober", "opportunistic_splitter", "fraudulent_burst"]:
            config.applicant_mix[name] *= factor
        config.applicant_mix["honest"] = 1.0 - sum(v for k, v in config.applicant_mix.items() if k != "honest")
        config.__post_init__()
    return config


def install_audit_ema(env, alpha):
    if not 0 < alpha <= 1:
        raise ValueError("EMA weight must be in (0,1]")
    def adapt(self, day, global_audit_intensity, max_approved_amount_recent):
        old = self.perceived_audit_intensity
        Applicant.adapt(self, day, global_audit_intensity, max_approved_amount_recent)
        if self.enable_adaptation:
            self.perceived_audit_intensity = (1 - alpha) * old + alpha * global_audit_intensity
    for applicant in env.unwrapped.applicants:
        applicant.adapt = MethodType(adapt, applicant)


def stop_new_submissions(env):
    def no_claims(self, *args, **kwargs):
        return []
    for applicant in env.unwrapped.applicants:
        applicant.generate_claims = MethodType(no_claims, applicant)


def snapshot(env):
    base = env.unwrapped
    pending = [c for c in base.claims.values() if c.status not in (ClaimStatus.APPROVED, ClaimStatus.REJECTED)]
    base.summary.unresolved_claims = len(pending)
    base.summary.unresolved_amount = sum(c.amount for c in pending)
    base.summary.unresolved_fraud_claims = sum(c.is_fraudulent for c in pending)
    base.summary.unresolved_fraud_amount = sum(c.amount for c in pending if c.is_fraudulent)
    return deepcopy(base.summary.as_dict())


def evaluate(job, predict, seed, config):
    variant = "SAC-Full" if job["variant"] == "fixed_rule" else job["variant"]
    env = make_env(variant, job["scenario"], job["cap"], configs={job["scenario"]: config})
    obs, _ = env.reset(seed=seed)
    alpha = job.get("interventions", {}).get("audit_ema_alpha")
    if alpha is not None:
        install_audit_ema(env, alpha)
    for _ in range(60):
        obs, _, done, truncated, info = env.step(predict(obs))
    if not done or truncated or env.unwrapped.day != 60:
        raise RuntimeError("The primary prefix must be exactly 60 working days")
    prefix = deepcopy(info["episode_summary"])
    row = dict(evaluation_seed=seed, summary=prefix)
    if job["phase"] == "settlement":
        frozen_claim_ids = set(env.unwrapped.claims)
        stop_new_submissions(env)
        env.unwrapped.config.episode_length = 60 + job["settlement_max_days"]
        days = 0
        while snapshot(env)["unresolved_claims"] and days < job["settlement_max_days"]:
            obs, _, _, _, _ = env.step(predict(obs))
            days += 1
        settled = snapshot(env)
        if set(env.unwrapped.claims) != frozen_claim_ids:
            raise RuntimeError("Settling phase added claims to the frozen submitted cohort")
        for name in ["total_claims", "total_fraud_claims", "total_fraud_amount"]:
            if settled[name] != prefix[name]:
                raise RuntimeError("Submitted cohort changed during settlement")
        row.update(settled_summary=settled, settlement_days=days,
                   additional_audits=settled["audit_count"] - prefix["audit_count"],
                   cohort_fully_settled=settled["unresolved_claims"] == 0,
                   same_operational_budget_as_primary=False)
    env.close()
    return row


def create_plan(smoke):
    source = source_manifest()
    if source["sha256"] != SOURCE:
        raise RuntimeError("Frozen R1 source changed")
    own_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    root = f"results/r1_supplement_smoke_20261029_{own_hash[:8]}" if smoke else "results/r1_supplement_20261029"
    out = ROOT / root
    out.mkdir(parents=True, exist_ok=False)
    jobs = build_jobs(smoke)
    for job in jobs:
        job["out"] = f"{root}/{job['key']}"
    artifacts = {}
    for job in jobs:
        paths = []
        if job["variant"] == "fixed_rule":
            capname = "unlimited" if job["cap"] is None else f"cap_{job['cap']}"
            paths.append(Path("results/rules/fixed_rule") / capname / "selected.json")
        else:
            directory = "backend_cuda_verification" if job["backend"] == "cuda" else "formal"
            run = Path("results") / directory / f"{job['variant']}_seed{job['train_seed']}"
            paths.extend([run / "final_model.zip", run / "run.json"])
        for path in paths:
            if path.as_posix() not in artifacts:
                artifacts[path.as_posix()] = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
    plan = dict(protocol="R1-supplement-20261029-v1", smoke=smoke, source_sha256=SOURCE,
        worker_sha256=own_hash, output_root=root,
        post_review_supplement=True, primary_results_unchanged=True,
        tail_seed_prefixes=[100, 200, 500, 1000], bootstrap_draws=5000,
        design_sensitivity_not_empirical_calibration=True,
        no_test_based_model_or_checkpoint_selection=True, frozen_artifacts=artifacts, jobs=jobs)
    path = out / "plan.json"
    with path.open("x", encoding="utf-8") as f:
        json.dump(plan, f, indent=2)
        f.write("\n")
    print(json.dumps(dict(path=str(path), jobs=len(jobs), episodes=sum(j["episodes"] for j in jobs), plan_sha256=digest(plan))), flush=True)


def reference_rows(job):
    capname = "unlimited" if job["cap"] is None else f"cap_{job['cap']}"
    if job["variant"] == "fixed_rule":
        path = ROOT / "results/rules/fixed_rule" / capname / "evaluation.jsonl"
    else:
        directory = ("backend_cuda_verification" if job["backend"] == "cuda" else "formal") if job["cap"] is None else "resource_matched"
        path = ROOT / "results" / directory / f"{job['variant']}_seed{job['train_seed']}" / "evaluation.jsonl"
    records = {}
    with path.open() as f:
        for line in f:
            row = json.loads(line)
            if row["scenario"] == job["scenario"] and row.get("audit_cap_per_day") == job["cap"]:
                if row["evaluation_seed"] in records:
                    raise RuntimeError("Duplicate primary prefix reference")
                records[row["evaluation_seed"]] = row["summary"]
    validate_reference_seeds(records, job)
    return records


def validate_reference_seeds(records, job):
    expected = set(range(job["seed_start"], job["seed_start"] + job["episodes"]))
    if not expected.issubset(records):
        raise RuntimeError("Missing primary prefix reference seeds")


def check_prefix(actual, expected):
    if set(actual) != set(expected):
        raise RuntimeError("Prefix summary fields differ")
    for name, value in actual.items():
        other = expected[name]
        if isinstance(value, (int, float)) and not isinstance(value, bool):
            if not math.isclose(value, other, rel_tol=1e-12, abs_tol=1e-9):
                raise RuntimeError(f"Primary prefix changed: {name}: {value} != {other}")
        elif value != other:
            raise RuntimeError(f"Primary prefix changed: {name}")


def worker(plan_path, index):
    import torch
    from stable_baselines3 import DDPG, DQN, PPO, SAC, TD3
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    plan = json.loads(plan_path.read_text())
    own_hash = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if source_manifest()["sha256"] != SOURCE or plan["worker_sha256"] != own_hash:
        raise RuntimeError("Evaluation source mismatch")
    job = plan["jobs"][index]
    out = ROOT / job["out"]
    if not out.resolve().is_relative_to(ROOT / "results"):
        raise RuntimeError("Output must remain in this project's results")
    out.mkdir(parents=True, exist_ok=False)
    device = "cuda:0" if job["backend"] == "cuda" else "cpu"
    if device.startswith("cuda"):
        if not torch.cuda.is_available():
            raise RuntimeError("No CPU fallback for a CUDA cohort")
        torch.cuda.set_per_process_memory_fraction(0.12)
    metadata = dict(job=job, job_sha256=digest(job), protocol=plan["protocol"],
        smoke=plan["smoke"], simulator_source_sha256=SOURCE, worker_sha256=own_hash,
        torch=torch.__version__, requested_device=device, evaluation_only=True,
        no_retraining=True, in_primary_500k_report=False,
        expanded_config=asdict(make_config(job)), visible_gpu=os.environ.get("CUDA_VISIBLE_DEVICES"),
        runtime_overrides=dict(audit_ema_alpha=job["interventions"].get("audit_ema_alpha", 0.4),
            horizon_before_day60=60, horizon_after_day60=60 + job["settlement_max_days"],
            horizon_observation_normalization_changes_only_after_day60=job["phase"] == "settlement",
            settlement_policy="original controller, no new submissions" if job["phase"] == "settlement" else None))
    if job["variant"] == "fixed_rule":
        capname = "unlimited" if job["cap"] is None else f"cap_{job['cap']}"
        selected = ROOT / "results/rules/fixed_rule" / capname / "selected.json"
        if hashlib.sha256(selected.read_bytes()).hexdigest() != plan["frozen_artifacts"][selected.relative_to(ROOT).as_posix()]:
            raise RuntimeError("Frozen selected rule changed")
        knobs = json.loads(selected.read_text())["knobs"]
        action = encode_knobs(knobs)
        predict = lambda obs: action
        metadata.update(selected_rule=knobs, selected_rule_sha256=hashlib.sha256(selected.read_bytes()).hexdigest())
    else:
        directory = "backend_cuda_verification" if job["backend"] == "cuda" else "formal"
        run = ROOT / "results" / directory / f"{job['variant']}_seed{job['train_seed']}"
        training = json.loads((run / "run.json").read_text())
        if ((run / "COMPLETED").read_text().strip() != SOURCE or training["status"] != "completed"
                or training["actual_training_steps"] < 500000 or training["train_seed"] != job["train_seed"]):
            raise RuntimeError("Formal completed source model required")
        if job["backend"] == "cuda" and not (run / "BACKEND_VERIFIED").exists():
            raise RuntimeError("CUDA source cohort is not verified")
        cls = {"DQN": DQN, "PPO": PPO, "DDPG": DDPG, "TD3": TD3}.get(job["variant"], SAC)
        path = run / "final_model.zip"
        for frozen in [path, run / "run.json"]:
            if hashlib.sha256(frozen.read_bytes()).hexdigest() != plan["frozen_artifacts"][frozen.relative_to(ROOT).as_posix()]:
                raise RuntimeError("Frozen model artifact changed")
        model = cls.load(path, device=device)
        observed = sorted({str(p.device) for p in model.policy.parameters()})
        if observed != [device]:
            raise RuntimeError("Actual policy device mismatch")
        metadata.update(model_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
            model_path=path.relative_to(ROOT).as_posix(), actual_training_steps=training["actual_training_steps"],
            observed_policy_devices=observed)
        predict = lambda obs: model.predict(obs, deterministic=True)[0]
    atomic_json(out / "metadata.json", metadata)
    start = time.monotonic()
    config = make_config(job)
    verify_prefixes = (job["phase"] == "settlement" or plan["smoke"]) and not job["interventions"]
    references = reference_rows(job) if verify_prefixes else {}
    prefix_checks = 0
    with gzip.open(out / "episodes.jsonl.gz", "wt", encoding="utf-8", compresslevel=1) as f:
        for i, seed in enumerate(range(job["seed_start"], job["seed_start"] + job["episodes"]), 1):
            row = evaluate(job, predict, seed, config)
            if verify_prefixes:
                check_prefix(row["summary"], references[seed])
                prefix_checks += 1
            f.write(json.dumps(row, allow_nan=False, separators=(",", ":")) + "\n")
            if i % 50 == 0 or i == job["episodes"]:
                f.flush()
                atomic_json(out / "progress.json", dict(episodes_done=i, wall_seconds=time.monotonic() - start))
                print(json.dumps(dict(job=job["key"], episodes=i, wall_seconds=round(time.monotonic() - start, 2))), flush=True)
    if source_manifest()["sha256"] != SOURCE or hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != own_hash:
        raise RuntimeError("Source changed during supplemental evaluation")
    if verify_prefixes and prefix_checks != job["episodes"]:
        raise RuntimeError("Not all primary prefixes were verified")
    metadata.update(status="completed", episodes=job["episodes"], primary_prefix_reference_checks=prefix_checks,
        wall_seconds=time.monotonic() - start,
        episodes_sha256=hashlib.sha256((out / "episodes.jsonl.gz").read_bytes()).hexdigest())
    atomic_json(out / "metadata.json", metadata)
    (out / "COMPLETED").write_text(digest(job) + "\n", encoding="ascii")


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("command", choices=["plan", "worker"])
    p.add_argument("--smoke", action="store_true")
    p.add_argument("--plan", type=Path)
    p.add_argument("--index", type=int)
    args = p.parse_args()
    if args.command == "plan":
        create_plan(args.smoke)
    else:
        worker(args.plan, args.index)
