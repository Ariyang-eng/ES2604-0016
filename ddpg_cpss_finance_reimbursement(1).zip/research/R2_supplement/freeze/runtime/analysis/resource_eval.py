"""Evaluate a completed independent model with held-out daily audit caps."""

import argparse
import hashlib
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts/r1"))

from reimbursesim.config import ScenarioConfig
from train import append_json, rollout, source_manifest


def run(args):
    import torch
    from stable_baselines3 import DDPG, DQN, PPO, SAC, TD3

    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    source = source_manifest()
    run_dir = args.run.resolve()
    expected = ROOT / ("results/smoke" if args.smoke else "results/formal")
    if not run_dir.is_relative_to(expected):
        raise ValueError("Model run directory does not match formal/smoke mode")
    metadata = json.loads((run_dir / "run.json").read_text())
    if (run_dir / "COMPLETED").read_text().strip() != source["sha256"]:
        raise ValueError("Completed model source does not match simulator")
    expected_mode = "smoke" if args.smoke else "formal"
    minimum_steps = 2048 if args.smoke else 500_000
    if metadata["mode"] != expected_mode or metadata["actual_training_steps"] < minimum_steps:
        raise ValueError("Smoke or partial training cannot enter a formal resource comparison")
    variant = metadata["variant"]
    cls = {"DQN": DQN, "PPO": PPO, "PPO-Quantized": PPO,
           "DDPG": DDPG, "TD3": TD3}.get(variant, SAC)
    model = cls.load(run_dir / "final_model.zip", device="cpu")
    configs = {s: ScenarioConfig(**c) for s, c in metadata["evaluation_configs"].items()}
    out = ROOT / ("results/resource_smoke" if args.smoke else "results/resource_matched") / run_dir.name
    out.mkdir(parents=True, exist_ok=False)
    (out / "metadata.json").write_text(json.dumps({"revision": "R1", "variant": variant,
        "train_seed": metadata["train_seed"], "mode": "resource_smoke" if args.smoke else "resource_matched",
        "training_source_sha256": source["sha256"],
        "analysis_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "model_sha256": hashlib.sha256((run_dir / "final_model.zip").read_bytes()).hexdigest(),
        "daily_caps": [5, 10, 20, 40], "interpretation": "evaluation-time caps, not budget-specific retraining"}, indent=2) + "\n")
    for cap in [5, 10, 20, 40]:
        for scenario in configs:
            for seed in metadata["final_evaluation_seeds"]:
                row = rollout(model, variant, scenario, seed, cap=cap, configs=configs)
                row.update(variant=variant, train_seed=metadata["train_seed"])
                append_json(out / "evaluation.jsonl", row)
        print(json.dumps({"event": "cap_completed", "model": run_dir.name, "cap": cap}), flush=True)
    if source_manifest() != source:
        raise RuntimeError("Simulator changed while evaluating resources")
    (out / "COMPLETED").write_text(source["sha256"] + "\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    run(parser.parse_args())
