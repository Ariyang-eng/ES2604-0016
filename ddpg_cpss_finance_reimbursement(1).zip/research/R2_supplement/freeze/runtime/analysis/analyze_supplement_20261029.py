"""Validate and analyze the separately frozen post-review evaluation cohort."""

import argparse
from collections import defaultdict
import csv
import gzip
import hashlib
import json
import math
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = "9f04de872f4f912f90be9349a15865cb7088c281b7dbc38cc9436d89163d3fae"
METRICS = ["leakage_rate", "fraud_catch_rate", "audit_count", "false_alarm_rate", "mean_cycle_time",
           "sla_violation_rate", "appeal_rate", "unresolved_claims", "unresolved_fraud_amount",
           "fraud_value_resolution_fraction", "resolution_fraction", "submitted_leakage_lower_bound",
           "submitted_leakage_upper_bound", "total_claims", "total_fraud_claims", "total_fraud_amount"]
PREFIXES = [100, 200, 500, 1000]
STRESS = ["default_quarter", "stress_fraud_burst", "stress_reviewer_shortage"]
CAPS = [None, 5, 10, 20, 40]
COHORTS = {
    "leakage_rate": ("leakage_rate_defined", "resolved_fraud_amount"),
    "fraud_catch_rate": ("fraud_catch_rate_defined", "resolved_fraud_claims"),
    "false_alarm_rate": ("false_alarm_rate_defined", "resolved_legitimate_claims"),
    "submitted_leakage_lower_bound": ("submitted_fraud_cohort_defined", "total_fraud_amount"),
    "submitted_leakage_upper_bound": ("submitted_fraud_cohort_defined", "total_fraud_amount"),
    "fraud_value_resolution_fraction": ("submitted_fraud_cohort_defined", "total_fraud_amount"),
    "resolution_fraction": (None, "total_claims"),
    "sla_violation_rate": (None, "total_claims"),
    "appeal_rate": (None, "total_claims"),
    "mean_cycle_time": (None, "resolved_claims"),
}


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()


def file_hash(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def group_key(job):
    return job["phase"], job["backend"], job["scenario"], job["cap"], job["sensitivity"], job["variant"]


def describe(key):
    return dict(zip(["phase", "backend", "scenario", "cap", "sensitivity", "variant"], key))


def check_summary(s):
    if s["metric_version"] != "R1-resolved-cohort-v1":
        raise ValueError("Unknown outcome metric version")
    for total, resolved, pending in [("total_claims", "resolved_claims", "unresolved_claims"),
            ("total_fraud_claims", "resolved_fraud_claims", "unresolved_fraud_claims"),
            ("total_fraud_amount", "resolved_fraud_amount", "unresolved_fraud_amount")]:
        if not math.isclose(s[total], s[resolved] + s[pending], rel_tol=1e-10, abs_tol=1e-8):
            raise ValueError("Submitted/resolved/pending accounting mismatch")
    if s["leakage_rate_defined"]:
        expected = s["total_leakage_amount"] / s["resolved_fraud_amount"]
        if not math.isclose(s["leakage_rate"], expected, rel_tol=1e-10, abs_tol=1e-12):
            raise ValueError("Resolved leakage denominator mismatch")
    if s["total_fraud_amount"] > 0:
        lower = s["total_leakage_amount"] / s["total_fraud_amount"]
        upper = (s["total_leakage_amount"] + s["unresolved_fraud_amount"]) / s["total_fraud_amount"]
        if not np.allclose([s["submitted_leakage_lower_bound"], s["submitted_leakage_upper_bound"]],
                           [lower, upper], rtol=1e-10, atol=1e-12):
            raise ValueError("Submitted leakage bounds mismatch")


def metric(s, name):
    if name in COHORTS:
        flag, denominator = COHORTS[name]
        defined = s[denominator] > 0
        if flag is not None and (flag not in s or type(s[flag]) is not bool or s[flag] != defined):
            raise ValueError("Missing or contradictory cohort definition flag")
        if not defined:
            return float("nan")
    value = float(s[name])
    if not math.isfinite(value):
        raise ValueError("Nonfinite reported outcome")
    return value


def validate_input(root, job, plan):
    directory = root / job["out"]
    if not directory.resolve().is_relative_to((root / plan["output_root"]).resolve()):
        raise ValueError("Input escaped its frozen cohort")
    meta = json.loads((directory / "metadata.json").read_text())
    required = dict(status="completed", episodes=job["episodes"], job_sha256=digest(job),
                    protocol=plan["protocol"], worker_sha256=plan["worker_sha256"],
                    simulator_source_sha256=SOURCE, smoke=False, no_retraining=True,
                    evaluation_only=True, in_primary_500k_report=False)
    if any(meta.get(k) != value for k, value in required.items()):
        raise ValueError("Incomplete, smoke, altered or incompatible metadata")
    if meta["job"] != job or (directory / "COMPLETED").read_text().strip() != digest(job):
        raise ValueError("Job identity mismatch")
    if job["phase"] == "settlement" and meta["primary_prefix_reference_checks"] != job["episodes"]:
        raise ValueError("Primary prefix reference checks incomplete")
    if job["variant"] == "fixed_rule":
        cap = "unlimited" if job["cap"] is None else f"cap_{job['cap']}"
        artifact = f"results/rules/fixed_rule/{cap}/selected.json"
        if meta["selected_rule_sha256"] != plan["frozen_artifacts"][artifact]:
            raise ValueError("Selected-rule provenance mismatch")
    else:
        device = "cpu" if job["backend"] == "cpu" else "cuda:0"
        if meta["observed_policy_devices"] != [device] or meta["requested_device"] != device:
            raise ValueError("Backend cohort mismatch")
        family = "formal" if job["backend"] == "cpu" else "backend_cuda_verification"
        expected_model = f"results/{family}/{job['variant']}_seed{job['train_seed']}/final_model.zip"
        if meta["model_path"] != expected_model:
            raise ValueError("Model path does not match the job variant, seed and backend")
        if meta["model_sha256"] != plan["frozen_artifacts"][expected_model]:
            raise ValueError("Model provenance mismatch")
    path = directory / "episodes.jsonl.gz"
    if file_hash(path) != meta["episodes_sha256"]:
        raise ValueError("Episode file content hash mismatch")
    return meta, path


def load_groups(root, plan):
    grouped = defaultdict(dict)
    provenance = []
    total = 0
    for index, job in enumerate(plan["jobs"]):
        meta, path = validate_input(root, job, plan)
        summaries = {m: [] for m in METRICS}
        settled = {m: [] for m in METRICS}
        extras = defaultdict(list)
        seen = set()
        with gzip.open(path, "rt", encoding="utf-8") as f:
            for line in f:
                row = json.loads(line)
                if row["evaluation_seed"] in seen:
                    raise ValueError("Duplicate evaluation seed")
                seen.add(row["evaluation_seed"])
                check_summary(row["summary"])
                for m in METRICS:
                    summaries[m].append(metric(row["summary"], m))
                if job["phase"] == "settlement":
                    final = row["settled_summary"]
                    check_summary(final)
                    for name in ["total_claims", "total_fraud_claims", "total_fraud_amount"]:
                        if row["summary"][name] != final[name]:
                            raise ValueError("Settled submitted cohort changed")
                    if row["same_operational_budget_as_primary"] is not False:
                        raise ValueError("Settlement must not be presented as equal-budget")
                    if row["cohort_fully_settled"] != (final["unresolved_claims"] == 0):
                        raise ValueError("False cohort-clearing indicator")
                    if not 0 <= row["settlement_days"] <= 30 or row["additional_audits"] < 0:
                        raise ValueError("Invalid settlement duration or audit count")
                    if not math.isclose(final["audit_count"] - row["summary"]["audit_count"],
                                        row["additional_audits"], abs_tol=1e-9):
                        raise ValueError("Settlement audit accounting mismatch")
                    for m in METRICS:
                        settled[m].append(metric(final, m))
                    for m in ["settlement_days", "additional_audits", "cohort_fully_settled"]:
                        extras[m].append(row[m])
        expected = set(range(job["seed_start"], job["seed_start"] + job["episodes"]))
        if seen != expected:
            raise ValueError("Incomplete held-out seed coverage")
        # Preserve numeric seed order even if a future writer emits records out of order.
        with gzip.open(path, "rt", encoding="utf-8") as f:
            order = np.argsort([json.loads(line)["evaluation_seed"] for line in f])
        data = dict(primary={m: np.asarray(a)[order] for m, a in summaries.items()})
        if job["phase"] == "settlement":
            data.update(settled={m: np.asarray(a)[order] for m, a in settled.items()},
                        extras={m: np.asarray(a)[order] for m, a in extras.items()})
        key = group_key(job)
        seed = job["train_seed"]
        if seed in grouped[key]:
            raise ValueError("Duplicate model/condition job")
        grouped[key][seed] = data
        provenance.append(dict(index=index, key=job["key"], episodes=job["episodes"],
            data_sha256=meta["episodes_sha256"], metadata_sha256=file_hash(path.with_name("metadata.json")),
            model_sha256=meta.get("model_sha256"), selected_rule_sha256=meta.get("selected_rule_sha256")))
        total += job["episodes"]
    result = {}
    for key, seeds in grouped.items():
        required = [None] if key[-1] == "fixed_rule" else list(range(5))
        if set(seeds) != set(required):
            raise ValueError("Incomplete independent training seeds")
        result[key] = {part: {m: np.stack([seeds[s][part][m] for s in required])
                             for m in seeds[required[0]][part]}
                       for part in seeds[required[0]]}
    if total != 351800 or len(provenance) != 683:
        raise ValueError("Full declared supplement required; partial results cannot be signed complete")
    return result, provenance


def upper_tail(a):
    k = int(math.ceil(.05 * a.shape[1]))
    return np.partition(a, a.shape[1] - k, axis=1)[:, -k:].mean(axis=1)


def bootstrap(a, *, draws=5000, seed=7301, tail=False):
    a = np.asarray(a, dtype=float)
    if a.ndim != 2 or a.shape[0] not in {1, 5} or not np.all(np.isfinite(a)):
        raise ValueError("Bootstrap requires complete finite rule or five-model matrices")
    rng = np.random.default_rng(seed)
    train = rng.integers(0, 5, (draws, 5))
    rollout = rng.integers(0, a.shape[1], (draws, a.shape[1]))
    estimates = np.empty(draws)
    for start in range(0, draws, 64):
        stop = min(draws, start + 64)
        sampled = a[:, rollout[start:stop]].transpose(1, 0, 2)
        if tail:
            k = int(math.ceil(.05 * a.shape[1]))
            values = np.partition(sampled, a.shape[1] - k, axis=2)[:, :, -k:].mean(axis=2)
        else:
            values = sampled.mean(axis=2)
        indices = train[start:stop] if a.shape[0] == 5 else np.zeros((stop-start, 1), dtype=int)
        estimates[start:stop] = np.take_along_axis(values, indices, axis=1).mean(axis=1)
    return estimates


def interval(draws):
    return np.quantile(draws, [.025, .975]).tolist()


def summarize(matrices):
    values, undefined = {}, {}
    for name, a in matrices.items():
        finite = np.isfinite(a)
        undefined[name] = int((~finite).sum())
        values[name] = float(a[finite].mean()) if finite.any() else None
    prevalence = np.divide(matrices["total_fraud_claims"], matrices["total_claims"],
                           out=np.full_like(matrices["total_claims"], np.nan, dtype=float),
                           where=matrices["total_claims"] > 0)
    valid = np.isfinite(prevalence)
    values["realized_fraud_claim_fraction"] = float(prevalence[valid].mean()) if valid.any() else None
    undefined["realized_fraud_claim_fraction"] = int((~valid).sum())
    return dict(means=values, undefined_counts=undefined,
                means_with_undefined_are_conditional_and_not_complete_pair_estimates=True)


def tail_analysis(groups, draws):
    rows, cached = [], {}
    for key, parts in groups.items():
        if key[0] != "tail":
            continue
        matrices = parts["primary"]
        for n in PREFIXES:
            a = matrices["leakage_rate"][:, :n]
            base = dict(**describe(key), rollouts_per_model=n,
                        independent_training_seeds=0 if a.shape[0] == 1 else 5,
                        tail_observations_per_model=int(math.ceil(.05*n)),
                        **summarize({m: v[:, :n] for m, v in matrices.items()}))
            if not np.all(np.isfinite(a)):
                rows.append(dict(base, tail_mean=None, tail_ci95=None, status="undefined_cohort_metric"))
                continue
            btail = bootstrap(a, draws=draws, tail=True)
            bmean = bootstrap(a, draws=draws)
            baudit = bootstrap(matrices["audit_count"][:, :n], draws=draws)
            cached[(key, n)] = dict(tail=btail, leakage=bmean, audit=baudit)
            rows.append(dict(base, tail_mean=float(upper_tail(a).mean()),
                seed_tail_means=upper_tail(a).tolist(), tail_ci95=interval(btail),
                leakage_ci95=interval(bmean), audit_ci95=interval(baudit), status="computed"))
    comparisons = []
    for backend, scenario, left, right, priority in [
            *[("cpu", s, "SAC-NoRisk", "SAC-Full", "declared_supplement_primary") for s in STRESS],
            *[("cpu", "default_quarter", a, b, "secondary_exploratory") for a, b in
              [("SAC-NoSocial", "SAC-Full"), ("PPO", "SAC-Full"), ("SAC-Full", "DQN"), ("SAC-Full", "fixed_rule")]],
            ("cuda", "default_quarter", "SAC-NoRisk", "SAC-Full", "secondary_exploratory"),
            ("cuda", "default_quarter", "SAC-NoSocial", "SAC-Full", "secondary_exploratory")]:
        for cap in CAPS:
            left_key = ("tail", backend, scenario, cap, "base", left)
            right_key = ("tail", backend, scenario, cap, "base", right)
            for n in PREFIXES:
                row = dict(backend=backend, scenario=scenario, cap=cap, left=left, right=right,
                    priority=priority, rollouts_per_model=n, multiplicity_adjusted=False,
                    rule_baseline_has_training_seeds=False if right == "fixed_rule" else None)
                if (left_key, n) not in cached or (right_key, n) not in cached:
                    comparisons.append(dict(row, status="undefined_cohort_metric", tail_delta=None, tail_ci95=None))
                    continue
                a, b = groups[left_key]["primary"], groups[right_key]["primary"]
                ca, cb = cached[(left_key, n)], cached[(right_key, n)]
                comparisons.append(dict(row, status="computed",
                    tail_delta=float((upper_tail(a["leakage_rate"][:, :n]) - upper_tail(b["leakage_rate"][:, :n])).mean()),
                    tail_ci95=interval(ca["tail"] - cb["tail"]),
                    leakage_delta=float(a["leakage_rate"][:, :n].mean() - b["leakage_rate"][:, :n].mean()),
                    leakage_ci95=interval(ca["leakage"] - cb["leakage"]),
                    audit_delta=float(a["audit_count"][:, :n].mean() - b["audit_count"][:, :n].mean()),
                    audit_ci95=interval(ca["audit"] - cb["audit"])))
    return rows, comparisons


def settlement_analysis(groups):
    rows = []
    for key, parts in groups.items():
        if key[0] != "settlement":
            continue
        extra = parts["extras"]
        rows.append(dict(**describe(key), independent_training_seeds=0 if key[-1] == "fixed_rule" else 5,
            rollouts_per_model=100, prefix=summarize(parts["primary"]), final=summarize(parts["settled"]),
            fully_cleared_fraction=float(extra["cohort_fully_settled"].mean()),
            mean_extension_days_including_capped_noncleared=float(extra["settlement_days"].mean()),
            mean_additional_audits=float(extra["additional_audits"].mean()),
            noncleared_episodes=int((~extra["cohort_fully_settled"].astype(bool)).sum()),
            same_operational_budget_as_primary=False, cumulative_reward_comparison_valid=False))
    return rows


def sensitivity_analysis(groups, draws):
    rows, comparisons = [], []
    for key, parts in groups.items():
        if key[0] == "sensitivity":
            rows.append(dict(**describe(key), independent_training_seeds=0 if key[-1] == "fixed_rule" else 5,
                             rollouts_per_model=100, **summarize(parts["primary"])))
    for sensitivity in ["mix_low", "mix_high", "ema_slow", "ema_fast"]:
        for cap in [None, 10]:
            for left, right in [("SAC-NoRisk", "SAC-Full"), ("SAC-NoSocial", "SAC-Full"), ("SAC-Full", "fixed_rule")]:
                k = ("sensitivity", "cpu", "default_quarter", cap, sensitivity)
                a, b = groups[(*k, left)]["primary"], groups[(*k, right)]["primary"]
                row = dict(sensitivity=sensitivity, cap=cap, left=left, right=right,
                           empirical_calibration=False, multiplicity_adjusted=False)
                if not all(np.all(np.isfinite(v["leakage_rate"])) for v in [a, b]):
                    comparisons.append(dict(row, status="undefined_cohort_metric"))
                    continue
                comparisons.append(dict(row, status="computed",
                    leakage_delta=float(a["leakage_rate"].mean() - b["leakage_rate"].mean()),
                    leakage_ci95=interval(bootstrap(a["leakage_rate"], draws=draws) - bootstrap(b["leakage_rate"], draws=draws)),
                    audit_delta=float(a["audit_count"].mean() - b["audit_count"].mean())))
    return rows, comparisons


def analyze(root, plan, draws=5000):
    if plan["smoke"] or plan["source_sha256"] != SOURCE or plan["tail_seed_prefixes"] != PREFIXES:
        raise ValueError("Frozen full supplement required")
    if draws != plan["bootstrap_draws"]:
        raise ValueError("Do not change the frozen resampling budget")
    if (root / plan["output_root"] / "COMPLETED").read_text().strip() != digest(plan):
        raise ValueError("Supplement supervisor has not signed full completion")
    groups, provenance = load_groups(root, plan)
    print("VERIFIED_INPUTS", len(provenance), flush=True)
    tails, tail_comparisons = tail_analysis(groups, draws)
    print("TAIL_ANALYSIS_COMPLETE", len(tails), len(tail_comparisons), flush=True)
    sensitivity, sensitivity_comparisons = sensitivity_analysis(groups, draws)
    return dict(status="computed", plan_sha256=digest(plan), frozen_worker_sha256=plan["worker_sha256"],
        simulator_source_sha256=SOURCE, analyzer_sha256=file_hash(Path(__file__)), bootstrap_draws=draws,
        numpy_version=np.__version__,
        total_episode_records=351800, input_jobs=provenance, tail_summaries=tails,
        tail_comparisons=tail_comparisons, settlement_summaries=settlement_analysis(groups),
        sensitivity_summaries=sensitivity, sensitivity_comparisons=sensitivity_comparisons,
        caveats=["Post-review supplement; primary 500k CPU report unchanged",
                 "Only five independent trained models per learned configuration and backend",
                 "Prefixes are nested and not independent repetitions; final analysis uses all 1000",
                 "Intervals are unadjusted exploratory estimates, not global significance or equivalence",
                 "Tail precision is not stable population CVaR or a safety guarantee",
                 "Settlement extends resources and changes a horizon normalization; not an equal-budget common cohort",
                 "Sensitivity ranges are design assumptions, not measured business calibration",
                 "CPU and CUDA cohorts are separate"], integrity_status="warn")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--plan", type=Path, default=Path("results/r1_supplement_20261029/plan.json"))
    parser.add_argument("--out", type=Path, default=Path("results/r1_supplement_analysis_20261029"))
    args = parser.parse_args()
    root = args.root.resolve()
    plan = json.loads((root / args.plan).read_text())
    out = (root / args.out).resolve()
    if not out.is_relative_to(root) or out.exists():
        raise ValueError("Use a new analysis directory inside this project; prior outputs are preserved")
    result = analyze(root, plan)
    out.mkdir(parents=True, exist_ok=False)
    (out / "report.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    fields = ["backend", "scenario", "cap", "variant", "rollouts_per_model", "independent_training_seeds",
              "tail_observations_per_model", "tail_mean", "tail_ci95"]
    with (out / "tail_estimates.csv").open("x", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows({k: r.get(k) for k in fields} for r in result["tail_summaries"])
    print("SUPPLEMENT_ANALYSIS_COMPUTED", out, flush=True)


if __name__ == "__main__":
    main()
