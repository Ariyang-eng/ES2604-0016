import numpy as np
import pytest

from paired_statistics import analyze, matrix, paired_interval, upper_tail_mean
from rules import candidates


def test_identical_paired_matrices_have_exactly_zero_delta_and_interval():
    a = np.arange(500).reshape(5, 100) / 500
    result = paired_interval(a, a, draws=200)
    assert result["delta_left_minus_right"] == 0
    assert result["ci95"] == [0, 0]
    assert not result["equivalence_claim"]


def test_paired_interval_preserves_constant_effect_and_is_seed_reproducible():
    a = np.ones((5, 100))
    result = paired_interval(a, a - 0.1, draws=200)
    assert result["delta_left_minus_right"] == pytest.approx(0.1)
    assert result["ci95"] == pytest.approx([0.1, 0.1])
    assert result == paired_interval(a, a - 0.1, draws=200)


@pytest.mark.parametrize("shape", [(3, 100), (5, 5), (500,)])
def test_rollouts_are_not_pseudoreplicated_as_independent_training_seeds(shape):
    with pytest.raises(ValueError):
        paired_interval(np.zeros(shape), np.zeros(shape), draws=200)


def test_nonfinite_losses_are_rejected():
    a = np.zeros((5, 100))
    a[0, 0] = np.nan
    with pytest.raises(ValueError):
        paired_interval(a, a, draws=200)


def test_episode_tail_reports_actual_tail_sample_count():
    result = upper_tail_mean(np.arange(100))
    assert result["mean"] == 97
    assert result["tail_samples"] == 5
    with pytest.raises(ValueError):
        upper_tail_mean(np.arange(20))


def test_rule_is_a_single_shared_vector_not_five_independent_trainings():
    rows = {(None, seed): {"leakage_rate": (seed - 200) / 100,
                           "leakage_rate_defined": True} for seed in range(200, 300)}
    a = matrix(rows, "leakage_rate", rule=True)
    assert a.shape == (5, 100)
    np.testing.assert_array_equal(a[0], a[4])
    with pytest.raises(ValueError):
        matrix(rows, "leakage_rate")


def test_undefined_fraud_cohort_is_not_imputed_as_a_true_zero():
    rows = {(s, seed): {"leakage_rate": 0, "leakage_rate_defined": seed != 200}
            for s in range(5) for seed in range(200, 300)}
    with pytest.raises(ValueError):
        matrix(rows, "leakage_rate")


def test_rule_grid_covers_action_bounds_without_duplicates():
    grid = list(candidates())
    assert len(grid) == 108
    assert len({tuple(sorted(c.items())) for c in grid}) == 108
    assert {c["random_audit_ratio"] for c in grid} == {0.05, 0.15, 0.30, 0.50}


def test_empty_results_produce_pending_items_not_fabricated_effects(tmp_path):
    result = analyze(tmp_path)
    assert result["status"] == "partial"
    assert result["comparisons"] == []
    assert result["summaries"] == []
    assert len(result["pending"]) == 720
