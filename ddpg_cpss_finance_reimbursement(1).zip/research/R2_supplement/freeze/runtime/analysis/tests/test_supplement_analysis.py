"""Focused statistical and missingness checks without any training dependency."""

import numpy as np
import pytest
import json

from analyze_supplement_20261029 import SOURCE, bootstrap, digest, interval, metric, upper_tail, validate_input


def test_tail_is_per_model_not_a_concatenated_mixture():
    a = np.vstack([np.zeros(100), np.ones(100)])
    assert upper_tail(a).mean() == .5
    assert np.sort(a.ravel())[-10:].mean() == 1


@pytest.mark.parametrize("tail", [False, True])
def test_shifted_pair_uses_shared_crossed_resampling(tail):
    a = np.arange(500).reshape(5, 100) / 1000
    delta = bootstrap(a + .05, draws=150, tail=tail) - bootstrap(a, draws=150, tail=tail)
    assert np.allclose(delta, .05)


def test_rule_has_no_artificial_training_seed_variability():
    a = np.full((1, 100), .2)
    assert np.allclose(interval(bootstrap(a, draws=150, tail=True)), [.2, .2])


def test_undefined_interface_zero_is_not_observed_zero_loss():
    assert np.isnan(metric(dict(leakage_rate=0, leakage_rate_defined=False, resolved_fraud_amount=0), "leakage_rate"))
    assert metric(dict(leakage_rate=0, leakage_rate_defined=True, resolved_fraud_amount=1), "leakage_rate") == 0


def test_incomplete_training_or_nonfinite_matrix_rejected():
    with pytest.raises(ValueError):
        bootstrap(np.zeros((4, 100)), draws=100)
    with pytest.raises(ValueError):
        bootstrap(np.full((5, 100), np.nan), draws=100)


def test_upper_five_percent_uses_fifty_at_one_thousand():
    a = np.arange(1000, dtype=float)[None, :]
    assert upper_tail(a)[0] == np.mean(np.arange(950, 1000))


@pytest.mark.parametrize("name", ["submitted_leakage_lower_bound", "submitted_leakage_upper_bound", "fraud_value_resolution_fraction"])
def test_shared_submitted_fraud_flag_excludes_interface_zeros(name):
    assert np.isnan(metric({name: 0, "total_fraud_amount": 0, "submitted_fraud_cohort_defined": False}, name))
    with pytest.raises(ValueError):
        metric({name: 0, "total_fraud_amount": 0, "submitted_fraud_cohort_defined": True}, name)
    with pytest.raises(ValueError):
        metric({name: 0, "total_fraud_amount": 1}, name)


@pytest.mark.parametrize("wrong", ["results/formal/SAC-Full_seed0/final_model.zip",
    "results/formal/SAC-NoRisk_seed1/final_model.zip",
    "results/backend_cuda_verification/SAC-Full_seed1/final_model.zip"])
def test_frozen_but_wrong_model_identity_is_rejected(tmp_path, wrong):
    job = dict(out="results/cohort/job", phase="tail", backend="cpu", variant="SAC-Full", train_seed=1, episodes=1)
    plan = dict(output_root="results/cohort", protocol="test", worker_sha256="worker", frozen_artifacts={wrong: "hash"})
    out = tmp_path / job["out"]
    out.mkdir(parents=True)
    (out / "COMPLETED").write_text(digest(job))
    metadata = dict(job=job, status="completed", episodes=1, job_sha256=digest(job), protocol="test",
        worker_sha256="worker", simulator_source_sha256=SOURCE, smoke=False, no_retraining=True,
        evaluation_only=True, in_primary_500k_report=False, requested_device="cpu", observed_policy_devices=["cpu"],
        model_path=wrong, model_sha256="hash")
    (out / "metadata.json").write_text(json.dumps(metadata))
    with pytest.raises(ValueError, match="Model path does not match"):
        validate_input(tmp_path, job, plan)
