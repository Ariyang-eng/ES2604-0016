"""Tune rules on validation seeds and evaluate held-out audit-budget curves."""

import argparse
from dataclasses import asdict
import hashlib
import itertools
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "scripts/r1"))

from reimbursesim.config import load_scenario
from reimbursesim.policies import B1_KNOBS, RandomPolicy, RiskThresholdPolicy, encode_knobs
from train import SCENARIOS, append_json, make_env, source_manifest


CAPS = [None, 5, 10, 20, 40]


def candidates():
    for audit, targeted, risk, auto in itertools.product(
            [0.05, 0.15, 0.30, 0.50], [0.0, 0.5, 1.0], [0.3, 0.6, 0.9], [0.0, 0.3, 0.8]):
        yield {**B1_KNOBS, "random_audit_ratio": audit, "targeted_audit_weight": targeted,
               "risk_threshold": risk, "auto_approval_prob": auto}


def episode(family, knobs, scenario, seed, cap, configs):
    env = make_env("SAC-Full", scenario, cap, configs=configs)
    obs, _ = env.reset(seed=seed)
    if family == "risk_threshold":
        policy = RiskThresholdPolicy(base=dict(knobs))
    elif family == "random":
        policy = RandomPolicy()
        policy.reset(seed=seed + 10_000)
    else:
        policy = None
    while True:
        action = policy.act(obs) if policy else encode_knobs(knobs)
        obs, _, done, truncated, info = env.step(action)
        if done or truncated:
            result = {"variant": family, "train_seed": None, "scenario": scenario,
                      "evaluation_seed": seed, "audit_cap_per_day": cap,
                      "summary": info["episode_summary"]}
            env.close()
            return result


def run(args):
    source = source_manifest()
    configs = {s: load_scenario(ROOT / "configs" / f"{s}.yaml") for s in SCENARIOS}
    validation_seeds = list(range(100, 102 if args.smoke else 105))
    evaluation_seeds = list(range(200, 202 if args.smoke else 300))
    mode = "rule_smoke" if args.smoke else "rules"
    out_root = ROOT / "results" / mode / args.family
    grid = list(candidates())[:2] if args.smoke else list(candidates())
    for cap in CAPS:
        out = out_root / ("unlimited" if cap is None else f"cap_{cap}")
        if (out / "COMPLETED").exists():
            metadata = json.loads((out / "metadata.json").read_text())
            if metadata["training_source_sha256"] != source["sha256"]:
                raise RuntimeError("Old rule result has a different simulator source")
            continue
        out.mkdir(parents=True, exist_ok=False)
        metadata = {"revision": "R1", "mode": mode, "family": args.family,
                    "audit_cap_per_day": cap, "training_source_sha256": source["sha256"],
                    "analysis_script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                    "validation_seeds": validation_seeds, "evaluation_seeds": evaluation_seeds,
                    "tuning_objective": "maximum validation mean total_reward with standard rolling-max reward",
                    "grid_size": 0 if args.family == "random" else len(grid),
                    "configs": {s: asdict(c) for s, c in configs.items()}}
        (out / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
        selected, best = dict(B1_KNOBS), -np.inf
        if args.family != "random":
            for candidate_id, knobs in enumerate(grid):
                rows = [episode(args.family, knobs, "default_quarter", s, cap, configs)
                        for s in validation_seeds]
                score = float(np.mean([r["summary"]["total_reward"] for r in rows]))
                append_json(out / "tuning.jsonl", {"candidate_id": candidate_id,
                    "knobs": knobs, "validation_score": score, "episodes": rows})
                if score > best:
                    selected, best = dict(knobs), score
                if candidate_id % 12 == 0:
                    print(json.dumps({"family": args.family, "cap": cap,
                                      "candidate": candidate_id, "of": len(grid)}), flush=True)
        (out / "selected.json").write_text(json.dumps({"knobs": selected,
            "validation_score": None if args.family == "random" else best}, indent=2) + "\n")
        for scenario in SCENARIOS:
            for seed in evaluation_seeds:
                append_json(out / "evaluation.jsonl",
                            episode(args.family, selected, scenario, seed, cap, configs))
        if source_manifest() != source:
            raise RuntimeError("Simulator source drifted; do not pool results")
        (out / "COMPLETED").write_text(source["sha256"] + "\n")
        print(json.dumps({"event": "completed", "family": args.family, "cap": cap}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--family", choices=["fixed_rule", "risk_threshold", "random"], required=True)
    parser.add_argument("--smoke", action="store_true")
    run(parser.parse_args())
