"""Paired training-seed and shared-rollout intervals without equivalence claims."""

import argparse
from collections import defaultdict
import json
from pathlib import Path

import numpy as np


def paired_interval(left, right, *, draws=5000, seed=7301):
    a, b = np.asarray(left, dtype=float), np.asarray(right, dtype=float)
    if a.shape != b.shape or a.ndim != 2 or a.shape[0] < 5 or a.shape[1] < 100:
        raise ValueError("Paired matrices require >=5 independent training seeds and >=100 matched rollouts")
    if not np.all(np.isfinite(a)) or not np.all(np.isfinite(b)):
        raise ValueError("Undefined or nonfinite outcomes must not be silently treated as zeros")
    if draws < 100:
        raise ValueError("At least 100 bootstrap draws are required")
    rng = np.random.default_rng(seed)
    delta = a - b
    estimates = []
    for _ in range(draws):
        train = rng.integers(0, a.shape[0], a.shape[0])
        rollout = rng.integers(0, a.shape[1], a.shape[1])
        estimates.append(float(delta[np.ix_(train, rollout)].mean()))
    return {"delta_left_minus_right": float(delta.mean()),
            "seed_mean_differences": delta.mean(axis=1).tolist(),
            "ci95": np.quantile(estimates, [0.025, 0.975]).tolist(),
            "method": "paired crossed bootstrap of training seeds and shared rollout seeds",
            "bootstrap_draws": draws, "training_seeds": a.shape[0], "rollouts_per_seed": a.shape[1],
            "equivalence_claim": False, "limitation": "Only five independent training seeds; intervals remain exploratory"}


def upper_tail_mean(values, fraction=0.05):
    a = np.asarray(values, dtype=float)
    if len(a) < 100 or not np.all(np.isfinite(a)) or not 0 < fraction <= 1:
        raise ValueError("A finite distribution of at least 100 episode losses is required")
    k = int(np.ceil(fraction * len(a)))
    return {"mean": float(np.sort(a)[-k:].mean()), "n": len(a), "tail_samples": k,
            "description": "upper-tail episode-loss summary, not evidence of a stable population tail expectation"}


def load_records(root):
    groups = defaultdict(dict)
    inputs = []
    sources = set()
    patterns = ["formal/*/evaluation.jsonl", "resource_matched/*/evaluation.jsonl",
                "rules/*/*/evaluation.jsonl"]
    for pattern in patterns:
        for path in sorted(root.glob(pattern)):
            if not (path.parent / "COMPLETED").exists():
                continue
            sources.add((path.parent / "COMPLETED").read_text().strip())
            inputs.append(str(path))
            with path.open() as f:
                for line in f:
                    r = json.loads(line)
                    if r["summary"].get("metric_version") != "R1-resolved-cohort-v1":
                        raise ValueError("Cannot pool V1 metrics or unknown metric versions")
                    key = (r["scenario"], r.get("audit_cap_per_day"), r["variant"])
                    row_key = (r.get("train_seed"), r["evaluation_seed"])
                    if row_key in groups[key]:
                        raise ValueError(f"Duplicate evaluation row: {key}, {row_key}")
                    groups[key][row_key] = r["summary"]
    if len(sources) > 1:
        raise ValueError("Cannot pool experiments from different simulator source hashes")
    return groups, inputs


def matrix(rows, metric, *, rule=False):
    train = sorted({s for s, _ in rows if s is not None})
    if rule:
        if train or not rows:
            raise ValueError("Expected an untrained rule baseline")
        row_ids = [None] * 5
    elif train == list(range(5)):
        row_ids = train
    else:
        raise ValueError("Independent training seeds 0..4 are not all complete")
    seeds = sorted({e for _, e in rows})
    if len(seeds) < 100 or seeds != list(range(200, 200 + len(seeds))):
        raise ValueError("Held-out rollout seeds must be a complete contiguous set starting at 200")
    result = []
    for s in row_ids:
        line = []
        for seed in seeds:
            summary = rows[(s, seed)]
            if metric + "_defined" in summary and not summary[metric + "_defined"]:
                raise ValueError("Undefined cohort metric; report missingness instead of zero imputation")
            line.append(summary[metric])
        result.append(line)
    return np.asarray(result)


def analyze(root):
    groups, inputs = load_records(root)
    comparisons, pending, summaries = [], [], []
    pairs = [("SAC-NoSocial", "SAC-Full"), ("SAC-NoRisk", "SAC-Full"),
             ("PPO-Quantized", "PPO"), ("SAC-Full", "DQN"),
             ("SAC-Full", "fixed_rule"), ("SAC-Full", "risk_threshold"), ("SAC-Full", "random")]
    scenarios = ["default_quarter", "stress_fraud_burst", "stress_month_end",
                 "stress_reviewer_shortage", "stress_policy_shock", "stress_budget_shock",
                 "public_reference_domestic", "public_reference_international"]
    workloads = [(s, c) for s in scenarios for c in [None, 5, 10, 20, 40]]
    variants = ["DQN", "PPO", "DDPG", "TD3", "SAC-Full", "SAC-NoSocial", "SAC-NoRisk",
                "PPO-Quantized", "fixed_rule", "risk_threshold", "random"]
    for scenario, cap in workloads:
        for variant in variants:
            is_rule = variant in {"fixed_rule", "risk_threshold", "random"}
            try:
                result = {}
                for metric in ["leakage_rate", "fraud_catch_rate", "mean_cycle_time",
                               "audit_count", "false_alarm_rate", "unresolved_fraud_amount",
                               "fraud_value_resolution_fraction", "submitted_leakage_lower_bound",
                               "submitted_leakage_upper_bound"]:
                    values = matrix(groups[(scenario, cap, variant)], metric, rule=is_rule)
                    result[metric] = {"mean": float(values.mean()),
                        "training_seed_std": None if is_rule else float(values.mean(axis=1).std(ddof=1))}
                summaries.append({"scenario": scenario, "daily_cap": cap, "variant": variant,
                    "independent_training_seeds": 0 if is_rule else 5,
                    "evaluation_rollouts_per_model_or_rule": values.shape[1], "metrics": result})
            except (KeyError, ValueError) as e:
                pending.append({"scenario": scenario, "cap": cap, "variant": variant, "reason": str(e)})
    for scenario, cap in workloads:
        for left, right in pairs:
            try:
                a = matrix(groups[(scenario, cap, left)], "leakage_rate")
                is_rule = right in {"fixed_rule", "risk_threshold", "random"}
                b = matrix(groups[(scenario, cap, right)], "leakage_rate", rule=is_rule)
            except (KeyError, ValueError) as e:
                pending.append({"scenario": scenario, "cap": cap, "pair": [left, right], "reason": str(e)})
                continue
            comparisons.append({"scenario": scenario, "daily_cap": cap, "left": left,
                "right": right, **paired_interval(a, b),
                "rule_baseline_has_training_seeds": False if is_rule else None,
                "rule_pairing_note": "Rule vector reused across trained models for pairing, not five independent rule trainings" if is_rule else None,
                "left_companion_means": {m: float(matrix(groups[(scenario, cap, left)], m).mean())
                    for m in ["unresolved_fraud_amount", "fraud_value_resolution_fraction",
                              "submitted_leakage_lower_bound", "submitted_leakage_upper_bound", "audit_count"]},
                "right_companion_means": {m: float(matrix(groups[(scenario, cap, right)], m, rule=is_rule).mean())
                    for m in ["unresolved_fraud_amount", "fraud_value_resolution_fraction",
                              "submitted_leakage_lower_bound", "submitted_leakage_upper_bound", "audit_count"]},
                "left_episode_tail_by_training_seed": [upper_tail_mean(x) for x in a],
                "right_episode_tail_by_training_seed": [upper_tail_mean(x) for x in b]})
    return {"status": "partial" if pending or not comparisons else "computed",
            "inputs": inputs, "summaries": summaries, "comparisons": comparisons, "pending": pending,
            "multiple_comparison_adjustment": None,
            "intervals_are_exploratory_not_significance_or_equivalence_decisions": True,
            "not_a_submission_ready_claim": True,
            "required_companion_metrics": ["unresolved_fraud_amount", "fraud_value_resolution_fraction",
                "submitted_leakage_lower_bound", "submitted_leakage_upper_bound", "audit_count"]}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--results", type=Path, default=Path(__file__).resolve().parents[1] / "results")
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    with args.out.open("x") as f:
        json.dump(analyze(args.results), f, indent=2)
        f.write("\n")
