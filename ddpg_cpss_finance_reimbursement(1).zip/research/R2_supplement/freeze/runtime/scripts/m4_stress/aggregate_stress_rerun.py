"""Aggregate per-variant M4 stress rerun outputs."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np


METRIC_KEYS = [
    "total_reward",
    "leakage_rate",
    "fraud_catch_rate",
    "mean_cycle_time",
    "daily_worst_5pct_mean",
    "appeal_rate",
    "false_alarm_rate",
    "sla_violation_rate",
    "audit_count",
]


def aggregate_across_runs(items: list[dict]) -> dict:
    out = {}
    for key in METRIC_KEYS:
        vals = [item["metrics"][key]["mean"] for item in items]
        out[key] = {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
            "values": [float(v) for v in vals],
        }
    return out


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--dir", default="results/m4_stress_rerun")
    parser.add_argument("--out", default="results/m4_stress_rerun/stress_results.json")
    args = parser.parse_args()

    in_dir = Path(args.dir)
    per_run = []
    for path in sorted(in_dir.glob("*.json")):
        if path.name == Path(args.out).name:
            continue
        with path.open(encoding="utf-8") as f:
            data = json.load(f)
        if "stress_results" in data:
            per_run.append(data)

    by_stress: dict[str, dict[str, list[dict]]] = {}
    for run in per_run:
        variant = run["variant"]
        for stress_name, stress_data in run["stress_results"].items():
            by_stress.setdefault(stress_name, {}).setdefault(variant, []).append(stress_data)

    summary = {}
    for stress_name, variants in by_stress.items():
        summary[stress_name] = {}
        for variant, items in variants.items():
            summary[stress_name][variant] = aggregate_across_runs(items)

    out = {
        "description": "M4 stress robustness rerun with independently trained variants",
        "n_runs": len(per_run),
        "variants": sorted({run["variant"] for run in per_run}),
        "seeds": sorted({run["seed"] for run in per_run}),
        "results": summary,
        "per_run_files": [f"{run['variant'].replace('-', '_')}_seed{run['seed']}.json" for run in per_run],
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    lines = ["# M4 Stress Rerun Results", "", "| Stress | Policy | Leakage | Catch | CVaR | Cycle | SLA |", "|---|---|---:|---:|---:|---:|---:|"]
    for stress_name, variants in summary.items():
        for variant, metrics in variants.items():
            lines.append(
                f"| {stress_name} | {variant} | "
                f"{metrics['leakage_rate']['mean']:.3f}±{metrics['leakage_rate']['std']:.3f} | "
                f"{metrics['fraud_catch_rate']['mean']:.3f}±{metrics['fraud_catch_rate']['std']:.3f} | "
                f"{metrics['daily_worst_5pct_mean']['mean']:.3f}±{metrics['daily_worst_5pct_mean']['std']:.3f} | "
                f"{metrics['mean_cycle_time']['mean']:.2f}±{metrics['mean_cycle_time']['std']:.2f} | "
                f"{metrics['sla_violation_rate']['mean']:.3f}±{metrics['sla_violation_rate']['std']:.3f} |"
            )

    md_path = out_path.with_name("summary.md")
    md_path.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print(f"\nWrote {out_path} and {md_path}")


if __name__ == "__main__":
    main()
