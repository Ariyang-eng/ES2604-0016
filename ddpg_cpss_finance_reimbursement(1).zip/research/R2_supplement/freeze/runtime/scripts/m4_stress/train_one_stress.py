"""Train one policy variant and evaluate it on all stress scenarios.

This script is intentionally per-variant/per-seed so remote runs can launch
independent jobs and avoid mixing model semantics. In particular, SAC-NoRisk
is trained in a NoRiskRewardWrapper environment instead of reusing SAC-Full.
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

from stable_baselines3 import DQN, SAC

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.wrappers import (
    DiscretizedActionWrapper,
    NoRiskRewardWrapper,
    NoSocialObservationWrapper,
)


STRESS_CONFIGS = {
    "fraud_burst": "configs/stress_fraud_burst.yaml",
    "month_end": "configs/stress_month_end.yaml",
    "reviewer_shortage": "configs/stress_reviewer_shortage.yaml",
    "policy_shock": "configs/stress_policy_shock.yaml",
    "budget_shock": "configs/stress_budget_shock.yaml",
}

METRIC_KEYS = [
    "total_reward",
    "leakage_rate",
    "fraud_catch_rate",
    "mean_cycle_time",
    "daily_worst_5pct_mean",
    "appeal_rate",
    "false_alarm_rate",
    "sla_violation_rate",
    "audit_count",
]


def make_env(config_path: str, seed: int, variant: str):
    env = ReimburseSimEnv(load_scenario(config_path))
    if variant == "DQN":
        env = DiscretizedActionWrapper(env, bins=3)
    elif variant == "SAC-NoRisk":
        env = NoRiskRewardWrapper(env)
    elif variant == "SAC-NoSocial":
        env = NoSocialObservationWrapper(env)
    env.reset(seed=seed)
    return env


def train_model(variant: str, config_path: str, seed: int, timesteps: int, quiet: bool):
    env = make_env(config_path, seed, variant)
    if variant == "DQN":
        model = DQN(
            "MlpPolicy",
            env,
            learning_rate=5e-4,
            buffer_size=20000,
            learning_starts=1000,
            batch_size=64,
            gamma=0.99,
            target_update_interval=500,
            train_freq=4,
            exploration_fraction=0.3,
            exploration_final_eps=0.05,
            verbose=0 if quiet else 1,
            seed=seed,
            device="auto",
        )
    else:
        model = SAC(
            "MlpPolicy",
            env,
            learning_rate=3e-4,
            buffer_size=100000,
            learning_starts=1000,
            batch_size=256,
            gamma=0.99,
            tau=0.005,
            ent_coef="auto",
            verbose=0 if quiet else 1,
            seed=seed,
            device="auto",
        )
    model.learn(total_timesteps=timesteps, progress_bar=False)
    return model


def evaluate(model, variant: str, config_path: str, eval_seeds: list[int]) -> list[dict]:
    episodes = []
    for seed in eval_seeds:
        env = make_env(config_path, seed, variant)
        obs, _ = env.reset(seed=seed)
        rewards = []
        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        summary = info.get("episode_summary", {})
        summary["total_reward"] = float(sum(rewards))
        summary["seed"] = seed
        episodes.append(summary)
    return episodes


def aggregate(episodes: list[dict]) -> dict:
    out = {}
    for key in METRIC_KEYS:
        vals = [e["total_reward"] if key == "total_reward" else e.get(key, 0.0) for e in episodes]
        out[key] = {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
            "values": [float(v) for v in vals],
        }
    return out


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", required=True, choices=["SAC-Full", "SAC-NoRisk", "SAC-NoSocial", "DQN"])
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--train-config", default="configs/default_quarter.yaml")
    parser.add_argument("--timesteps", type=int, default=50000)
    parser.add_argument("--eval-seeds", type=int, nargs="+", default=[100, 101, 102, 103, 104])
    parser.add_argument("--out-dir", default="results/m4_stress_rerun")
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    start = time.time()
    model = train_model(args.variant, args.train_config, args.seed, args.timesteps, args.quiet)
    train_seconds = time.time() - start

    stress_results = {}
    for stress_name, rel_config in STRESS_CONFIGS.items():
        config_path = str(PROJECT / rel_config)
        episodes = evaluate(model, args.variant, config_path, args.eval_seeds)
        stress_results[stress_name] = {
            "metrics": aggregate(episodes),
            "episodes": episodes,
        }

    result = {
        "variant": args.variant,
        "seed": args.seed,
        "train_config": args.train_config,
        "timesteps": args.timesteps,
        "eval_seeds": args.eval_seeds,
        "train_wall_seconds": round(train_seconds, 1),
        "total_wall_seconds": round(time.time() - start, 1),
        "stress_results": stress_results,
    }

    out_path = out_dir / f"{args.variant.replace('-', '_')}_seed{args.seed}.json"
    out_path.write_text(json.dumps(result, indent=2), encoding="utf-8")

    print(f"[{args.variant} seed={args.seed}] train={train_seconds:.1f}s")
    for stress_name, data in stress_results.items():
        m = data["metrics"]
        print(
            f"  {stress_name}: leak={m['leakage_rate']['mean']:.4f} "
            f"catch={m['fraud_catch_rate']['mean']:.4f} "
            f"cvar={m['daily_worst_5pct_mean']['mean']:.4f} "
            f"sla={m['sla_violation_rate']['mean']:.4f}"
        )


if __name__ == "__main__":
    main()
