"""Summarize public reimbursement logs without inventing currency or fraud labels."""

from collections import Counter
from datetime import datetime, timedelta
import gzip
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np


ROOT = Path(__file__).resolve().parents[2]
SOURCE = "https://icpmconference.org/2020/bpi-challenge/"


def quantiles(values):
    a = np.asarray(values, dtype=float)
    if not len(a):
        return {"n": 0}
    return {"n": len(a), "mean": float(a.mean()), "std": float(a.std()),
            **{f"p{q:02d}": float(np.percentile(a, q)) for q in [5, 25, 50, 75, 95]},
            "max": float(a.max())}


def summarize(path):
    amounts, cycles, starts = [], [], []
    amount_nonpositive, amount_missing, cases, events_count, paid_cases = 0, 0, 0, 0, 0
    case_records = []
    with gzip.open(path, "rb") as f:
        for _, node in ET.iterparse(f, events=["end"]):
            if node.tag.rsplit("}", 1)[-1] != "trace":
                continue
            cases += 1
            attrs = {c.get("key"): c.get("value") for c in node
                     if c.tag.rsplit("}", 1)[-1] != "event"}
            events = [{c.get("key"): c.get("value") for c in item} for item in node
                      if item.tag.rsplit("}", 1)[-1] == "event"]
            events_count += len(events)
            value = attrs.get("Amount")
            amount = float(value) if value is not None else None
            if amount is None or not np.isfinite(amount):
                amount_missing += 1
            elif amount <= 0:
                amount_nonpositive += 1
            else:
                amounts.append(amount)
            submitted = [datetime.fromisoformat(e["time:timestamp"]) for e in events
                         if e.get("concept:name") == "Declaration SUBMITTED by EMPLOYEE"
                         and "time:timestamp" in e]
            first = min(submitted) if submitted else None
            payments = [datetime.fromisoformat(e["time:timestamp"]) for e in events
                        if e.get("concept:name") == "Payment Handled"
                        and "time:timestamp" in e]
            after_start = [p for p in payments if first and p >= first]
            elapsed = None
            if first:
                starts.append(first.date())
                if after_start:
                    elapsed = (min(after_start) - first).total_seconds() / 86400
                    cycles.append(elapsed)
                    paid_cases += 1
            case_records.append({"case": attrs.get("concept:name"), "amount": amount,
                                 "first_submission": first.isoformat() if first else None,
                                 "calendar_days_to_first_payment": elapsed})
            node.clear()
    counts = Counter(starts)
    days = []
    if starts:
        day = min(starts)
        while day <= max(starts):
            days.append((day, counts[day]))
            day += timedelta(days=1)
    logs = np.log(amounts)
    return {"source_url": SOURCE, "download_filename": path.name,
            "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "cases": cases, "events": events_count,
            "amount_units": "Not established from XES; no conversion to CNY assumed",
            "positive_case_amounts": quantiles(amounts),
            "amount_missing_or_nonfinite": amount_missing,
            "amount_nonpositive": amount_nonpositive,
            "positive_amount_lognormal_mle": {"mu": float(logs.mean()), "sigma": float(logs.std())},
            "payment_delay_calendar_days": quantiles(cycles),
            "paid_cases_with_observed_submission": paid_cases,
            "cases_without_observed_submission": cases - len(starts),
            "cases_without_observed_payment_after_submission": len(starts) - paid_cases,
            "submission_range": [str(min(starts)), str(max(starts))] if starts else [],
            "daily_submissions_all_calendar_days": quantiles([n for _, n in days]),
            "daily_submissions_weekdays_only": quantiles([n for d, n in days if d.weekday() < 5]),
            "fraud_ground_truth": "Unavailable; rejection is not a fraud label",
            "amount_anonymization": "Provider states amounts are perturbed; only aggregate checks justified",
            "case_records": case_records}


if __name__ == "__main__":
    out = ROOT / "results/public_calibration"
    out.mkdir(parents=True, exist_ok=True)
    result = {p.name: summarize(p) for p in sorted((ROOT / "data/public/bpi2020").glob("*.gz"))}
    (out / "bpi2020_statistics.json").write_text(json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    for name, stats in result.items():
        print(json.dumps({k: v for k, v in stats.items() if k != "case_records"}, indent=2))
