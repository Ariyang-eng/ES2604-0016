"""CPU-only low-priority scheduler that yields its own jobs under host pressure."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

# Set these before importing the training module (which imports NumPy).
for variable in ["OMP_NUM_THREADS", "MKL_NUM_THREADS", "OPENBLAS_NUM_THREADS", "NUMEXPR_NUM_THREADS"]:
    os.environ[variable] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = ""

import psutil

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Path(__file__).resolve().parent))
from train import VARIANTS, source_manifest


def main(args):
    if os.name != "posix":
        raise RuntimeError("Resource-aware scheduling is intended for the Linux server")
    os.nice(15)
    def shutdown(signum, frame):
        raise KeyboardInterrupt(f"Scheduler received signal {signum}")

    signal.signal(signal.SIGTERM, shutdown)
    signal.signal(signal.SIGHUP, shutdown)
    allowed = sorted(os.sched_getaffinity(0))
    usage = psutil.cpu_percent(interval=1, percpu=True)
    selected = sorted(allowed, key=lambda cpu: usage[cpu])[:args.workers]
    os.sched_setaffinity(0, selected)
    num_cpus = psutil.cpu_count() or 1
    source_hash = source_manifest()["sha256"]
    if args.phase == "formal":
        for variant in VARIANTS:
            smoke = ROOT / "results/smoke" / f"{variant}_seed0"
            if not (smoke / "COMPLETED").exists():
                raise RuntimeError(f"Missing smoke gate: {variant}")
            if (smoke / "COMPLETED").read_text().strip() != source_hash:
                raise RuntimeError("Smoke gate source hash does not match current code")
    jobs = [(v, seed) for seed in ([0] if args.phase == "smoke" else range(5)) for v in VARIANTS]
    output = ROOT / "results" / args.phase
    output.mkdir(parents=True, exist_ok=True)
    log_dir = output / "logs"
    log_dir.mkdir(exist_ok=True)
    state_file = output / "scheduler.json"
    if state_file.exists() and psutil.pid_exists(json.loads(state_file.read_text()).get("pid", -1)):
        raise RuntimeError("A scheduler for this phase appears to be active")
    running, complete, failed = {}, [], []
    env = dict(os.environ, CUDA_VISIBLE_DEVICES="", OMP_NUM_THREADS="1",
               MKL_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", NUMEXPR_NUM_THREADS="1",
               MPLCONFIGDIR=str(ROOT / ".cache/matplotlib"),
               XDG_CACHE_HOME=str(ROOT / ".cache"), PYTEST_DISABLE_PLUGIN_AUTOLOAD="1")
    for rel in [".cache/matplotlib", ".tmp"]:
        (ROOT / rel).mkdir(parents=True, exist_ok=True)
    env["TMPDIR"] = str(ROOT / ".tmp")
    try:
        while jobs or running:
            load = os.getloadavg()[0]
            available_gb = psutil.virtual_memory().available / 2**30
            pressure = load > 0.8 * num_cpus or available_gb < 32
            resume_safe = load < 0.65 * num_cpus and available_gb >= 48
            for pid, item in list(running.items()):
                process = item["process"]
                rc = process.poll()
                if rc is not None:
                    item["log"].close()
                    marker = output / f"{item['variant']}_seed{item['seed']}" / "COMPLETED"
                    (complete if rc == 0 and marker.exists() else failed).append(
                        {"variant": item["variant"], "seed": item["seed"], "returncode": rc})
                    del running[pid]
                    continue
                if pressure and not item["paused"]:
                    os.killpg(pid, signal.SIGSTOP)
                    item["paused"] = True
                elif resume_safe and item["paused"]:
                    os.killpg(pid, signal.SIGCONT)
                    item["paused"] = False
            if failed:
                jobs.clear()
            while jobs and len(running) < args.workers and resume_safe:
                variant, seed = jobs.pop(0)
                dest = output / f"{variant}_seed{seed}"
                if (dest / "COMPLETED").exists():
                    if (dest / "COMPLETED").read_text().strip() != source_hash:
                        raise RuntimeError("Completed job has a different source hash")
                    complete.append({"variant": variant, "seed": seed, "already_complete": True})
                    continue
                if dest.exists():
                    raise RuntimeError(f"Partial output requires inspection, not overwrite: {dest}")
                command = [sys.executable, "-u", str(Path(__file__).with_name("train.py")),
                           "--variant", variant, "--seed", str(seed)]
                if args.phase == "smoke":
                    command += ["--smoke", "--timesteps", "2048", "--eval-episodes", "2",
                                "--curve-interval", "1024"]
                if shutil.which("ionice"):
                    command = ["ionice", "-c", "2", "-n", "7", *command]
                log = (log_dir / f"{variant}_seed{seed}.log").open("w")
                command = [sys.executable, str(Path(__file__).with_name("owned_job.py")),
                           "--parent", str(os.getpid()), "--", *command]
                p = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log,
                                     stderr=subprocess.STDOUT, start_new_session=True)
                running[p.pid] = {"process": p, "log": log, "variant": variant,
                                  "seed": seed, "paused": False}
            state = {"pid": os.getpid(), "phase": args.phase, "gpu_disabled": True,
                     "nice": os.getpriority(os.PRIO_PROCESS, 0), "cpu_affinity": selected,
                     "workers_max": args.workers, "host_load_1m": load,
                     "host_available_memory_gb": available_gb, "pending": len(jobs),
                     "running": [{"pid": pid, "variant": i["variant"], "seed": i["seed"],
                                  "paused": i["paused"]} for pid, i in running.items()],
                     "completed": complete, "failed": failed, "updated_at_unix": time.time()}
            temp = state_file.with_suffix(".tmp")
            temp.write_text(json.dumps(state, indent=2) + "\n")
            temp.replace(state_file)
            if jobs or running:
                time.sleep(10)
    finally:
        for pid, item in running.items():
            if item["paused"]:
                os.killpg(pid, signal.SIGCONT)
            os.killpg(pid, signal.SIGTERM)
            item["process"].wait()
            item["log"].close()
    if failed:
        raise SystemExit("At least one job failed; remaining jobs were not dispatched")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--phase", choices=["smoke", "formal"], required=True)
    parser.add_argument("--workers", type=int, default=2)
    args = parser.parse_args()
    if not 1 <= args.workers <= 4:
        parser.error("Initial shared-server policy limits workers to 1..4")
    main(args)
