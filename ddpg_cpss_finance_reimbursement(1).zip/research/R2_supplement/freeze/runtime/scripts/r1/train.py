"""Independent R1 training with held-out curves, checkpoints and rollout records."""

from __future__ import annotations

import argparse
from copy import deepcopy
from dataclasses import asdict
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from reimbursesim.config import load_scenario
from reimbursesim.env import ReimburseSimEnv
from reimbursesim.wrappers import (
    DiscretizedActionWrapper, NoRiskRewardWrapper,
    NoSocialObservationWrapper, QuantizedBoxActionWrapper,
)


VARIANTS = ["DQN", "PPO", "DDPG", "TD3", "SAC-Full", "SAC-NoSocial",
            "SAC-NoRisk", "PPO-Quantized"]
SCENARIOS = ["default_quarter", "stress_fraud_burst", "stress_month_end",
             "stress_reviewer_shortage", "stress_policy_shock", "stress_budget_shock",
             "public_reference_domestic", "public_reference_international"]


def source_manifest() -> dict:
    records = {}
    for folder in ["src", "configs", "scripts", "tests"]:
        for p in sorted((ROOT / folder).rglob("*")):
            if p.is_file() and p.suffix in {".py", ".yaml"} and "__pycache__" not in p.parts:
                records[p.relative_to(ROOT).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()
    root_hash = hashlib.sha256(json.dumps(records, sort_keys=True).encode()).hexdigest()
    return {"sha256": root_hash, "files": records}


def make_env(variant: str, scenario: str, cap: int | None = None, *, configs=None):
    config = deepcopy(configs[scenario]) if configs is not None else load_scenario(
        ROOT / "configs" / f"{scenario}.yaml")
    config.audit_cap_per_day = cap
    env = ReimburseSimEnv(config)
    if variant == "DQN":
        return DiscretizedActionWrapper(env, bins=2)
    if variant == "PPO-Quantized":
        return QuantizedBoxActionWrapper(env, bins=2)
    if variant == "SAC-NoSocial":
        return NoSocialObservationWrapper(env)
    if variant == "SAC-NoRisk":
        return NoRiskRewardWrapper(env)
    return env


def rollout(model, variant: str, scenario: str, seed: int, *, cap: int | None = None,
            trajectory: bool = False, configs=None) -> dict:
    env = make_env(variant, scenario, cap, configs=configs)
    obs, _ = env.reset(seed=seed)
    steps = []
    while True:
        action, _ = model.predict(obs, deterministic=True)
        obs, reward, done, truncated, info = env.step(action)
        if trajectory:
            steps.append({"day": info["day"], "requested_action": action.tolist(),
                          "reward": reward, "metrics": info["metrics"],
                          "stress_state": info["stress_state"]})
        if done or truncated:
            result = {"scenario": scenario, "evaluation_seed": seed,
                      "audit_cap_per_day": cap, "summary": info["episode_summary"]}
            if trajectory:
                result["trajectory"] = steps
            env.close()
            return result


def append_json(path: Path, record: dict) -> None:
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, allow_nan=False) + "\n")


def run(args) -> None:
    import torch
    from stable_baselines3 import DDPG, DQN, PPO, SAC, TD3
    from stable_baselines3.common.callbacks import BaseCallback

    if not args.smoke and (args.timesteps < 500_000 or args.eval_episodes < 100):
        raise ValueError("Formal R1 runs require >=500000 steps and >=100 held-out episodes")
    torch.set_num_threads(1)
    torch.set_num_interop_threads(1)
    source = source_manifest()
    configs = {s: load_scenario(ROOT / "configs" / f"{s}.yaml") for s in SCENARIOS}
    mode = "smoke" if args.smoke else "formal"
    out = ROOT / "results" / mode / f"{args.variant}_seed{args.seed}"
    out.mkdir(parents=True, exist_ok=False)
    start = time.time()
    packages = {d.metadata["Name"]: d.version for d in importlib.metadata.distributions()}
    metadata = {"revision": "R1", "mode": mode, "variant": args.variant,
        "train_seed": args.seed, "timesteps_requested": args.timesteps,
        "curve_seeds": list(range(100, 105)),
        "final_evaluation_seeds": list(range(200, 200 + args.eval_episodes)),
        "metric_version": "R1-resolved-cohort-v1", "source": source,
        "packages": packages, "device": "cpu", "torch_threads": 1,
        "train_config": asdict(configs["default_quarter"]),
        "evaluation_configs": {s: asdict(c) for s, c in configs.items()}}
    (out / "run.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")

    class Curves(BaseCallback):
        def _on_step(self):
            for info in self.locals.get("infos", []):
                if "episode_summary" in info:
                    append_json(out / "training_episodes.jsonl",
                        {"steps": self.num_timesteps, "summary": info["episode_summary"]})
            if self.num_timesteps % args.curve_interval == 0:
                episodes = [rollout(self.model, args.variant, "default_quarter", s, configs=configs)
                            for s in range(100, 105)]
                append_json(out / "learning_curve.jsonl",
                            {"steps": self.num_timesteps, "episodes": episodes})
                self.model.save(out / f"checkpoint_{self.num_timesteps}.zip")
                print(json.dumps({"event": "checkpoint", "variant": args.variant,
                    "seed": args.seed, "steps": self.num_timesteps,
                    "wall_seconds": round(time.time() - start, 1)}), flush=True)
            return True

    env = make_env(args.variant, "default_quarter", configs=configs)
    algorithm = {"DQN": DQN, "PPO": PPO, "PPO-Quantized": PPO,
                 "DDPG": DDPG, "TD3": TD3}.get(args.variant, SAC)
    kwargs = {"policy_kwargs": {"net_arch": [64, 64]}, "learning_rate": 3e-4,
              "seed": args.seed, "device": "cpu", "verbose": 0}
    if algorithm == PPO:
        kwargs.update(n_steps=512, batch_size=64)
    else:
        kwargs.update(buffer_size=100_000, learning_starts=1000, batch_size=128,
                      train_freq=1, gradient_steps=1)
    model = algorithm("MlpPolicy", env, **kwargs)
    model.learn(total_timesteps=args.timesteps, callback=Curves())
    model.save(out / "final_model.zip")
    metadata["actual_training_steps"] = model.num_timesteps
    metadata["learning_curves_prove_convergence"] = False
    for scenario in SCENARIOS:
        for seed in range(200, 200 + args.eval_episodes):
            record = rollout(model, args.variant, scenario, seed, trajectory=True, configs=configs)
            record.update(variant=args.variant, train_seed=args.seed)
            append_json(out / "evaluation.jsonl", record)
    if source_manifest() != source:
        raise RuntimeError("Source changed during training; do not pool this run")
    metadata["status"] = "completed"
    metadata["wall_seconds"] = time.time() - start
    (out / "run.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    (out / "COMPLETED").write_text(source["sha256"] + "\n", encoding="ascii")
    env.close()
    print(json.dumps({"event": "completed", "output": str(out),
                      "wall_seconds": metadata["wall_seconds"]}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--variant", choices=VARIANTS, required=True)
    parser.add_argument("--seed", type=int, required=True)
    parser.add_argument("--timesteps", type=int, default=500_000)
    parser.add_argument("--eval-episodes", type=int, default=100)
    parser.add_argument("--curve-interval", type=int, default=25_000)
    parser.add_argument("--smoke", action="store_true")
    arguments = parser.parse_args()
    if arguments.curve_interval < 1 or arguments.timesteps < 1 or arguments.eval_episodes < 1:
        parser.error("Step and evaluation counts must be positive")
    run(arguments)
