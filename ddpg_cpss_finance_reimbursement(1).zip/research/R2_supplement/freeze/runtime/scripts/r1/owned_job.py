"""Bind only this newly spawned worker to its scheduler's lifetime on Linux."""

import argparse
import ctypes
import os
import signal
import sys


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--parent", type=int, required=True)
    parser.add_argument("command", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    command = args.command[1:] if args.command[:1] == ["--"] else args.command
    if not sys.platform.startswith("linux") or not command:
        raise RuntimeError("A Linux parent-death guard and command are required")
    libc = ctypes.CDLL(None, use_errno=True)
    # SIGKILL also terminates a stopped worker if its scheduler is killed/OOMed.
    if libc.prctl(1, signal.SIGKILL, 0, 0, 0) != 0:
        raise OSError(ctypes.get_errno(), "Unable to set parent-death signal")
    if os.getppid() != args.parent:
        raise RuntimeError("Scheduler exited before worker initialization")
    os.execvpe(command[0], command, os.environ)


if __name__ == "__main__":
    main()
