"""Generate paper figures from released experiment artifacts.

Usage:
    python scripts/m7_figures/make_figures.py --results-dir results --out-dir results/figures

The redesign rationale and per-figure decisions are documented in
``results/figures/FIGURE_REDESIGN_NOTES.md``. The script reads from released
JSON artifacts only and never modifies the underlying numbers.

Each figure is emitted in three formats so the LaTeX build can include the
vector ``.pdf`` while ``.png`` remains as a preview and ``.svg`` as an
editable archival format.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch

    HAS_MPL = True
except ImportError:
    HAS_MPL = False


# Okabe-Ito colourblind-safe palette with semantic groups.
RULE_GRAYS = {
    "Fixed Rule": "#525252",
    "Risk Thr.": "#969696",
    "Random": "#cccccc",
}
DISCRETE_BLUE = "#0072B2"
CONTINUOUS_PILOTS = {
    "PPO": "#E69F00",      # orange
    "DDPG": "#CC79A7",     # reddish purple
    "TD3": "#D55E00",      # vermillion
}
SAC_FAMILY = {
    "SAC-Full": "#009E73",      # bluish green
    "SAC-NoSocial": "#56B4E9",  # sky blue
    "SAC-NoRisk": "#F0E442",    # gold
}
DQN_COLOR = DISCRETE_BLUE

SCENARIO_COLORS = {
    "default_quarter": "#0072B2",
    "fraud_burst": "#D55E00",
    "month_end": "#009E73",
    "policy_shock": "#CC79A7",
    "reviewer_shortage": "#E69F00",
    "budget_shock": "#56B4E9",
    "default": "#0072B2",
    "stress": "#D55E00",
}


def set_paper_style() -> None:
    """Apply a consistent publication-quality matplotlib style."""
    if not HAS_MPL:
        return
    plt.rcParams.update({
        "font.family": "DejaVu Sans",
        "font.size": 8.5,
        "axes.titlesize": 9.5,
        "axes.titleweight": "bold",
        "axes.labelsize": 9,
        "axes.linewidth": 0.8,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "xtick.labelsize": 8,
        "ytick.labelsize": 8,
        "xtick.major.width": 0.7,
        "ytick.major.width": 0.7,
        "xtick.major.size": 3,
        "ytick.major.size": 3,
        "legend.fontsize": 8,
        "legend.frameon": False,
        "lines.linewidth": 1.2,
        "lines.markersize": 5,
        "figure.dpi": 120,
        "savefig.dpi": 300,
        "savefig.bbox": "tight",
        "savefig.pad_inches": 0.04,
        "svg.fonttype": "none",
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def load_json(path: Path) -> dict:
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


def save_figure(fig, name: str, out_dir: Path) -> None:
    """Save a figure in PNG, PDF and SVG with consistent settings."""
    out_dir.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf", "svg"):
        fig.savefig(out_dir / f"{name}.{ext}")
    plt.close(fig)
    print(f"  Saved {name}.[png|pdf|svg]")


# ---------------------------------------------------------------------------
# Figure 1 — main_comparison
# ---------------------------------------------------------------------------

def _collect_main_entries(results_dir: Path):
    """Build the row list for the main comparison figure.

    Rule baselines (M1) and continuous-RL pilots (M2) are single-seed
    rollouts; SAC variants and DQN are read from the M5 ablation summary
    (three independently trained seeds, five eval rollouts each) so the
    figure agrees with Table 1 in the paper.
    """
    entries = []  # (label, group, leakage, catch, cycle, leak_std, catch_std, cycle_std)

    def push(label, group, metrics):
        entries.append((
            label,
            group,
            metrics["leakage_rate"]["mean"],
            metrics["fraud_catch_rate"]["mean"],
            metrics["mean_cycle_time"]["mean"],
            metrics["leakage_rate"].get("std", 0.0),
            metrics["fraud_catch_rate"].get("std", 0.0),
            metrics["mean_cycle_time"].get("std", 0.0),
        ))

    rule_files = [
        ("fixed_rule.json", "Fixed Rule"),
        ("risk_threshold.json", "Risk Thr."),
        ("random.json", "Random"),
    ]
    for filename, label in rule_files:
        path = results_dir / "m1" / filename
        if path.exists():
            push(label, "rule", load_json(path)["metrics"])

    # M2 continuous-RL pilots (single-seed pilots, kept for context but
    # visually marked as the pilot group). PPO is sometimes counted as
    # discrete-action in older literature but in this benchmark it is the
    # Gaussian-policy continuous variant, so it sits in the pilot group.
    pilot_files = [
        ("ppo_seed0.json", "PPO"),
        ("ddpg_seed0.json", "DDPG"),
        ("td3_seed0.json", "TD3"),
    ]
    for filename, label in pilot_files:
        path = results_dir / "m2" / filename
        if path.exists():
            push(label, "pilot", load_json(path)["metrics"])

    # M5 ablation: DQN + SAC variants with 3-seed mean/std — matches Table 1.
    m5_path = results_dir / "m5_ablation" / "ablation_results.json"
    if m5_path.exists():
        m5 = load_json(m5_path).get("summary", {})
        for label, group in (
            ("DQN", "discrete"),
            ("SAC-Full", "sac"),
            ("SAC-NoSocial", "sac"),
            ("SAC-NoRisk", "sac"),
        ):
            if label in m5:
                push(label, group, m5[label])

    return entries


def make_main_comparison(results_dir: Path, out_dir: Path) -> None:
    if not HAS_MPL:
        return

    entries = _collect_main_entries(results_dir)
    if not entries:
        print("[M7] No main comparison data found")
        return

    labels = [e[0] for e in entries]
    groups = [e[1] for e in entries]
    leak = np.array([e[2] for e in entries])
    catch = np.array([e[3] for e in entries])
    cycle = np.array([e[4] for e in entries])
    leak_err = np.array([e[5] for e in entries])
    catch_err = np.array([e[6] for e in entries])
    cycle_err = np.array([e[7] for e in entries])

    color_for_label = {
        **RULE_GRAYS,
        "DQN": DQN_COLOR,
        **CONTINUOUS_PILOTS,
        **SAC_FAMILY,
    }
    colors = [color_for_label.get(lbl, "#7f7f7f") for lbl in labels]

    fig, axes = plt.subplots(1, 3, figsize=(7.2, 3.0), constrained_layout=True)
    x = np.arange(len(labels))
    panels = [
        (axes[0], leak, leak_err, "Leakage rate", "lower is better"),
        (axes[1], catch, catch_err, "Fraud catch rate", "higher is better"),
        (axes[2], cycle, cycle_err, "Mean cycle time (d)", "lower is better"),
    ]

    # Group boundaries between rule / discrete+pilot / sac.
    def boundaries():
        prev = groups[0]
        for i, g in enumerate(groups):
            if g != prev:
                yield i - 0.5
                prev = g

    for ax, values, errs, ylabel, direction in panels:
        ax.bar(
            x, values, yerr=errs,
            color=colors,
            edgecolor="#262626",
            linewidth=0.5,
            error_kw=dict(ecolor="#262626", elinewidth=0.7, capsize=2.0),
        )
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=35, ha="right")
        ax.set_ylabel(ylabel)
        ax.set_title(direction, fontsize=8.5, fontweight="normal", color="#525252")
        ax.grid(axis="y", alpha=0.25, linewidth=0.5)
        ax.set_axisbelow(True)
        for xb in boundaries():
            ax.axvline(xb, color="#cccccc", linewidth=0.5, linestyle="--")

    # Reference line at the rule-cluster mean on the leakage panel, to
    # visually anchor the headline "rule vs RL" gap.
    rule_mask = np.array([g == "rule" for g in groups])
    if rule_mask.any():
        rule_mean = leak[rule_mask].mean()
        axes[0].axhline(rule_mean, color="#525252", linewidth=0.7, linestyle=":")
        axes[0].text(
            len(labels) - 0.5, rule_mean,
            f"rule mean {rule_mean:.2f}",
            ha="right", va="bottom", fontsize=7, color="#525252",
        )

    legend_handles = [
        Patch(facecolor="#969696", edgecolor="#262626", linewidth=0.4, label="Rule baselines (M1)"),
        Patch(facecolor=DQN_COLOR, edgecolor="#262626", linewidth=0.4, label="Discrete RL — DQN (M5, 3 seeds)"),
        Patch(facecolor="#E69F00", edgecolor="#262626", linewidth=0.4, label="Continuous RL pilots (M2, 1 seed)"),
        Patch(facecolor="#009E73", edgecolor="#262626", linewidth=0.4, label="SAC ablation family (M5, 3 seeds)"),
    ]
    fig.legend(
        handles=legend_handles,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.08),
        ncol=2,
        frameon=False,
        fontsize=7.5,
    )

    save_figure(fig, "main_comparison", out_dir)


# ---------------------------------------------------------------------------
# Figure 2 — social_negative_result
# ---------------------------------------------------------------------------

def make_social_negative_result(results_dir: Path, out_dir: Path) -> None:
    if not HAS_MPL:
        return

    runs = []  # (label, scenario, full_metrics, nosocial_metrics)

    m3 = results_dir / "m3" / "killer_seed0.json"
    if m3.exists():
        data = load_json(m3)["results"]
        runs.append((
            "Default · s0", "default",
            data["sac_full"]["metrics"], data["sac_nosocial"]["metrics"],
        ))

    for seed in range(3):
        path = results_dir / "m3_rescue" / f"killer_stress_seed{seed}.json"
        if path.exists():
            data = load_json(path)["results"]
            runs.append((
                f"Stress · s{seed}", "stress",
                data["sac_full"]["metrics"], data["sac_nosocial"]["metrics"],
            ))

    if not runs:
        print("[M7] No social comparison data found")
        return

    fig, axes = plt.subplots(
        2, 2, figsize=(7.2, 4.6),
        gridspec_kw={"height_ratios": [1.7, 1.0]},
        constrained_layout=True,
    )

    scenario_marker = {"default": "o", "stress": "s"}

    slope_panels = [
        (axes[0, 0], "leakage_rate", "Leakage rate", "lower is better"),
        (axes[0, 1], "fraud_catch_rate", "Fraud catch rate", "higher is better"),
    ]

    x_pos = np.array([0.0, 1.0])
    for ax, key, ylabel, direction in slope_panels:
        for label, scenario, full_m, nos_m in runs:
            y_full = full_m[key]["mean"]
            y_nos = nos_m[key]["mean"]
            color = SCENARIO_COLORS[scenario]
            marker = scenario_marker[scenario]
            ax.plot(x_pos, [y_full, y_nos], color=color, alpha=0.85, linewidth=1.1)
            ax.plot(
                x_pos, [y_full, y_nos],
                marker=marker, color=color,
                markerfacecolor=color, markeredgecolor="#262626",
                markeredgewidth=0.5, linestyle="None", markersize=5.5,
            )
        ax.set_xticks(x_pos)
        ax.set_xticklabels(["SAC-Full", "SAC-NoSocial"])
        ax.set_xlim(-0.18, 1.18)
        ax.set_ylabel(ylabel)
        ax.set_title(direction, fontsize=8.5, fontweight="normal", color="#525252")
        ax.grid(axis="y", alpha=0.25, linewidth=0.5)
        ax.set_axisbelow(True)

    # Bottom-row delta panels: explicit per-pair Δ = NoSocial − Full bar chart,
    # so the reader can read magnitude as well as direction.
    delta_panels = [
        (axes[1, 0], "leakage_rate", "Δ leakage = NoSocial − Full", "Δ < 0 favours NoSocial"),
        (axes[1, 1], "fraud_catch_rate", "Δ catch = NoSocial − Full", "Δ > 0 favours NoSocial"),
    ]
    pair_labels = [run[0] for run in runs]
    pair_colors = [SCENARIO_COLORS[run[1]] for run in runs]
    y_idx = np.arange(len(runs))

    for ax, key, title, hint in delta_panels:
        deltas = np.array([r[3][key]["mean"] - r[2][key]["mean"] for r in runs])
        bar_colors = [
            (c if (d < 0 and key == "leakage_rate") or (d > 0 and key == "fraud_catch_rate")
             else "#d9d9d9")
            for c, d in zip(pair_colors, deltas)
        ]
        edge_colors = pair_colors
        ax.barh(y_idx, deltas,
                 color=bar_colors, edgecolor=edge_colors, linewidth=0.8, height=0.55)
        for yi, d in zip(y_idx, deltas):
            ha = "left" if d >= 0 else "right"
            offset = 1 if d >= 0 else -1
            ax.annotate(f"{d:+.3f}", xy=(d, yi),
                         xytext=(2 * offset, 0), textcoords="offset points",
                         ha=ha, va="center", fontsize=7, color="#262626")
        ax.axvline(0, color="#525252", linewidth=0.6)
        ax.set_yticks(y_idx)
        ax.set_yticklabels(pair_labels)
        ax.invert_yaxis()
        ax.set_xlabel(title)
        ax.set_title(hint, fontsize=8, fontweight="normal", color="#525252",
                       loc="left")
        ax.grid(axis="x", alpha=0.25, linewidth=0.5)
        ax.set_axisbelow(True)
        # Pad x-limits a little so labels don't get clipped.
        xmin, xmax = ax.get_xlim()
        span = max(abs(xmin), abs(xmax))
        ax.set_xlim(-span * 1.25, span * 1.25)

    legend_handles = [
        Line2D([0], [0], marker="o", color=SCENARIO_COLORS["default"],
               markerfacecolor=SCENARIO_COLORS["default"], markeredgecolor="#262626",
               markeredgewidth=0.4, linestyle="-", linewidth=1.0,
               label="Default scenario (M3, 1 pair)"),
        Line2D([0], [0], marker="s", color=SCENARIO_COLORS["stress"],
               markerfacecolor=SCENARIO_COLORS["stress"], markeredgecolor="#262626",
               markeredgewidth=0.4, linestyle="-", linewidth=1.0,
               label="Stress scenario (M3-rescue, 3 pairs)"),
    ]
    fig.legend(
        handles=legend_handles,
        loc="lower center",
        bbox_to_anchor=(0.5, -0.07),
        ncol=2,
        frameon=False,
        fontsize=7.5,
    )

    save_figure(fig, "social_negative_result", out_dir)


# ---------------------------------------------------------------------------
# Figure 3 — stress_comparison
# ---------------------------------------------------------------------------

STRESS_ORDER = ["fraud_burst", "month_end", "policy_shock", "budget_shock", "reviewer_shortage"]
STRESS_LABELS = {
    "fraud_burst": "fraud\nburst",
    "month_end": "month\nend",
    "policy_shock": "policy\nshock",
    "budget_shock": "budget\nshock",
    "reviewer_shortage": "reviewer\nshortage",
}
POLICY_ORDER = ["DQN", "SAC-Full", "SAC-NoRisk", "SAC-NoSocial"]
POLICY_COLORS = {
    "DQN": DQN_COLOR,
    "SAC-Full": SAC_FAMILY["SAC-Full"],
    "SAC-NoRisk": SAC_FAMILY["SAC-NoRisk"],
    "SAC-NoSocial": SAC_FAMILY["SAC-NoSocial"],
}


def make_stress_comparison(results_dir: Path, out_dir: Path) -> None:
    if not HAS_MPL:
        return

    path = results_dir / "m4_stress_rerun" / "stress_results.json"
    if not path.exists():
        print("[M7] No stress results found")
        return

    stress = load_json(path).get("results", {})
    scenarios = [s for s in STRESS_ORDER if s in stress]
    if not scenarios:
        return

    fig, axes = plt.subplots(
        2, 1, figsize=(7.2, 4.8),
        gridspec_kw={"height_ratios": [1.6, 1.0]},
        constrained_layout=True,
    )

    ax_leak, ax_sla = axes

    n_pol = len(POLICY_ORDER)
    dx = 0.18  # spacing between policies within a scenario
    offsets = (np.arange(n_pol) - (n_pol - 1) / 2.0) * dx

    # Highlight the reviewer_shortage column with a light band so the reader
    # sees the hardest regime without us encoding a new "significance" claim.
    rs_idx = scenarios.index("reviewer_shortage") if "reviewer_shortage" in scenarios else None

    def shade_reviewer_shortage(ax):
        if rs_idx is None:
            return
        ax.axvspan(rs_idx - 0.45, rs_idx + 0.45, color="#fff4d6", zorder=0)

    shade_reviewer_shortage(ax_leak)
    shade_reviewer_shortage(ax_sla)

    # Panel a — leakage with seed-level error bars.
    for j, policy in enumerate(POLICY_ORDER):
        means, stds = [], []
        for s in scenarios:
            entry = stress[s].get(policy, {}).get("leakage_rate", {})
            means.append(entry.get("mean", np.nan))
            stds.append(entry.get("std", 0.0))
        xs = np.arange(len(scenarios)) + offsets[j]
        ax_leak.errorbar(
            xs, means, yerr=stds,
            fmt="o", markersize=5,
            color=POLICY_COLORS[policy],
            markeredgecolor="#262626", markeredgewidth=0.4,
            ecolor="#262626", elinewidth=0.7, capsize=2.5,
            label=policy,
        )
    ax_leak.set_xticks(np.arange(len(scenarios)))
    ax_leak.set_xticklabels([STRESS_LABELS[s] for s in scenarios])
    ax_leak.set_ylabel("Leakage rate")
    ax_leak.set_title("a · Leakage under stress (mean ± seed std, 3 seeds × 5 rollouts)",
                       loc="left", fontsize=9, fontweight="bold")
    ax_leak.grid(axis="y", alpha=0.25, linewidth=0.5)
    ax_leak.set_axisbelow(True)
    ax_leak.legend(ncol=4, loc="lower center", bbox_to_anchor=(0.5, 1.10),
                    fontsize=7.5, columnspacing=1.2, handletextpad=0.4,
                    frameon=False)
    ax_leak.set_ylim(bottom=0.0)

    # Panel b — SLA violation rate.
    for j, policy in enumerate(POLICY_ORDER):
        means, stds = [], []
        for s in scenarios:
            entry = stress[s].get(policy, {}).get("sla_violation_rate", {})
            means.append(entry.get("mean", np.nan))
            stds.append(entry.get("std", 0.0))
        xs = np.arange(len(scenarios)) + offsets[j]
        ax_sla.errorbar(
            xs, means, yerr=stds,
            fmt="o", markersize=4.5,
            color=POLICY_COLORS[policy],
            markeredgecolor="#262626", markeredgewidth=0.4,
            ecolor="#262626", elinewidth=0.7, capsize=2.5,
        )
    ax_sla.set_xticks(np.arange(len(scenarios)))
    ax_sla.set_xticklabels([STRESS_LABELS[s] for s in scenarios])
    ax_sla.set_ylabel("SLA violation rate")
    ax_sla.set_title("b · SLA violation rate — only reviewer_shortage is nontrivial",
                      loc="left", fontsize=9, fontweight="bold")
    ax_sla.grid(axis="y", alpha=0.25, linewidth=0.5)
    ax_sla.set_axisbelow(True)
    ax_sla.set_ylim(bottom=-0.02)

    if rs_idx is not None:
        ax_leak.annotate(
            "hardest regime", xy=(rs_idx, ax_leak.get_ylim()[1] * 0.82),
            ha="center", va="top", fontsize=7, color="#8a6d00",
        )

    save_figure(fig, "stress_comparison", out_dir)


# ---------------------------------------------------------------------------
# Figure 4 — validation_distributions
# ---------------------------------------------------------------------------

def make_validation_plots(results_dir: Path, out_dir: Path) -> None:
    if not HAS_MPL:
        return

    path = results_dir / "validation" / "simulator_validation.json"
    if not path.exists():
        print("[M7] No validation data found")
        return

    data = load_json(path)
    scenarios = list(data.keys())  # ordered as in the JSON

    fig, axes = plt.subplots(2, 2, figsize=(7.6, 5.4), constrained_layout=True)
    y_positions = np.arange(len(scenarios))
    color_for_scenario = [SCENARIO_COLORS.get(s, "#7f7f7f") for s in scenarios]

    # Panel a — claim amount p05–p95 range with median marker (NOT a CDF).
    ax = axes[0, 0]
    for i, scenario in enumerate(scenarios):
        amount = data[scenario]["claim_amount"]
        p05, med, p95 = amount["p05"], amount["median"], amount["p95"]
        lc = ax.hlines(y=i, xmin=p05, xmax=p95,
                       color=color_for_scenario[i], linewidth=4.0, alpha=0.45)
        lc.set_capstyle("round")
        ax.plot([p05, p95], [i, i], "|",
                color=color_for_scenario[i], markersize=10, markeredgewidth=1.2)
        ax.plot([med], [i], "o",
                color=color_for_scenario[i], markeredgecolor="#262626",
                markeredgewidth=0.6, markersize=7)
        ax.annotate(f"med {med:,.0f}", xy=(med, i), xytext=(0, 9),
                     textcoords="offset points", ha="center", fontsize=6.8,
                     color="#262626")
    ax.set_yticks(y_positions)
    ax.set_yticklabels(scenarios)
    ax.set_xscale("log")
    ax.set_xlabel("Claim amount (CNY, log scale)")
    ax.set_title("a · Claim amount summary",
                  loc="left", fontsize=9, fontweight="bold")
    ax.grid(axis="x", which="both", alpha=0.25, linewidth=0.5)
    ax.set_axisbelow(True)
    ax.invert_yaxis()

    # Panel b — daily claim volume (mean + max) as grouped bars.
    ax = axes[0, 1]
    means = [data[s]["daily_volume"]["mean"] for s in scenarios]
    maxes = [data[s]["daily_volume"]["max"] for s in scenarios]
    xs = np.arange(len(scenarios))
    width = 0.36
    ax.bar(xs - width / 2, means, width, color="#6baed6", edgecolor="#262626",
            linewidth=0.5, label="mean")
    ax.bar(xs + width / 2, maxes, width, color="#08519c", edgecolor="#262626",
            linewidth=0.5, label="max")
    ax.set_xticks(xs)
    ax.set_xticklabels(scenarios, rotation=15, ha="right")
    ax.set_ylabel("Claims per day")
    ax.set_title("b · Daily volume",
                  loc="left", fontsize=9, fontweight="bold")
    ax.legend(loc="upper left", fontsize=7.5)
    ax.grid(axis="y", alpha=0.25, linewidth=0.5)
    ax.set_axisbelow(True)

    # Panel c — cycle time mean ± std with p95/max whisker.
    ax = axes[1, 0]
    for i, scenario in enumerate(scenarios):
        cycle = data[scenario]["cycle_time"]
        mean, std = cycle["mean"], cycle["std"]
        p95 = cycle["p95"]
        ax.barh(i, mean, height=0.45, xerr=std,
                color=color_for_scenario[i], edgecolor="#262626",
                linewidth=0.5, alpha=0.85,
                error_kw=dict(ecolor="#262626", elinewidth=0.7, capsize=3))
        ax.plot([p95], [i], marker="|", color="#262626", markersize=12,
                markeredgewidth=1.0)
        ax.annotate(f"p95 {p95:.1f}d", xy=(p95, i), xytext=(5, 0),
                     textcoords="offset points", ha="left", va="center",
                     fontsize=6.8, color="#262626")
    ax.set_yticks(y_positions)
    ax.set_yticklabels(scenarios)
    ax.set_xlabel("Cycle time (days)")
    ax.set_title("c · Cycle time summary",
                  loc="left", fontsize=9, fontweight="bold")
    ax.grid(axis="x", alpha=0.25, linewidth=0.5)
    ax.set_axisbelow(True)
    ax.invert_yaxis()

    # Panel d — SLA-vs-utilisation with a regime-shift trace.
    ax = axes[1, 1]
    utils = np.array([data[s]["reviewer_utilization"]["mean"] for s in scenarios])
    slas = np.array([data[s]["sla_violation_rate"] for s in scenarios])
    ax.plot(utils, slas, color="#525252", linestyle="--", linewidth=0.8,
             alpha=0.6, zorder=1)
    for i, scenario in enumerate(scenarios):
        ax.scatter([utils[i]], [slas[i]], s=110, color=color_for_scenario[i],
                    edgecolor="#262626", linewidth=0.6, zorder=2)
        dx, dy = (-0.04, 0.05) if scenario == "reviewer_shortage" else (0.01, 0.03)
        ha = "right" if scenario == "reviewer_shortage" else "left"
        ax.annotate(scenario, xy=(utils[i], slas[i]),
                     xytext=(utils[i] + dx, slas[i] + dy),
                     fontsize=7.5, color="#262626", ha=ha,
                     arrowprops=dict(arrowstyle="-", color="#bdbdbd",
                                     linewidth=0.5))
    ax.set_xlabel("Mean reviewer utilisation")
    ax.set_ylabel("SLA violation rate")
    ax.set_xlim(0.4, 1.1)
    ax.set_ylim(-0.05, max(slas) * 1.4 + 0.05)
    ax.set_title("d · Utilisation vs SLA",
                  loc="left", fontsize=9, fontweight="bold")
    ax.grid(alpha=0.25, linewidth=0.5)
    ax.set_axisbelow(True)

    save_figure(fig, "validation_distributions", out_dir)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--results-dir", default="results")
    parser.add_argument("--out-dir", default="results/figures")
    return parser.parse_args()


def main() -> None:
    if not HAS_MPL:
        print("[M7] matplotlib not available; install with: pip install matplotlib")
        return

    set_paper_style()

    args = parse_args()
    results_dir = Path(args.results_dir).resolve()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    print("[M7] Generating figures ...")
    make_main_comparison(results_dir, out_dir)
    make_social_negative_result(results_dir, out_dir)
    make_validation_plots(results_dir, out_dir)
    make_stress_comparison(results_dir, out_dir)
    print("[M7] Done.")


if __name__ == "__main__":
    main()
