"""Train continuous-action RL algorithms (PPO/DDPG/TD3/SAC) on ReimburseSim.

Usage:
    python scripts/m2_continuous_rl/train_continuous.py \
        --algo SAC \
        --config configs/default_quarter.yaml \
        --seed 0 --timesteps 50000 \
        --out results/m2/sac_seed0.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from stable_baselines3 import DDPG, PPO, SAC, TD3

from reimbursesim import ReimburseSimEnv, load_scenario

ALGOS = {
    "PPO": PPO,
    "DDPG": DDPG,
    "TD3": TD3,
    "SAC": SAC,
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--algo", required=True, choices=list(ALGOS))
    p.add_argument("--config", required=True)
    p.add_argument("--seed", type=int, default=0)
    p.add_argument("--timesteps", type=int, default=50000)
    p.add_argument("--eval-episodes", type=int, default=5)
    p.add_argument("--out", required=True)
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def make_env(config_path: str, seed: int):
    config = load_scenario(config_path)
    env = ReimburseSimEnv(config)
    env.reset(seed=seed)
    return env


def evaluate(model, env_factory, n_episodes: int, eval_seeds: list[int]) -> list[dict]:
    eps = []
    for s in eval_seeds[:n_episodes]:
        env = env_factory(s)
        obs, _ = env.reset(seed=s)
        rewards = []
        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s_summary = info.get("episode_summary", {})
        s_summary["seed"] = s
        s_summary["total_reward"] = float(sum(rewards))
        s_summary["mean_reward"] = float(np.mean(rewards))
        eps.append(s_summary)
    return eps


def build_metrics(per_episode: list[dict]) -> dict:
    def agg(key):
        vals = [e.get(key, 0.0) for e in per_episode]
        return {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
            "values": [float(v) for v in vals],
        }

    return {
        key: agg(key)
        for key in [
            "total_reward", "leakage_rate", "mean_cycle_time",
            "daily_worst_5pct_mean", "fraud_catch_rate",
            "sla_violation_rate", "appeal_rate", "false_alarm_rate", "audit_count",
        ]
    }


def main() -> None:
    args = parse_args()
    algo_cls = ALGOS[args.algo]

    train_env = make_env(args.config, args.seed)
    print(f"[{args.algo}] action_space={train_env.action_space}  obs_dim={train_env.observation_space.shape[0]}")

    t0 = time.time()

    # Shared defaults tuned for the 6-dim continuous control task
    shared = dict(
        policy="MlpPolicy",
        env=train_env,
        learning_rate=3e-4,
        buffer_size=100000,
        learning_starts=1000,
        batch_size=256,
        gamma=0.99,
        verbose=0 if args.quiet else 1,
        seed=args.seed,
        device="cpu",
    )

    if args.algo == "PPO":
        model = algo_cls(
            "MlpPolicy", train_env,
            learning_rate=3e-4, n_steps=2048, batch_size=64,
            gamma=0.99, gae_lambda=0.95, ent_coef=0.01,
            verbose=shared["verbose"], seed=args.seed, device="cpu",
        )
    elif args.algo == "DDPG":
        model = algo_cls(
            **shared, tau=0.005,
            action_noise=None,  # env already stochastic
        )
    elif args.algo == "TD3":
        model = algo_cls(
            **shared, tau=0.005, policy_delay=2,
            action_noise=None,
        )
    elif args.algo == "SAC":
        model = algo_cls(
            **shared, tau=0.005, ent_coef="auto",
        )

    model.learn(total_timesteps=args.timesteps, progress_bar=False)
    train_wall = time.time() - t0

    eval_seeds = [2000 + args.seed * 10 + i for i in range(args.eval_episodes)]
    per_episode = evaluate(
        model, lambda s: make_env(args.config, s), args.eval_episodes, eval_seeds
    )

    out = {
        "policy": args.algo.lower(),
        "scenario": load_scenario(args.config).scenario_name,
        "train_seed": args.seed,
        "timesteps": args.timesteps,
        "train_wall_seconds": round(train_wall, 1),
        "eval_seeds": eval_seeds,
        "n_eval_episodes": len(per_episode),
        "metrics": build_metrics(per_episode),
        "per_episode": per_episode,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    m = out["metrics"]
    print(
        f"[{args.algo} seed={args.seed}] reward={m['total_reward']['mean']:.2f}±"
        f"{m['total_reward']['std']:.2f}  "
        f"leak={m['leakage_rate']['mean']:.3f}  "
        f"cycle={m['mean_cycle_time']['mean']:.2f}  "
        f"cvar={m['daily_worst_5pct_mean']['mean']:.3f}  "
        f"catch={m['fraud_catch_rate']['mean']:.3f}  "
        f"train={train_wall:.1f}s"
    )
    print(f"  wrote {out_path}")


if __name__ == "__main__":
    main()
