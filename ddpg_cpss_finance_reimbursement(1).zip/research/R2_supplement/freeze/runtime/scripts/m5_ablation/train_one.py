"""Train one ablation variant for one seed. Designed for parallel GPU execution.

Usage:
    python scripts/m5_ablation/train_one.py --variant SAC-Full --seed 0
    python scripts/m5_ablation/train_one.py --variant DQN --seed 0
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

from stable_baselines3 import SAC, DQN

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.wrappers import (
    DiscretizedActionWrapper,
    NoRiskRewardWrapper,
    NoSocialObservationWrapper,
)

METRIC_KEYS = [
    "total_reward", "leakage_rate", "fraud_catch_rate",
    "mean_cycle_time", "daily_worst_5pct_mean", "appeal_rate",
    "false_alarm_rate", "sla_violation_rate", "audit_count",
]


def make_env(config_path, seed, wrapper=None, discretize=False):
    config = load_scenario(config_path)
    env = ReimburseSimEnv(config)
    if discretize:
        env = DiscretizedActionWrapper(env, bins=3)
    if wrapper is not None:
        env = wrapper(env)
    env.reset(seed=seed)
    return env


def evaluate(model, config_path, seeds, wrapper=None, discretize=False):
    results = []
    for seed in seeds:
        env = make_env(config_path, seed, wrapper, discretize)
        obs, _ = env.reset(seed=seed)
        rewards = []
        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, term, _, info = env.step(action)
            rewards.append(reward)
            if term:
                break
        s = info.get("episode_summary", {})
        s["total_reward"] = float(sum(rewards))
        s["seed"] = seed
        results.append(s)
    return results


def aggregate(episodes):
    out = {}
    for key in METRIC_KEYS:
        if key == "total_reward":
            vals = [e["total_reward"] for e in episodes]
        else:
            vals = [e.get(key, 0.0) for e in episodes]
        out[key] = {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
        }
    return out


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--variant", required=True,
                   choices=["SAC-Full", "SAC-NoSocial", "SAC-NoRisk", "DQN"])
    p.add_argument("--config", default="configs/default_quarter.yaml")
    p.add_argument("--seed", type=int, required=True)
    p.add_argument("--timesteps", type=int, default=50000)
    p.add_argument("--eval-seeds", type=int, nargs="+", default=[200, 201, 202, 203, 204])
    p.add_argument("--out-dir", default="results/m5_ablation")
    p.add_argument("--quiet", action="store_true")
    return p.parse_args()


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    wrapper_map = {
        "SAC-Full": None,
        "SAC-NoSocial": NoSocialObservationWrapper,
        "SAC-NoRisk": NoRiskRewardWrapper,
        "DQN": None,
    }

    wrapper = wrapper_map[args.variant]
    t0 = time.time()

    env = make_env(args.config, args.seed, wrapper)

    discretize = (args.variant == "DQN")

    if args.variant == "DQN":
        env = DiscretizedActionWrapper(env, bins=3)
        env.reset(seed=args.seed)
        model = DQN(
            "MlpPolicy", env,
            learning_rate=5e-4, buffer_size=20000, learning_starts=1000,
            batch_size=64, gamma=0.99, target_update_interval=500,
            train_freq=4, exploration_fraction=0.3, exploration_final_eps=0.05,
            verbose=0, seed=args.seed, device="auto",
        )
    else:
        model = SAC(
            "MlpPolicy", env,
            learning_rate=3e-4, buffer_size=100000, learning_starts=1000,
            batch_size=256, gamma=0.99, tau=0.005, ent_coef="auto",
            verbose=0, seed=args.seed, device="auto",
        )

    model.learn(total_timesteps=args.timesteps, progress_bar=False)
    train_time = time.time() - t0

    eval_result = evaluate(model, args.config, args.eval_seeds, wrapper, discretize)
    agg = aggregate(eval_result)

    out = {
        "variant": args.variant,
        "seed": args.seed,
        "timesteps": args.timesteps,
        "train_wall_seconds": round(train_time, 1),
        "metrics": agg,
        "eval_seeds": args.eval_seeds,
    }

    fname = f"{args.variant.replace('-','_')}_seed{args.seed}.json"
    out_path = out_dir / fname
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")

    m = agg
    print(
        f"[{args.variant} seed={args.seed}] "
        f"leak={m['leakage_rate']['mean']:.4f} "
        f"catch={m['fraud_catch_rate']['mean']:.4f} "
        f"cvar={m['daily_worst_5pct_mean']['mean']:.4f} "
        f"train={train_time:.0f}s"
    )


if __name__ == "__main__":
    main()
