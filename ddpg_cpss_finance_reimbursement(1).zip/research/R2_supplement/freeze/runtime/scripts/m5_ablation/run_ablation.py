"""M5 ablation study.

The experiment removes social observations or risk-shaped rewards from the SAC
agent and compares both variants with the full SAC policy and a discretized DQN
baseline.

Usage:
    python scripts/m5_ablation/run_ablation.py --out-dir results/m5_ablation/
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np
from stable_baselines3 import DQN, SAC

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.wrappers import (
    DiscretizedActionWrapper,
    NoRiskRewardWrapper,
    NoSocialObservationWrapper,
)

METRIC_KEYS = [
    "total_reward",
    "leakage_rate",
    "fraud_catch_rate",
    "mean_cycle_time",
    "daily_worst_5pct_mean",
    "appeal_rate",
    "false_alarm_rate",
    "sla_violation_rate",
    "audit_count",
]


def make_env(config_path: str, seed: int, wrapper=None, discretize: bool = False):
    config = load_scenario(config_path)
    env = ReimburseSimEnv(config)
    if discretize:
        env = DiscretizedActionWrapper(env, bins=3)
    if wrapper is not None:
        env = wrapper(env)
    env.reset(seed=seed)
    return env


def evaluate(model, config_path: str, seeds: list[int], wrapper=None, discretize: bool = False) -> list[dict]:
    results = []
    for seed in seeds:
        env = make_env(config_path, seed, wrapper, discretize)
        obs, _ = env.reset(seed=seed)
        rewards = []
        info = {}

        for _ in range(env.unwrapped.config.episode_length):
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, _, info = env.step(action)
            rewards.append(reward)
            if terminated:
                break

        summary = info.get("episode_summary", {})
        summary["total_reward"] = float(sum(rewards))
        summary["seed"] = seed
        results.append(summary)
    return results


def aggregate(episodes: list[dict]) -> dict:
    out = {}
    for key in METRIC_KEYS:
        if key == "total_reward":
            values = [episode["total_reward"] for episode in episodes]
        else:
            values = [episode.get(key, 0.0) for episode in episodes]
        out[key] = {
            "mean": float(np.mean(values)),
            "std": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
        }
    return out


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/default_quarter.yaml")
    parser.add_argument("--train-seeds", type=int, nargs="+", default=[0, 1, 2])
    parser.add_argument("--timesteps", type=int, default=50_000)
    parser.add_argument("--eval-seeds", type=int, nargs="+", default=[200, 201, 202, 203, 204])
    parser.add_argument("--out-dir", default="results/m5_ablation")
    parser.add_argument("--quiet", action="store_true")
    return parser.parse_args()


def train_sac_variant(name: str, wrapper, args) -> dict:
    print(f"\n[M5] Training {name} (seeds={args.train_seeds}) ...")
    results = {}

    for train_seed in args.train_seeds:
        print(f"  seed={train_seed} ...", end=" ", flush=True)
        start = time.time()

        env = make_env(args.config, train_seed, wrapper)
        model = SAC(
            "MlpPolicy",
            env,
            learning_rate=3e-4,
            buffer_size=100_000,
            learning_starts=1_000,
            batch_size=256,
            gamma=0.99,
            tau=0.005,
            ent_coef="auto",
            verbose=0,
            seed=train_seed,
            device="auto",
        )
        model.learn(total_timesteps=args.timesteps, progress_bar=False)
        train_time = time.time() - start

        eval_result = evaluate(model, args.config, args.eval_seeds, wrapper)
        metrics = aggregate(eval_result)
        results[f"seed_{train_seed}"] = {
            "train_wall_seconds": round(train_time, 1),
            "metrics": metrics,
            "eval_seeds": args.eval_seeds,
        }
        print(
            f"leak={metrics['leakage_rate']['mean']:.4f} "
            f"catch={metrics['fraud_catch_rate']['mean']:.4f} ({train_time:.0f}s)"
        )

    return results


def train_dqn(args) -> dict:
    print(f"\n[M5] Training DQN (bins=3, seeds={args.train_seeds}) ...")
    results = {}

    for train_seed in args.train_seeds:
        print(f"  seed={train_seed} ...", end=" ", flush=True)
        start = time.time()

        env = make_env(args.config, train_seed, discretize=True)
        model = DQN(
            "MlpPolicy",
            env,
            learning_rate=5e-4,
            buffer_size=20_000,
            learning_starts=1_000,
            batch_size=64,
            gamma=0.99,
            target_update_interval=500,
            train_freq=4,
            exploration_fraction=0.3,
            exploration_final_eps=0.05,
            verbose=0,
            seed=train_seed,
            device="auto",
        )
        model.learn(total_timesteps=args.timesteps, progress_bar=False)
        train_time = time.time() - start

        eval_result = evaluate(model, args.config, args.eval_seeds, discretize=True)
        metrics = aggregate(eval_result)
        results[f"seed_{train_seed}"] = {
            "train_wall_seconds": round(train_time, 1),
            "metrics": metrics,
            "eval_seeds": args.eval_seeds,
        }
        print(
            f"leak={metrics['leakage_rate']['mean']:.4f} "
            f"catch={metrics['fraud_catch_rate']['mean']:.4f} ({train_time:.0f}s)"
        )

    return results


def summarize(all_results: dict) -> dict:
    summary = {}
    for variant_name, variant_data in all_results.items():
        metrics_by_key = {key: [] for key in METRIC_KEYS}
        for seed_data in variant_data.values():
            for key in METRIC_KEYS:
                metrics_by_key[key].append(seed_data["metrics"][key]["mean"])

        summary[variant_name] = {
            key: {
                "mean": float(np.mean(values)),
                "std": float(np.std(values, ddof=1)) if len(values) > 1 else 0.0,
            }
            for key, values in metrics_by_key.items()
        }
    return summary


def write_outputs(out_dir: Path, args, wall_seconds: float, summary: dict, details: dict) -> None:
    payload = {
        "description": "M5 ablation study",
        "config": args.config,
        "train_seeds": args.train_seeds,
        "timesteps": args.timesteps,
        "eval_seeds": args.eval_seeds,
        "wall_seconds": round(wall_seconds, 1),
        "summary": summary,
        "details": details,
    }

    out_path = out_dir / "ablation_results.json"
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    lines = ["# M5 Ablation Results\n", f"Wall time: {wall_seconds:.0f}s\n"]
    lines.append("| Variant | Leakage | Catch | CVaR | Cycle | Reward |")
    lines.append("|---------|---------|-------|------|-------|--------|")
    for variant_name, metrics in summary.items():
        lines.append(
            f"| {variant_name} | {metrics['leakage_rate']['mean']:.4f} +/- {metrics['leakage_rate']['std']:.4f} | "
            f"{metrics['fraud_catch_rate']['mean']:.4f} +/- {metrics['fraud_catch_rate']['std']:.4f} | "
            f"{metrics['daily_worst_5pct_mean']['mean']:.4f} +/- {metrics['daily_worst_5pct_mean']['std']:.4f} | "
            f"{metrics['mean_cycle_time']['mean']:.3f} +/- {metrics['mean_cycle_time']['std']:.3f} | "
            f"{metrics['total_reward']['mean']:.1f} +/- {metrics['total_reward']['std']:.1f} |"
        )

    md_path = out_dir / "summary.md"
    md_path.write_text("\n".join(lines), encoding="utf-8")
    print(f"\n  Wrote {out_path} and {md_path}")


def main():
    args = parse_args()
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    variants = {
        "SAC-Full": None,
        "SAC-NoSocial": NoSocialObservationWrapper,
        "SAC-NoRisk": NoRiskRewardWrapper,
    }

    start = time.time()
    all_results = {
        name: train_sac_variant(name, wrapper, args)
        for name, wrapper in variants.items()
    }
    all_results["DQN"] = train_dqn(args)

    wall_seconds = time.time() - start
    summary = summarize(all_results)
    write_outputs(out_dir, args, wall_seconds, summary, all_results)


if __name__ == "__main__":
    main()
