"""M6: Structural diagnostics, not proof of real-world validity.

Checks:
1. Claim amount distribution
2. Daily claim volume
3. Fraud rate per applicant type
4. Leakage under fixed rule
5. Cycle time distribution
6. Reviewer utilization
7. SLA violation under normal vs stress
8. Stress event impact on metrics

Output: results/validation/simulator_validation.json + .md
"""

from __future__ import annotations

import json
import argparse
import sys
from collections import Counter
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(PROJECT / "src"))

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.models import ACTION_KEYS, ACTION_RANGES, ApplicantType, ClaimStatus

FIXED_KNOBS = {
    "random_audit_ratio": 0.15,
    "targeted_audit_weight": 0.5,
    "risk_threshold": 0.6,
    "auto_approval_prob": 0.3,
    "escalation_intensity": 0.2,
    "reviewer_load_temperature": 1.0,
}


def encode_action(knobs):
    a = np.zeros(6, dtype=np.float32)
    for i, key in enumerate(ACTION_KEYS):
        lo, hi = ACTION_RANGES[key]
        a[i] = float(np.clip((knobs[key] - lo) / (hi - lo), 0.0, 1.0))
    return a


def run_episode(config_path: str, seed: int, knobs=None):
    if knobs is None:
        knobs = FIXED_KNOBS
    config = load_scenario(config_path)
    env = ReimburseSimEnv(config)
    obs, _ = env.reset(seed=seed)
    action_vec = encode_action(knobs)
    episode_data = {
        "seed": seed,
        "claims": [],
        "daily": [],
        "summary": {},
    }
    for _ in range(config.episode_length):
        obs, reward, term, _, info = env.step(action_vec)
        episode_data["daily"].append({
            "day": info["day"],
            "claims_submitted": info["metrics"]["claims_submitted"],
            "claims_resolved": info["metrics"]["claims_resolved"],
            "leakage_rate": info["metrics"]["leakage_rate"],
            "audit_count": info["metrics"]["audit_count"],
        })
        if term:
            episode_data["summary"] = info.get("episode_summary", {})
            break
    # Collect all claims
    for c in env.claims.values():
        episode_data["claims"].append({
            "claim_id": c.claim_id,
            "amount": c.amount,
            "category": c.category.value,
            "is_fraudulent": c.is_fraudulent,
            "is_split": c.is_split,
            "risk_score": c.risk_score,
            "status": c.status.value,
            "submit_day": c.submit_day,
            "resolution_day": c.resolution_day,
        })
    # Reviewer stats
    reviewer_utils = [r.utilization for r in env.reviewers]
    fatigue_levels = [r.fatigue_level for r in env.reviewers]
    episode_data["reviewer_stats"] = {
        "utilization_mean": float(np.mean(reviewer_utils)),
        "utilization_max": float(np.max(reviewer_utils)),
        "fatigue_mean": float(np.mean(fatigue_levels)),
    }
    # Applicant type distribution
    type_counts = Counter(a.type.value for a in env.applicants)
    episode_data["applicant_types"] = dict(type_counts)
    return episode_data


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=30)
    parser.add_argument("--start-seed", type=int, default=3000)
    parser.add_argument("--out", type=Path, default=Path("results/validation"))
    args = parser.parse_args()
    if args.episodes < 1:
        parser.error("Episode count must be positive")
    seeds = list(range(args.start_seed, args.start_seed + args.episodes))
    out_dir = args.out
    out_dir.mkdir(parents=True, exist_ok=True)
    if (out_dir / "simulator_validation.json").exists():
        raise FileExistsError("Validation results already exist; choose a new --out directory")
    configs = {
        "default_quarter": "configs/default_quarter.yaml",
        "fraud_burst": "configs/stress_fraud_burst.yaml",
        "reviewer_shortage": "configs/stress_reviewer_shortage.yaml",
        "month_end": "configs/stress_month_end.yaml",
        "policy_shock": "configs/stress_policy_shock.yaml",
        "budget_shock": "configs/stress_budget_shock.yaml",
        "public_reference_domestic": "configs/public_reference_domestic.yaml",
        "public_reference_international": "configs/public_reference_international.yaml",
    }

    all_data = {}

    for config_name, config_path in configs.items():
        print(f"[M6] Validating {config_name} ...")
        episodes = [run_episode(config_path, seed) for seed in seeds]
        with (out_dir / f"{config_name}_rollouts.jsonl").open("x", encoding="utf-8") as raw:
            for episode in episodes:
                raw.write(json.dumps(episode, allow_nan=False) + "\n")

        # Aggregate
        amounts = []
        daily_volumes = []
        fraud_count = 0
        total_claims = 0
        cycle_times = []
        leakages = []
        utilizations = []

        for ep in episodes:
            for c in ep["claims"]:
                amounts.append(c["amount"])
                if c["is_fraudulent"]:
                    fraud_count += 1
                if c["resolution_day"] is not None and c["submit_day"] is not None:
                    cycle_times.append(c["resolution_day"] - c["submit_day"] + 1)
                total_claims += 1
            for d in ep["daily"]:
                daily_volumes.append(d["claims_submitted"])
            leakages.append(ep["summary"].get("leakage_rate", 0))
            utilizations.append(ep["reviewer_stats"]["utilization_mean"])

        amounts = np.array(amounts)
        daily_volumes = np.array(daily_volumes)

        all_data[config_name] = {
            "n_episodes": len(episodes),
            "seeds": seeds,
            "config_path": config_path,
            "metric_version": "R1-resolved-cohort-v1",
            "claim_amount": {
                "mean": float(np.mean(amounts)),
                "median": float(np.median(amounts)),
                "std": float(np.std(amounts)),
                "p05": float(np.percentile(amounts, 5)),
                "p95": float(np.percentile(amounts, 95)),
                "max": float(np.max(amounts)),
            },
            "daily_volume": {
                "mean": float(np.mean(daily_volumes)),
                "std": float(np.std(daily_volumes)),
                "max": int(np.max(daily_volumes)),
            },
            "fraud_rate": float(fraud_count / max(1, total_claims)),
            "cycle_time": {
                "mean": float(np.mean(cycle_times)),
                "std": float(np.std(cycle_times)),
                "p95": float(np.percentile(cycle_times, 95)),
                "max": float(np.max(cycle_times)),
            },
            "leakage_rate": {
                "mean": float(np.mean(leakages)),
                "std": float(np.std(leakages)),
            },
            "reviewer_utilization": {
                "mean": float(np.mean(utilizations)),
                "max": float(np.max(utilizations)),
            },
            "sla_violation_rate": float(np.mean([
                ep["summary"].get("sla_violation_rate", 0) for ep in episodes
            ])),
            "episode_summaries": [ep["summary"] for ep in episodes],
        }

    json_path = out_dir / "simulator_validation.json"
    json_path.write_text(json.dumps(all_data, indent=2), encoding="utf-8")

    # Markdown
    md = ["# M6 Simulator Validation\n"]
    for cname, data in all_data.items():
        md.append(f"## {cname}\n")
        ca = data["claim_amount"]
        md.append(f"- Claim amount: mean={ca['mean']:.0f}, median={ca['median']:.0f}, std={ca['std']:.0f}, p95={ca['p95']:.0f}, max={ca['max']:.0f}")
        md.append(f"- Daily volume: mean={data['daily_volume']['mean']:.1f}, max={data['daily_volume']['max']}")
        md.append(f"- Fraud rate: {data['fraud_rate']:.3f}")
        md.append(f"- Cycle time: mean={data['cycle_time']['mean']:.2f}, p95={data['cycle_time']['p95']:.1f}, max={data['cycle_time']['max']:.0f}")
        md.append(f"- Leakage: mean={data['leakage_rate']['mean']:.4f} ± {data['leakage_rate']['std']:.4f}")
        md.append(f"- Reviewer util: mean={data['reviewer_utilization']['mean']:.3f}, max={data['reviewer_utilization']['max']:.3f}")
        md.append(f"- SLA violation: {data['sla_violation_rate']:.4f}")
        md.append("")

    md_path = out_dir / "simulator_validation.md"
    md_path.write_text("\n".join(md), encoding="utf-8")
    print(f"\n  Wrote {json_path} and {md_path}")


if __name__ == "__main__":
    main()
