"""Evaluate a baseline policy across N seeds and save aggregate metrics.

Usage:
    python scripts/m1_baseline/eval_policy.py \\
        --config configs/default_quarter.yaml \\
        --policy fixed_rule \\
        --seeds 0,1,2,3,4 \\
        --out results/m1/fixed_rule.json
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "src"))

from reimbursesim import ReimburseSimEnv, load_scenario  # noqa: E402
from reimbursesim.policies import (  # noqa: E402
    FixedRulePolicy,
    RandomPolicy,
    RiskThresholdPolicy,
)

POLICIES = {
    "fixed_rule": FixedRulePolicy,
    "random": RandomPolicy,
    "risk_threshold": RiskThresholdPolicy,
}


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--policy", required=True, choices=list(POLICIES))
    p.add_argument("--seeds", default="0,1,2,3,4", help="Comma-separated seeds")
    p.add_argument("--out", required=True)
    return p.parse_args()


def run_episode(env: ReimburseSimEnv, policy, seed: int) -> dict:
    policy.reset(seed=seed)
    obs, _ = env.reset(seed=seed)
    rewards = []
    daily_leakage = []
    for _ in range(env.config.episode_length):
        action = policy.act(obs)
        obs, reward, term, _, info = env.step(action)
        rewards.append(reward)
        daily_leakage.append(info["metrics"]["leakage_rate"])
        if term:
            break
    summary = info.get("episode_summary", {})
    summary["total_reward"] = float(sum(rewards))
    summary["mean_reward"] = float(np.mean(rewards))
    summary["daily_leakage"] = daily_leakage
    return summary


def main() -> None:
    args = parse_args()
    config = load_scenario(args.config)
    seeds = [int(s) for s in args.seeds.split(",")]

    policy_cls = POLICIES[args.policy]
    per_seed = []
    t0 = time.time()
    for seed in seeds:
        env = ReimburseSimEnv(config)
        policy = policy_cls()
        summary = run_episode(env, policy, seed)
        summary["seed"] = seed
        per_seed.append(summary)
        print(
            f"[{args.policy} seed={seed}] reward={summary['total_reward']:.2f} "
            f"leak={summary.get('leakage_rate', 0):.3f} "
            f"catch={summary.get('fraud_catch_rate', 0):.3f} "
            f"cycle={summary.get('mean_cycle_time', 0):.2f} "
            f"cvar={summary.get('daily_worst_5pct_mean', 0):.3f}"
        )
    wall = time.time() - t0

    # Aggregate
    def agg(key: str) -> dict:
        vals = [s.get(key, 0.0) for s in per_seed]
        return {
            "mean": float(np.mean(vals)),
            "std": float(np.std(vals, ddof=1)) if len(vals) > 1 else 0.0,
            "values": [float(v) for v in vals],
        }

    out = {
        "policy": args.policy,
        "scenario": config.scenario_name,
        "n_seeds": len(seeds),
        "wall_time_seconds": round(wall, 3),
        "metrics": {
            key: agg(key)
            for key in [
                "total_reward",
                "leakage_rate",
                "fraud_catch_rate",
                "mean_cycle_time",
                "sla_violation_rate",
                "appeal_rate",
                "false_alarm_rate",
                "daily_worst_5pct_mean",
                "audit_count",
            ]
        },
        "per_seed": per_seed,
    }

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(out, indent=2), encoding="utf-8")
    print(
        f"\n[{args.policy}] AGGREGATE  reward={out['metrics']['total_reward']['mean']:.2f}±"
        f"{out['metrics']['total_reward']['std']:.2f}  "
        f"leak={out['metrics']['leakage_rate']['mean']:.3f}±"
        f"{out['metrics']['leakage_rate']['std']:.3f}  "
        f"cycle={out['metrics']['mean_cycle_time']['mean']:.2f}  "
        f"cvar={out['metrics']['daily_worst_5pct_mean']['mean']:.3f}  "
        f"wall={wall:.1f}s"
    )
    print(f"  wrote {out_path}")


if __name__ == "__main__":
    main()
