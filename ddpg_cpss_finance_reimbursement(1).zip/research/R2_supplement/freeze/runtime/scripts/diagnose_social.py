"""Diagnose social observation features to understand why NoSocial > Full.

Checks:
1. Variance / distribution of social features (obs[14:19])
2. Correlation with leakage / fraud outcomes
3. Whether these features provide useful signal or just noise
"""

import sys
from pathlib import Path

import numpy as np

PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT / "src"))

from reimbursesim import ReimburseSimEnv, load_scenario
from reimbursesim.policies import FixedRulePolicy

SOCIAL_NAMES = [
    "obs[14] perceived_audit_intensity",
    "obs[15] reviewer_fatigue",
    "obs[16] reviewer_strictness_drift",
    "obs[17] split_rate_7d",
    "obs[18] appeal_rate_7d",
]


def main():
    config = load_scenario(str(PROJECT / "configs/default_quarter.yaml"))
    seeds = [0, 1, 2, 3, 4]

    all_obs = []
    all_leakage = []

    for seed in seeds:
        env = ReimburseSimEnv(config)
        policy = FixedRulePolicy()
        obs, _ = env.reset(seed=seed)
        for _ in range(config.episode_length):
            action = policy.act(obs)
            obs, reward, term, _, info = env.step(action)
            all_obs.append(obs.copy())
            all_leakage.append(info["metrics"]["leakage_rate"])
            if term:
                break

    all_obs = np.array(all_obs)
    all_leakage = np.array(all_leakage)

    print("=" * 70)
    print("SOCIAL FEATURE DIAGNOSIS")
    print("=" * 70)

    print(f"\nSamples collected: {len(all_obs)} steps across {len(seeds)} seeds")
    print(f"Episode length: {config.episode_length}")

    # 1. Distribution stats
    print("\n--- 1. Feature Distributions ---")
    print(f"{'Feature':<40} {'Mean':>8} {'Std':>8} {'Min':>8} {'Max':>8} {'Zero%':>8}")
    print("-" * 75)
    for i in range(14, 19):
        vals = all_obs[:, i]
        zero_pct = 100 * np.mean(vals == 0.0)
        print(f"{SOCIAL_NAMES[i-14]:<40} {np.mean(vals):8.4f} {np.std(vals):8.4f} "
              f"{np.min(vals):8.4f} {np.max(vals):8.4f} {zero_pct:7.1f}%")

    # 2. Correlation with leakage
    print("\n--- 2. Correlation with Leakage Rate ---")
    for i in range(14, 19):
        vals = all_obs[:, i]
        stdv = np.std(vals)
        if stdv < 1e-6:
            print(f"{SOCIAL_NAMES[i-14]:<40} NO VARIANCE (constant)")
            continue
        corr = np.corrcoef(vals, all_leakage)[0, 1]
        # Time-lagged correlation: does feature at t predict leakage at t+1?
        if len(vals) > 1:
            lag_corr = np.corrcoef(vals[:-1], all_leakage[1:])[0, 1]
        else:
            lag_corr = 0.0
        print(f"{SOCIAL_NAMES[i-14]:<40} corr={corr:+.4f}  lag1_corr={lag_corr:+.4f}")

    # 3. High-leak vs Low-leak analysis
    print("\n--- 3. Feature Values: High Leak (top 20%) vs Low Leak (bottom 20%) ---")
    n_high = max(1, len(all_leakage) // 5)
    idx_high = np.argsort(all_leakage)[-n_high:]
    idx_low = np.argsort(all_leakage)[:n_high]

    for i in range(14, 19):
        mean_high = np.mean(all_obs[idx_high, i])
        mean_low = np.mean(all_obs[idx_low, i])
        diff = mean_high - mean_low
        print(f"{SOCIAL_NAMES[i-14]:<40} high_leak={mean_high:.4f}  low_leak={mean_low:.4f}  Δ={diff:+.4f}")

    # 4. Feature correlation matrix (are social features redundant?)
    print("\n--- 4. Social Feature Inter-Correlation ---")
    social_block = all_obs[:, 14:19]
    for i in range(5):
        row = " ".join(f"{np.corrcoef(social_block[:, i], social_block[:, j])[0,1]:+7.3f}" for j in range(5))
        print(f"  {SOCIAL_NAMES[i][:40]}: [{row}]")

    # 5. Non-social feature distribution for comparison
    print("\n--- 5. Non-Social Features (for comparison) ---")
    non_social = np.concatenate([all_obs[:, :14], all_obs[:, 19:]], axis=1)
    print(f"  Non-social dims: mean_std={np.mean(np.std(non_social, axis=0)):.4f}, "
          f"mean_abs={np.mean(np.abs(non_social)):.4f}")
    social_only = all_obs[:, 14:19]
    print(f"  Social dims only: mean_std={np.mean(np.std(social_only, axis=0)):.4f}, "
          f"mean_abs={np.mean(np.abs(social_only)):.4f}")

    # 6. SAC training: what number of effective dims matters?
    print("\n--- 6. Assessment ---")
    n_constant = sum(1 for i in range(14, 19) if np.std(all_obs[:, i]) < 0.001)
    n_low_var = sum(1 for i in range(14, 19) if np.std(all_obs[:, i]) < 0.05)
    max_corr = max(abs(np.corrcoef(all_obs[:, i], all_leakage)[0, 1]) for i in range(14, 19) if np.std(all_obs[:, i]) > 0.001)

    print(f"  Constant features (std<0.001): {n_constant}/5")
    print(f"  Low-variance features (std<0.05): {n_low_var}/5")
    print(f"  Max |correlation with leakage|: {max_corr:.4f}")
    if n_low_var >= 3 or max_corr < 0.1:
        print("  VERDICT: Social features carry little useful signal → explains NoSocial >= Full")
    else:
        print("  VERDICT: Social features have signal → need deeper investigation")


if __name__ == "__main__":
    main()
