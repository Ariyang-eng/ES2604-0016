import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import pytest


@pytest.mark.skipif(not sys.platform.startswith("linux"), reason="Linux parent-death signal")
@pytest.mark.parametrize("paused", [False, True])
def test_owned_worker_dies_with_scheduler_even_if_stopped(tmp_path, paused):
    psutil = pytest.importorskip("psutil")
    root = Path(__file__).resolve().parents[1]
    pid_file = tmp_path / "owned_worker.pid"
    parent = subprocess.Popen([sys.executable, str(root / "tests/fixtures/guard_parent.py"),
                               str(pid_file)], stdout=subprocess.PIPE, text=True,
                              start_new_session=True)
    child = None
    def terminated():
        try:
            return child is None or not child.is_running() or child.status() == psutil.STATUS_ZOMBIE
        except psutil.NoSuchProcess:
            return True

    try:
        assert parent.stdout.readline().strip() == "READY"
        child = psutil.Process(int(pid_file.read_text()))
        assert child.ppid() == parent.pid
        if paused:
            os.kill(child.pid, signal.SIGSTOP)
        parent.kill()
        parent.wait(timeout=5)
        deadline = time.monotonic() + 5
        while time.monotonic() < deadline:
            if terminated():
                break
            time.sleep(0.05)
        assert terminated()
    finally:
        if parent.poll() is None:
            parent.kill()
        parent.wait(timeout=5)
        if not terminated():
            child.kill()
