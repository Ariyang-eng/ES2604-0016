"""Subprocess fixture: expose only a newly spawned guarded child's PID."""

import os
from pathlib import Path
import subprocess
import sys


root = Path(__file__).resolve().parents[2]
child = subprocess.Popen([sys.executable, str(root / "scripts/r1/owned_job.py"),
    "--parent", str(os.getpid()), "--", sys.executable, "-u", "-c",
    "import time; print('READY', flush=True); time.sleep(120)"], start_new_session=True)
Path(sys.argv[1]).write_text(str(child.pid), encoding="ascii")
child.wait()
