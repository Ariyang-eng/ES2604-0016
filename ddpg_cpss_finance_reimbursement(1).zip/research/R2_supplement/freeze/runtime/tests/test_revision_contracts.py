from dataclasses import asdict
from pathlib import Path

import numpy as np
import pytest

from reimbursesim.applicants import Applicant
from reimbursesim.config import ScenarioConfig, StressEvent, load_scenario
from reimbursesim.env import EpisodeSummary, ReimburseSimEnv
from reimbursesim.metrics import DailyMetrics, build_observation, compute_reward
from reimbursesim.models import ApplicantType, CategoryType, Claim, ClaimStatus, decode_action
from reimbursesim.wrappers import NoRiskRewardWrapper, QuantizedBoxActionWrapper


ROOT = Path(__file__).resolve().parents[1]
SCENARIOS = ["default_quarter", "stress_fraud_burst", "stress_month_end",
             "stress_reviewer_shortage", "stress_policy_shock", "stress_budget_shock"]
ACTION = np.full(6, 0.5, dtype=np.float32)


@pytest.mark.parametrize("name", SCENARIOS[1:])
def test_stress_configuration_changes_only_declared_event(name):
    base = asdict(load_scenario(ROOT / "configs/default_quarter.yaml"))
    stress = asdict(load_scenario(ROOT / f"configs/{name}.yaml"))
    assert base["stress_events"] == []
    assert len(stress["stress_events"]) == 1
    for key in base:
        if key not in {"scenario_name", "stress_events"}:
            assert base[key] == stress[key], key


@pytest.mark.parametrize("kind,params", [
    ("fraud_burst", {"burst_multiplier": 5}),
    ("month_end_surge", {"surge_multiplier": 3}),
    ("reviewer_shortage", {"unavailable_fraction": 0.4}),
    ("policy_shock", {"min_audit_ratio": 0.4, "perceived_intensity": 0.8}),
    ("budget_shock", {"department_id": 0, "remaining_fraction": 0.05}),
])
def test_event_boundaries_and_no_configuration_mutation(kind, params):
    config = ScenarioConfig(stress_events=[StressEvent(kind, 2, 2, params)])
    before = asdict(config)
    env = ReimburseSimEnv(config)
    env.reset(seed=11)
    for day in [1, 2, 3, 4]:
        env.day = day
        knobs = decode_action(ACTION)
        flag = env._apply_stress_overrides(knobs)
        assert bool(env._active_stress_events) == (day in {2, 3})
        assert flag == (kind == "policy_shock" and day in {2, 3})
        assert env._submission_multiplier == (3 if kind == "month_end_surge" and day in {2, 3} else 1)
        assert env._burst_multiplier == (5 if kind == "fraud_burst" and day in {2, 3} else 1)
        assert len(env._unavailable_reviewers) == (4 if kind == "reviewer_shortage" and day in {2, 3} else 0)
        assert env.departments[0].budget_remaining == (25000 if kind == "budget_shock" and day >= 2 else 500000)
        assert all(d.budget_remaining == 500000 for i, d in env.departments.items() if i != 0)
        expected = decode_action(ACTION)
        if flag:
            expected["random_audit_ratio"] = 0.4
        assert knobs == expected
    assert asdict(config) == before == asdict(env.config)
    env.reset(seed=11)
    assert env.departments[0].budget_remaining == 500000
    assert env._applied_stress_events == set()
    assert env._unavailable_reviewers == set()


def test_policy_perception_reset_only_at_event_onset():
    env = ReimburseSimEnv(ScenarioConfig(stress_events=[StressEvent("policy_shock", 0, 2)]))
    env.reset(seed=0)
    env._apply_stress_overrides(decode_action(ACTION))
    assert all(a.perceived_audit_intensity == 0.8 for a in env.applicants)
    env.applicants[0].perceived_audit_intensity = 0.6
    env.day = 1
    env._apply_stress_overrides(decode_action(ACTION))
    assert env.applicants[0].perceived_audit_intensity == 0.6


def test_distinct_policy_shock_events_have_distinct_onset_resets():
    env = ReimburseSimEnv(ScenarioConfig(stress_events=[
        StressEvent("policy_shock", 0, 1), StressEvent("policy_shock", 3, 1)]))
    env.reset(seed=0)
    env._apply_stress_overrides(decode_action(ACTION))
    env.applicants[0].perceived_audit_intensity = 0.2
    env.day = 3
    env._apply_stress_overrides(decode_action(ACTION))
    assert env.applicants[0].perceived_audit_intensity == 0.8
    assert env._applied_stress_events == {0, 1}


def test_cached_evaluation_config_is_independent_and_does_not_reload_disk(monkeypatch):
    import train
    config = ScenarioConfig()
    snapshots = {"default_quarter": config}
    monkeypatch.setattr(train, "load_scenario", lambda p: pytest.fail("Unexpected disk reload"))
    first = train.make_env("SAC-NoRisk", "default_quarter", configs=snapshots)
    second = train.make_env("SAC-Full", "default_quarter", configs=snapshots)
    assert first.unwrapped.config.reward_weights["w_rolling_max"] == 0
    assert second.unwrapped.config.reward_weights["w_rolling_max"] == 0.8
    assert config.reward_weights["w_rolling_max"] == 0.8


def test_surge_reaches_poisson_generation_without_changing_base_rate():
    class FakeRng:
        def poisson(self, rate):
            self.rate = rate
            return 0

    rng = FakeRng()
    a = Applicant(0, 0, ApplicantType.HONEST, submission_rate=0.3)
    assert a.generate_claims(0, {}, rng, 0, submission_multiplier=3) == []
    assert rng.rate == pytest.approx(0.9)
    assert a.submission_rate == 0.3


def test_forced_burst_activates_dormant_fraud_actor_only():
    a = Applicant(0, 0, ApplicantType.FRAUDULENT_BURST)
    claims = a.generate_claims(0, {}, np.random.default_rng(4), 100,
                               force_burst=True, burst_multiplier=5)
    assert 15 <= len(claims) <= 25
    assert all(c.is_fraudulent for c in claims)
    assert [c.claim_id for c in claims] == list(range(100, 100 + len(claims)))
    honest = Applicant(1, 0, ApplicantType.HONEST)
    plain = honest.generate_claims(0, {}, np.random.default_rng(4), 0)
    stressed = honest.generate_claims(0, {}, np.random.default_rng(4), 0,
                                     force_burst=True, burst_multiplier=5)
    assert plain == stressed


def test_shortage_preserves_absent_reviewer_queue_and_stops_new_assignment():
    env = ReimburseSimEnv(ScenarioConfig(stress_events=[StressEvent("reviewer_shortage", 1, 1)]))
    env.reset(seed=1)
    env.day = 1
    env._apply_stress_overrides(decode_action(ACTION))
    old = Claim(0, 0, 100, CategoryType.MEAL, 0, 0,
                status=ClaimStatus.UNDER_REVIEW, assigned_reviewer=0, enqueue_day=0)
    new = Claim(1, 0, 100, CategoryType.MEAL, 0, 1)
    env.claims = {0: old, 1: new}
    env.reviewers[0].queue = [0]
    env.pending_claims = [1]
    knobs = decode_action(ACTION)
    knobs.update(random_audit_ratio=0, targeted_audit_weight=0, auto_approval_prob=0)
    metrics = DailyMetrics(day=1)
    env._route_claims(knobs, env._rng, metrics)
    assert new.assigned_reviewer not in env._unavailable_reviewers
    env._reviewer_step(knobs, env._rng, metrics)
    assert env.reviewers[0].queue == [0]
    assert old.status == ClaimStatus.UNDER_REVIEW
    env.day = 2
    env._apply_stress_overrides(knobs)
    env._reviewer_step(knobs, env._rng, DailyMetrics(day=2))
    assert old.status != ClaimStatus.UNDER_REVIEW


def test_episode_rates_use_resolved_cohort_not_all_submissions():
    summary = EpisodeSummary(total_claims=10, total_fraud_claims=4, total_fraud_amount=1000,
        total_leakage_amount=100, resolved_claims=5, resolved_fraud_claims=2,
        resolved_fraud_amount=400, resolved_legitimate_claims=3,
        unresolved_claims=5, unresolved_fraud_claims=2, unresolved_fraud_amount=600,
        fraud_caught=1, false_alarms=1, audit_count=1, sla_violations=2)
    d = summary.as_dict()
    assert d["leakage_rate"] == 0.25
    assert d["fraud_catch_rate"] == 0.5
    assert d["false_alarm_rate"] == pytest.approx(1 / 3)
    assert d["sla_violation_rate"] == 0.2
    assert d["fraud_value_resolution_fraction"] == 0.4
    assert d["unresolved_fraud_amount"] == 600
    assert d["submitted_leakage_lower_bound"] == 0.1
    assert d["submitted_leakage_upper_bound"] == 0.7
    assert d["submitted_catch_lower_bound"] == 0.25
    assert d["submitted_catch_upper_bound"] == 0.75


def test_empty_cohort_is_explicitly_marked_undefined():
    d = EpisodeSummary().as_dict()
    assert not d["leakage_rate_defined"]
    assert not d["fraud_catch_rate_defined"]
    assert not d["false_alarm_rate_defined"]


def test_rolling_risk_is_a_maximum_not_a_tail_expectation():
    buffer = list(np.linspace(0, 1, 20))
    reward, breakdown = compute_reward(DailyMetrics(0), {"w_rolling_max": 1}, buffer, 0, 3)
    assert breakdown["rolling_max_leakage"] == 1
    assert "cvar" not in breakdown
    assert build_observation({}, buffer)[20] == 1
    assert compute_reward(DailyMetrics(0), {}, [], 0, 3)[1]["rolling_max_leakage"] == 0


def test_reward_ablation_cannot_mutate_another_environment_or_source_config():
    config = ScenarioConfig()
    first, second = ReimburseSimEnv(config), ReimburseSimEnv(config)
    NoRiskRewardWrapper(first)
    assert first.config.reward_weights["w_rolling_max"] == 0
    assert config.reward_weights["w_rolling_max"] == second.config.reward_weights["w_rolling_max"] == 0.8


@pytest.mark.parametrize("cap", [0, 1, 5])
def test_all_audit_paths_respect_daily_resource_cap(cap):
    env = ReimburseSimEnv(ScenarioConfig(audit_cap_per_day=cap))
    env.reset(seed=1)
    for _ in range(5):
        _, _, _, _, info = env.step(np.array([1, 1, 0, 0, 0.5, 0.5]))
        assert info["metrics"]["audit_count"] <= cap
        assert all(c.status != ClaimStatus.PENDING for c in env.claims.values())


def test_quantized_ppo_executes_same_centers_without_changing_box_interface():
    env = QuantizedBoxActionWrapper(ReimburseSimEnv(), bins=2)
    assert env.action_space.shape == (6,)
    result = env.action(np.array([-1, 0, 0.49, 0.5, 1, 2]))
    np.testing.assert_array_equal(result, [0.25, 0.25, 0.25, 0.75, 0.75, 0.75])


@pytest.mark.parametrize("name", SCENARIOS)
def test_full_episode_reproducibility_cohort_conservation_and_valid_observations(name):
    config = load_scenario(ROOT / f"configs/{name}.yaml")
    summaries = []
    for _ in range(2):
        env = ReimburseSimEnv(config)
        env.reset(seed=200)
        for day in range(config.episode_length):
            obs, reward, done, truncated, info = env.step(ACTION)
            assert env.observation_space.contains(obs)
            assert np.isfinite(reward)
            assert done == (day == config.episode_length - 1)
            assert not truncated
        d = info["episode_summary"]
        assert d["resolved_claims"] + d["unresolved_claims"] == d["total_claims"]
        assert d["resolved_fraud_claims"] + d["unresolved_fraud_claims"] == d["total_fraud_claims"]
        assert d["resolved_fraud_amount"] + d["unresolved_fraud_amount"] == pytest.approx(d["total_fraud_amount"])
        assert d["unresolved_fraud_amount"] == pytest.approx(sum(c.amount for c in env.claims.values()
            if c.is_fraudulent and c.resolution_day is None))
        for metric in ["leakage_rate", "fraud_catch_rate", "false_alarm_rate", "sla_violation_rate"]:
            assert 0 <= d[metric] <= 1
        with pytest.raises(RuntimeError):
            env.step(ACTION)
        summaries.append(d)
    assert summaries[0] == summaries[1]


@pytest.mark.parametrize("event", [StressEvent("unknown", 0, 1),
    StressEvent("fraud_burst", -1, 1), StressEvent("fraud_burst", 59, 2),
    StressEvent("fraud_burst", 0, 1, {"unused": 2}),
    StressEvent("fraud_burst", 0, 1, {"burst_multiplier": float("nan")}),
    StressEvent("reviewer_shortage", 0, 1, {"unavailable_fraction": 1}),
    StressEvent("policy_shock", 0, 1, {"min_audit_ratio": 0.9})])
def test_invalid_stress_configuration_fails_loudly(event):
    with pytest.raises(ValueError):
        ScenarioConfig(stress_events=[event])


@pytest.mark.parametrize("name", ["m0_sanity", "m0_sanity_adaptive", "m3_stress"])
def test_legacy_auxiliary_scenarios_still_load(name):
    assert load_scenario(ROOT / f"configs/{name}.yaml").episode_length > 0


@pytest.mark.parametrize("name,sigma", [("domestic", 1.0618928160711947),
                                       ("international", 1.178158958047975)])
def test_public_reference_shape_is_wired_without_importing_a_currency_scale(name, sigma):
    config = load_scenario(ROOT / f"configs/public_reference_{name}.yaml")
    assert config.claim_amount_log_mu == 6.0
    assert config.claim_amount_log_sigma == sigma
    env = ReimburseSimEnv(config)
    env.reset(seed=0)
    assert all(a.amount_log_sigma == sigma for a in env.applicants)
    assert all(a.amount_log_mu == 6.0 for a in env.applicants)
