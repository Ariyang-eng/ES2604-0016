# Frozen Runtime

The 47 files listed in `revision/source_manifest_formal.json` retain their evaluated contents.

Use `scripts/r1/train.py` for the original 500,000-step training protocol. Use `../../worker.py` from this runtime directory for the separate cap-5 protocol, following the working-directory instructions in the package-level `REPRODUCTION.md`.

Legacy scripts remain in the source manifest for traceability. Their older default budgets are not the R2 protocol. The legacy remote runner reads connection settings from environment variables; it contains no embedded credentials and is not invoked by tests.

Model weights and historical run directories are not part of this runtime directory.
