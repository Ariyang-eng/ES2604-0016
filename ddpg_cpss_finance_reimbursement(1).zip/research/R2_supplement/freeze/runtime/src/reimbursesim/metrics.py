"""Reward, observation, and metric helpers for ReimburseSim.

Single source of truth for what the agent sees and how it is graded.
"""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np


@dataclass
class DailyMetrics:
    day: int
    claims_submitted: int = 0
    claims_resolved: int = 0
    fraud_missed: int = 0  # leakage count
    fraud_caught: int = 0
    leakage_amount: float = 0.0
    # Sum of fraud amount in claims SUBMITTED today (kept for backward compat)
    total_fraud_amount: float = 0.0
    # Sum of fraud amount in claims RESOLVED today (correct cohort for leakage_rate)
    resolved_fraud_amount: float = 0.0
    resolved_fraud_claims: int = 0
    resolved_legitimate_claims: int = 0
    audit_count: int = 0
    false_alarms: int = 0
    appeals: int = 0
    sla_violations: int = 0
    cycle_times: list[float] = field(default_factory=list)
    approved_amount: float = 0.0
    action: list[float] = field(default_factory=list)

    @property
    def avg_cycle_time(self) -> float:
        return float(np.mean(self.cycle_times)) if self.cycle_times else 0.0

    @property
    def leakage_rate(self) -> float:
        # Cohort-correct: leakage_amount and resolved_fraud_amount both refer to
        # claims resolved today, so the ratio is well-defined.
        if self.resolved_fraud_amount <= 0:
            return 0.0
        return float(min(1.0, self.leakage_amount / self.resolved_fraud_amount))


def compute_reward(
    metrics: DailyMetrics,
    weights: dict[str, float],
    rolling_max_buffer: list[float],
    morale_index: float,
    sla_target: int,
    cost_per_audit: float = 1.0,
) -> tuple[float, dict[str, float]]:
    """Compute scalar reward + breakdown for diagnostics.

    All component terms normalized to [0, 1] before weighting.
    """
    leak_rate = metrics.leakage_rate
    audit_norm = min(1.0, metrics.audit_count / max(1, metrics.claims_submitted))
    cycle_pen = max(0.0, (metrics.avg_cycle_time - sla_target) / max(1.0, sla_target))
    cycle_pen = min(1.0, cycle_pen)
    fa_rate = (
        metrics.false_alarms / metrics.resolved_legitimate_claims
        if metrics.resolved_legitimate_claims > 0
        else 0.0
    )
    appeal_rate = (
        metrics.appeals / metrics.claims_resolved if metrics.claims_resolved > 0 else 0.0
    )
    throughput_ratio = (
        min(1.0, metrics.claims_resolved / metrics.claims_submitted)
        if metrics.claims_submitted > 0
        else 0.0
    )

    rolling_max = max(rolling_max_buffer, default=0.0)

    breakdown = {
        "leakage": leak_rate,
        "audit_cost": audit_norm * cost_per_audit,
        "cycle_penalty": cycle_pen,
        "false_alarm": fa_rate,
        "appeal": appeal_rate,
        "morale": morale_index,
        "rolling_max_leakage": float(rolling_max),
        "throughput": throughput_ratio,
    }

    reward = (
        -weights.get("w_leak", 1.0) * breakdown["leakage"]
        - weights.get("w_cost", 0.3) * breakdown["audit_cost"]
        - weights.get("w_cycle", 0.5) * breakdown["cycle_penalty"]
        - weights.get("w_fa", 0.2) * breakdown["false_alarm"]
        - weights.get("w_appeal", 0.4) * breakdown["appeal"]
        - weights.get("w_morale", 0.2) * breakdown["morale"]
        - weights.get("w_rolling_max", 0.8) * breakdown["rolling_max_leakage"]
        + weights.get("w_throughput", 0.3) * breakdown["throughput"]
    )
    return float(reward), breakdown


OBS_DIM = 24


def build_observation(
    state: dict,
    rolling_max_buffer: list[float],
) -> np.ndarray:
    """Construct the 24-dim observation vector per spec.

    All features normalized to [0, 1].
    """
    o = np.zeros(OBS_DIM, dtype=np.float32)

    pending = state.get("pending_claims", [])
    o[0] = min(1.0, len(pending) / max(1, state.get("max_queue_size", 200)))
    if pending:
        ages = [state["day"] - c.submit_day for c in pending]
        o[1] = min(1.0, float(np.mean(ages)) / state.get("sla_hard_limit", 10))
    else:
        o[1] = 0.0

    reviewers = state.get("reviewers", [])
    if reviewers:
        utils = [r.utilization for r in reviewers]
        o[2] = float(np.mean(utils))
    o[3] = min(
        1.0,
        sum(len(m.escalation_queue) for m in state.get("managers", []))
        / max(1, state.get("max_escalation", 50)),
    )

    depts = state.get("departments", {})
    if depts:
        ratios = [d.budget_remaining / max(1.0, d.budget_total) for d in depts.values()]
        o[4] = float(np.clip(np.mean(ratios), 0.0, 1.0))
        # cash_flow_pressure
        min_ratio = min(ratios) if ratios else 1.0
        o[6] = 1.0 if min_ratio < 0.1 else float(1.0 - min_ratio)
    else:
        o[4] = 1.0
        o[6] = 0.0
    o[5] = float(np.clip(state.get("monthly_spend_velocity", 0.0), 0.0, 1.0))

    if pending:
        risks = [c.risk_score for c in pending]
        o[7] = float(np.clip(np.mean(risks), 0.0, 1.0))
        amounts = [c.amount for c in pending]
        median = float(np.median(amounts))
        high_count = sum(1 for a in amounts if a > 2 * median)
        o[8] = float(high_count / max(1, len(amounts)))
        cross = sum(1 for c in pending if c.department < 0)  # placeholder, depts not crossing
        o[9] = float(cross / max(1, len(pending)))
    else:
        o[7] = 0.0
        o[8] = 0.0
        o[9] = 0.0

    o[10] = float(np.clip(state.get("repeat_offender_ratio", 0.0), 0.0, 1.0))
    o[11] = float(np.clip(state.get("current_audit_ratio", 0.0), 0.0, 1.0))
    o[12] = float(np.clip(state.get("targeted_hit_rate_7d", 0.0), 0.0, 1.0))
    o[13] = float(np.clip(state.get("false_alarm_rate_7d", 0.0), 0.0, 1.0))

    applicants = state.get("applicants", [])
    if applicants:
        o[14] = float(np.mean([a.perceived_audit_intensity for a in applicants]))
    o[15] = float(np.mean([r.fatigue_level for r in reviewers])) if reviewers else 0.0
    o[16] = float(np.std([r.strictness for r in reviewers])) if reviewers else 0.0
    o[17] = float(np.clip(state.get("split_rate_7d", 0.0), 0.0, 1.0))
    o[18] = float(np.clip(state.get("appeal_rate_7d", 0.0), 0.0, 1.0))
    o[19] = float(np.clip(state.get("leakage_rate_7d", 0.0), 0.0, 1.0))

    if rolling_max_buffer:
        o[20] = float(np.clip(max(rolling_max_buffer), 0.0, 1.0))
    o[21] = float(np.clip(state.get("sla_violation_rate_7d", 0.0), 0.0, 1.0))
    o[22] = 1.0 if state.get("policy_shock_active", False) else 0.0
    o[23] = float((state.get("day", 0) % 30) / 30.0)
    # Final defensive clip + NaN replace
    o = np.nan_to_num(o, nan=0.0, posinf=1.0, neginf=0.0)
    o = np.clip(o, 0.0, 1.0)
    return o.astype(np.float32)
