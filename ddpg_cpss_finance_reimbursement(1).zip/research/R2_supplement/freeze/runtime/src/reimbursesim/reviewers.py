"""Reviewer agent behaviors (4 types) for ReimburseSim-CPSS."""

from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from reimbursesim.models import (
    Claim,
    ClaimStatus,
    ReviewerType,
)


# Per-type defaults: (base_accuracy, base_capacity, base_escalation_rate)
REVIEWER_DEFAULTS = {
    ReviewerType.DILIGENT: (0.90, 8, 0.10),
    ReviewerType.RUBBER_STAMPER: (0.60, 15, 0.02),
    ReviewerType.RISK_AVERSE_ESCALATOR: (0.80, 6, 0.30),
    ReviewerType.ADAPTIVE: (0.75, 10, 0.15),
}


@dataclass
class Reviewer:
    reviewer_id: int
    type: ReviewerType
    base_accuracy: float = 0.80
    base_capacity: int = 10
    base_escalation_rate: float = 0.10

    queue: list[int] = field(default_factory=list)  # claim ids
    fatigue_level: float = 0.0
    days_overloaded: int = 0
    strictness: float = 0.5  # adaptive only
    recent_fraud_caught: int = 0

    enable_adaptation: bool = True

    # Internal buffers used by env to close the manager-feedback loop. Adaptive
    # reviewers EMA over these buffers in daily_update.
    _last_decisions: list = field(default_factory=list)
    _manager_feedback_buf: list = field(default_factory=list)

    @classmethod
    def make(cls, reviewer_id: int, rtype: ReviewerType, enable_adaptation: bool) -> "Reviewer":
        acc, cap, esc = REVIEWER_DEFAULTS[rtype]
        return cls(
            reviewer_id=reviewer_id,
            type=rtype,
            base_accuracy=acc,
            base_capacity=cap,
            base_escalation_rate=esc,
            enable_adaptation=enable_adaptation,
        )

    @property
    def capacity(self) -> int:
        return self.base_capacity

    @property
    def current_load(self) -> int:
        return len(self.queue)

    @property
    def utilization(self) -> float:
        return min(1.0, self.current_load / max(1, self.capacity))

    @property
    def accuracy(self) -> float:
        """Effective accuracy after fatigue/load effects."""
        acc = self.base_accuracy
        if self.type == ReviewerType.RUBBER_STAMPER and self.utilization > 0.8:
            acc = 0.30
        # Fatigue degradation for diligent reviewer
        if self.type == ReviewerType.DILIGENT and self.days_overloaded > 5:
            acc = max(0.70, acc - 0.02 * (self.days_overloaded - 5))
        # General fatigue for everyone
        acc = max(0.40, acc - 0.2 * self.fatigue_level)
        return acc

    @property
    def effective_speed(self) -> int:
        """Claims per day under current condition."""
        if self.type == ReviewerType.RUBBER_STAMPER and self.utilization > 0.8:
            return 15
        if self.type == ReviewerType.DILIGENT and self.days_overloaded > 5:
            return 12
        return self.base_capacity

    @property
    def escalation_rate(self) -> float:
        rate = self.base_escalation_rate
        if self.type == ReviewerType.RISK_AVERSE_ESCALATOR and self.enable_adaptation:
            # Increases with recent fraud
            rate += 0.02 * min(10, self.recent_fraud_caught)
        if self.type == ReviewerType.ADAPTIVE and self.enable_adaptation:
            # Driven by strictness EMA
            rate = 0.05 + 0.4 * self.strictness
        return min(1.0, rate)

    def process_claim(
        self,
        claim: Claim,
        knobs: dict[str, float],
        rng: np.random.Generator,
        day: int,
    ) -> str:
        """Decide claim outcome.

        Returns one of: 'approve', 'reject', 'escalate'.
        """
        # Decide escalate first
        eff_esc = self.escalation_rate * (0.5 + 0.5 * knobs["escalation_intensity"])
        if rng.random() < eff_esc:
            return "escalate"

        # Detection: with prob = accuracy correctly classify
        if rng.random() < self.accuracy:
            base = "reject" if claim.is_fraudulent else "approve"
        else:
            # Misclassification
            if self.type == ReviewerType.RUBBER_STAMPER and self.utilization > 0.8:
                base = "approve"  # under load, defaults to approve
            else:
                base = "approve" if claim.is_fraudulent else "reject"

        # Adaptive reviewers tighten/loosen their final approval threshold
        # based on their EMA strictness signal (closes the social loop).
        if self.type == ReviewerType.ADAPTIVE and self.enable_adaptation and base == "approve":
            # High strictness -> chance of flipping borderline approvals to reject
            if claim.risk_score > (0.6 - 0.4 * self.strictness):
                if rng.random() < self.strictness:
                    base = "reject"
        return base

    def daily_update(
        self,
        manager_feedback: float | None,
        day: int,
    ) -> None:
        """Update fatigue / strictness daily (after processing).

        manager_feedback is computed from ``_manager_feedback_buf`` if not provided.
        """
        if self.utilization > 0.8:
            self.days_overloaded += 1
            self.fatigue_level = min(1.0, self.fatigue_level + 0.05)
        else:
            self.days_overloaded = max(0, self.days_overloaded - 1)
            self.fatigue_level = max(0.0, self.fatigue_level - 0.03)

        if self.type == ReviewerType.ADAPTIVE and self.enable_adaptation:
            # Aggregate manager feedback signal from buffered comparisons
            if manager_feedback is None and self._manager_feedback_buf:
                manager_feedback = float(np.mean(self._manager_feedback_buf))
            if manager_feedback is None:
                manager_feedback = 0.0
            # Negative feedback (manager overturned -> we were wrong) -> raise strictness
            target = 0.5 - 0.5 * manager_feedback
            self.strictness = 0.8 * self.strictness + 0.2 * target
            self.strictness = float(np.clip(self.strictness, 0.0, 1.0))

        # Decay decision/feedback buffers
        if len(self._last_decisions) > 50:
            self._last_decisions = self._last_decisions[-50:]
        if len(self._manager_feedback_buf) > 30:
            self._manager_feedback_buf = self._manager_feedback_buf[-30:]
