"""ReimburseSim-CPSS Gymnasium environment.

Core MDP: 1 step = 1 working day, episode = 1 fiscal quarter (60 days).

Step lifecycle (matches spec):
    1. Decode action -> control knobs
    2. Applicants generate today's claims
    3. Risk scoring
    4. Routing decision (auto-approve / random audit / targeted audit / reviewer assignment)
    5. Reviewer processing
    6. Manager processing of escalations
    7. Appeal processing
    8. Applicant + reviewer adaptation
    9. Compute reward + observation
    10. Termination check (end of quarter)
"""

from __future__ import annotations

from collections import deque
from copy import deepcopy
from dataclasses import dataclass

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from reimbursesim.applicants import Applicant
from reimbursesim.config import ScenarioConfig, StressEvent
from reimbursesim.metrics import (
    OBS_DIM,
    DailyMetrics,
    build_observation,
    compute_reward,
)
from reimbursesim.models import (
    ACTION_KEYS,
    DEFAULT_POLICY,
    ApplicantType,
    Claim,
    ClaimStatus,
    Department,
    Manager,
    ReviewerType,
    decode_action,
)
from reimbursesim.reviewers import Reviewer
from reimbursesim.risk_model import RiskModel


@dataclass
class EpisodeSummary:
    total_claims: int = 0
    total_fraud_claims: int = 0
    total_fraud_amount: float = 0.0
    total_leakage_amount: float = 0.0
    resolved_claims: int = 0
    resolved_fraud_claims: int = 0
    resolved_fraud_amount: float = 0.0
    resolved_legitimate_claims: int = 0
    unresolved_claims: int = 0
    unresolved_amount: float = 0.0
    unresolved_fraud_claims: int = 0
    unresolved_fraud_amount: float = 0.0
    cycle_times: list[float] = None  # type: ignore
    sla_violations: int = 0
    appeals: int = 0
    audit_count: int = 0
    false_alarms: int = 0
    fraud_caught: int = 0
    total_reward: float = 0.0
    daily_leakage_rates: list[float] = None  # type: ignore

    def __post_init__(self) -> None:
        if self.cycle_times is None:
            self.cycle_times = []
        if self.daily_leakage_rates is None:
            self.daily_leakage_rates = []

    def as_dict(self) -> dict:
        return {
            "total_claims": self.total_claims,
            "total_fraud_claims": self.total_fraud_claims,
            "total_fraud_amount": float(self.total_fraud_amount),
            "total_leakage_amount": float(self.total_leakage_amount),
            "metric_version": "R1-resolved-cohort-v1",
            "metric_cohort": "claims resolved by the episode horizon",
            "resolved_claims": self.resolved_claims,
            "resolved_fraud_claims": self.resolved_fraud_claims,
            "resolved_fraud_amount": self.resolved_fraud_amount,
            "resolved_legitimate_claims": self.resolved_legitimate_claims,
            "unresolved_claims": self.unresolved_claims,
            "unresolved_amount": self.unresolved_amount,
            "unresolved_fraud_claims": self.unresolved_fraud_claims,
            "unresolved_fraud_amount": self.unresolved_fraud_amount,
            "resolution_fraction": self.resolved_claims / max(1, self.total_claims),
            "fraud_value_resolution_fraction": self.resolved_fraud_amount / self.total_fraud_amount
            if self.total_fraud_amount > 0 else 0.0,
            "submitted_fraud_cohort_defined": self.total_fraud_amount > 0,
            "submitted_leakage_lower_bound": self.total_leakage_amount / self.total_fraud_amount
            if self.total_fraud_amount > 0 else 0.0,
            "submitted_leakage_upper_bound": (self.total_leakage_amount + self.unresolved_fraud_amount)
            / self.total_fraud_amount if self.total_fraud_amount > 0 else 0.0,
            "submitted_catch_lower_bound": self.fraud_caught / max(1, self.total_fraud_claims),
            "submitted_catch_upper_bound": (self.fraud_caught + self.unresolved_fraud_claims)
            / max(1, self.total_fraud_claims),
            "leakage_rate_defined": self.resolved_fraud_amount > 0,
            "fraud_catch_rate_defined": self.resolved_fraud_claims > 0,
            "false_alarm_rate_defined": self.resolved_legitimate_claims > 0,
            "leakage_rate": float(
                self.total_leakage_amount / self.resolved_fraud_amount
                if self.resolved_fraud_amount > 0
                else 0.0
            ),
            "mean_cycle_time": float(np.mean(self.cycle_times)) if self.cycle_times else 0.0,
            "sla_violation_rate": float(
                self.sla_violations / max(1, self.total_claims)
            ),
            "appeal_rate": float(self.appeals / max(1, self.total_claims)),
            "false_alarm_rate": float(self.false_alarms / max(1, self.resolved_legitimate_claims)),
            "fraud_catch_rate": float(self.fraud_caught / max(1, self.resolved_fraud_claims)),
            "audit_count": int(self.audit_count),
            "total_reward": float(self.total_reward),
            "daily_leakage_mean": float(np.mean(self.daily_leakage_rates))
            if self.daily_leakage_rates
            else 0.0,
            "daily_worst_5pct_mean": float(
                np.mean(np.sort(self.daily_leakage_rates)[-max(1, int(np.ceil(len(self.daily_leakage_rates) * 0.05))):])
            )
            if self.daily_leakage_rates
            else 0.0,
        }


class ReimburseSimEnv(gym.Env):
    """Discrete-time multi-agent reimbursement workflow simulator."""

    metadata = {"render_modes": ["human"]}

    def __init__(self, config: ScenarioConfig | None = None) -> None:
        super().__init__()
        self.config = deepcopy(config or ScenarioConfig())
        self.observation_space = spaces.Box(low=0.0, high=1.0, shape=(OBS_DIM,), dtype=np.float32)
        self.action_space = spaces.Box(low=0.0, high=1.0, shape=(6,), dtype=np.float32)

        self.day: int = 0
        self.next_claim_id: int = 0
        self.applicants: list[Applicant] = []
        self.reviewers: list[Reviewer] = []
        self.managers: list[Manager] = []
        self.departments: dict[int, Department] = {}
        self.claims: dict[int, Claim] = {}
        self.pending_claims: list[int] = []
        self.rolling_max_buffer: deque[float] = deque(maxlen=self.config.rolling_max_buffer_size)

        self.risk_model: RiskModel | None = None
        self.summary: EpisodeSummary = EpisodeSummary()
        self.daily_log: list[DailyMetrics] = []

        # 7-day rolling stats
        self._fa_window: deque[tuple[int, int]] = deque(maxlen=7)  # (false_alarms, audits)
        self._appeal_window: deque[tuple[int, int]] = deque(maxlen=7)
        self._leak_window: deque[tuple[float, float]] = deque(maxlen=7)
        self._sla_window: deque[tuple[int, int]] = deque(maxlen=7)
        self._split_window: deque[tuple[int, int]] = deque(maxlen=7)
        self._targeted_window: deque[tuple[int, int]] = deque(maxlen=7)
        self._targeted_today: tuple[int, int] | None = None

        self._rng: np.random.Generator | None = None
        self._unavailable_reviewers: set[int] = set()
        self._applied_stress_events: set[int] = set()
        self._submission_multiplier = 1.0
        self._burst_multiplier = 1.0
        self._active_stress_events: list[str] = []

    # ------------- Setup ------------------------------------------------

    def _build_population(self, rng: np.random.Generator) -> None:
        # Departments
        self.departments = {}
        for d in range(self.config.num_departments):
            self.departments[d] = Department(
                dept_id=d,
                budget_total=self.config.budget_per_dept,
                budget_remaining=self.config.budget_per_dept,
                headcount=max(1, self.config.num_applicants // self.config.num_departments),
                fraud_base_rate=0.05,
            )

        # Applicants
        types_list = list(self.config.applicant_mix.keys())
        probs = np.array(list(self.config.applicant_mix.values()))
        probs = probs / probs.sum()
        self.applicants = []
        for i in range(self.config.num_applicants):
            t = ApplicantType(types_list[int(rng.choice(len(types_list), p=probs))])
            dept = int(rng.integers(0, self.config.num_departments))
            self.applicants.append(
                Applicant(
                    applicant_id=i,
                    department=dept,
                    type=t,
                    submission_rate=self.config.claim_rate_per_applicant,
                    amount_log_mu=self.config.claim_amount_log_mu,
                    amount_log_sigma=self.config.claim_amount_log_sigma,
                    enable_adaptation=self.config.enable_social_adaptation,
                )
            )

        # Reviewers
        rtypes = list(self.config.reviewer_mix.keys())
        rprobs = np.array(list(self.config.reviewer_mix.values()))
        rprobs = rprobs / rprobs.sum()
        self.reviewers = []
        for i in range(self.config.num_reviewers):
            t = ReviewerType(rtypes[int(rng.choice(len(rtypes), p=rprobs))])
            self.reviewers.append(
                Reviewer.make(i, t, self.config.enable_social_adaptation)
            )

        # Managers
        self.managers = [
            Manager(manager_id=i, daily_capacity=30) for i in range(self.config.num_managers)
        ]

    # ------------- Gym interface ----------------------------------------

    def reset(self, *, seed: int | None = None, options: dict | None = None):  # noqa: ARG002
        if seed is None and self.config.random_seed is not None:
            seed = self.config.random_seed
        super().reset(seed=seed)
        self._rng = np.random.default_rng(seed)
        self.day = 0
        self.next_claim_id = 0
        self.claims = {}
        self.pending_claims = []
        self.rolling_max_buffer.clear()
        self.summary = EpisodeSummary()
        self.daily_log = []
        for w in (
            self._fa_window, self._appeal_window, self._leak_window,
            self._sla_window, self._split_window, self._targeted_window,
        ):
            w.clear()
        self._targeted_today = None
        self._unavailable_reviewers.clear()
        self._applied_stress_events.clear()
        self._submission_multiplier = 1.0
        self._burst_multiplier = 1.0
        self._active_stress_events = []
        self._build_population(self._rng)
        self.risk_model = RiskModel(self.departments)
        obs = self._make_obs(metrics_today=DailyMetrics(day=0))
        info = {"scenario": self.config.scenario_name}
        return obs.astype(np.float32), info

    def step(self, action):
        assert self._rng is not None and self.risk_model is not None
        if self.day >= self.config.episode_length:
            raise RuntimeError("Episode has ended; call reset before stepping again")
        rng = self._rng
        knobs = decode_action(action)

        # Apply policy shocks (override knobs if needed)
        shock_active = self._apply_stress_overrides(knobs)

        metrics = DailyMetrics(day=self.day, action=[float(x) for x in np.array(action).tolist()])

        # 1. Generate claims
        new_claim_ids: list[int] = []
        for a in self.applicants:
            new_claims = a.generate_claims(
                self.day, knobs, rng, self.next_claim_id,
                submission_multiplier=self._submission_multiplier,
                force_burst="fraud_burst" in self._active_stress_events,
                burst_multiplier=self._burst_multiplier,
            )
            for c in new_claims:
                self.claims[c.claim_id] = c
                self.pending_claims.append(c.claim_id)
                new_claim_ids.append(c.claim_id)
                metrics.claims_submitted += 1
                if c.is_fraudulent:
                    metrics.total_fraud_amount += c.amount
                self.next_claim_id += 1

        # 2. Risk scoring (only new ones)
        for cid in new_claim_ids:
            c = self.claims[cid]
            c.risk_score = self.risk_model.score(c, rng)

        # 3. Routing
        self._route_claims(knobs, rng, metrics)

        # 4. Reviewer processing
        self._reviewer_step(knobs, rng, metrics)

        # 5. Manager processing of escalations
        self._manager_step(knobs, rng, metrics)

        # 6. Appeals (rejected applicants may appeal)
        self._appeal_step(rng, metrics)

        # 7. SLA monitoring (claims still pending past hard limit count as violations)
        self._sla_step(metrics)

        # 8. Adaptation
        self._adaptation_step()

        # 9. Update windows
        self._update_windows(metrics)

        # 10. Update the rolling maximum leakage buffer (not a CVaR estimator).
        self.rolling_max_buffer.append(metrics.leakage_rate)

        # 11. Compute reward
        morale_index = self._compute_morale(metrics)
        reward, breakdown = compute_reward(
            metrics,
            self.config.reward_weights,
            list(self.rolling_max_buffer),
            morale_index,
            DEFAULT_POLICY["sla_days"],
        )

        # 12. Update episode summary
        self.summary.total_claims += metrics.claims_submitted
        self.summary.total_fraud_amount += metrics.total_fraud_amount
        self.summary.total_fraud_claims += sum(
            1 for cid in new_claim_ids if self.claims[cid].is_fraudulent
        )
        self.summary.total_leakage_amount += metrics.leakage_amount
        self.summary.resolved_claims += metrics.claims_resolved
        self.summary.resolved_fraud_claims += metrics.resolved_fraud_claims
        self.summary.resolved_fraud_amount += metrics.resolved_fraud_amount
        self.summary.resolved_legitimate_claims += metrics.resolved_legitimate_claims
        self.summary.cycle_times.extend(metrics.cycle_times)
        self.summary.sla_violations += metrics.sla_violations
        self.summary.appeals += metrics.appeals
        self.summary.audit_count += metrics.audit_count
        self.summary.false_alarms += metrics.false_alarms
        self.summary.fraud_caught += metrics.fraud_caught
        self.summary.total_reward += reward
        self.summary.daily_leakage_rates.append(metrics.leakage_rate)

        self.daily_log.append(metrics)

        # 13. Daily decay
        self.risk_model.daily_decay(day=self.day)

        self.day += 1
        terminated = self.day >= self.config.episode_length
        truncated = False
        info = {
            "day": self.day,
            "metrics": {
                "claims_submitted": metrics.claims_submitted,
                "claims_resolved": metrics.claims_resolved,
                "leakage_rate": metrics.leakage_rate,
                "audit_count": metrics.audit_count,
                "appeals": metrics.appeals,
                "sla_violations": metrics.sla_violations,
                "avg_cycle_time": metrics.avg_cycle_time,
            },
            "reward_breakdown": breakdown,
            "policy_shock_active": shock_active,
            "stress_state": {
                "events": list(self._active_stress_events),
                "submission_multiplier": self._submission_multiplier,
                "burst_multiplier": self._burst_multiplier,
                "active_reviewers": len(self.reviewers) - len(self._unavailable_reviewers),
                "effective_knobs": dict(knobs),
            },
        }
        if terminated:
            unresolved = [c for c in self.claims.values()
                          if c.status not in (ClaimStatus.APPROVED, ClaimStatus.REJECTED)]
            self.summary.unresolved_claims = len(unresolved)
            self.summary.unresolved_amount = sum(c.amount for c in unresolved)
            self.summary.unresolved_fraud_claims = sum(c.is_fraudulent for c in unresolved)
            self.summary.unresolved_fraud_amount = sum(c.amount for c in unresolved if c.is_fraudulent)
            info["episode_summary"] = self.summary.as_dict()

        obs = self._make_obs(metrics_today=metrics, shock_active=shock_active)
        return obs.astype(np.float32), float(reward), terminated, truncated, info

    # ------------- Routing & processing ---------------------------------

    def _route_claims(
        self, knobs: dict[str, float], rng: np.random.Generator, metrics: DailyMetrics
    ) -> None:
        """Decide for each pending claim: auto-approve / audit / send to reviewer."""
        targeted_threshold = 0.5  # claims with risk * weight > this go to audit
        active_indices = [i for i in range(len(self.reviewers))
                          if i not in self._unavailable_reviewers]
        temp = max(0.05, knobs["reviewer_load_temperature"])

        # Use list copy because we mutate pending_claims
        for cid in list(self.pending_claims):
            c = self.claims[cid]
            if c.status != ClaimStatus.PENDING:
                continue

            # Auto-approve path: low risk + small amount + auto_prob roll
            if (
                c.risk_score < knobs["risk_threshold"]
                and c.amount <= DEFAULT_POLICY["auto_approve_ceiling"] * 2
                and rng.random() < knobs["auto_approval_prob"]
            ):
                self._resolve_claim(c, approved=True, metrics=metrics, by="auto")
                self.pending_claims.remove(cid)
                continue

            # Random audit
            if rng.random() < knobs["random_audit_ratio"] and self._audit_capacity_available(metrics):
                self._audit_claim(c, knobs, rng, metrics)
                self.pending_claims.remove(cid)
                continue

            # Targeted audit
            if (c.risk_score * knobs["targeted_audit_weight"] > targeted_threshold
                    and self._audit_capacity_available(metrics)):
                self._audit_claim(c, knobs, rng, metrics, targeted=True)
                self.pending_claims.remove(cid)
                continue

            # Assign to reviewer (recompute load each time so heavy assignments
            # don't all collapse onto the same reviewer)
            cur_loads = np.array([self.reviewers[i].current_load for i in active_indices], dtype=np.float32)
            cur_logits = -cur_loads / temp
            cur_ex = np.exp(cur_logits - np.max(cur_logits))
            cur_probs = cur_ex / cur_ex.sum()
            r_idx = active_indices[int(rng.choice(len(active_indices), p=cur_probs))]
            self.reviewers[r_idx].queue.append(cid)
            c.assigned_reviewer = r_idx
            c.status = ClaimStatus.UNDER_REVIEW
            c.enqueue_day = self.day
            self.pending_claims.remove(cid)

    def _audit_capacity_available(self, metrics: DailyMetrics) -> bool:
        cap = self.config.audit_cap_per_day
        return cap is None or metrics.audit_count < cap

    def _audit_claim(
        self,
        c: Claim,
        knobs: dict[str, float],
        rng: np.random.Generator,
        metrics: DailyMetrics,
        targeted: bool = False,
    ) -> None:
        """Audit detects fraud with high accuracy (0.92)."""
        c.audit_selected = True
        metrics.audit_count += 1
        if targeted:
            self._targeted_window_increment(hit=c.is_fraudulent)
        # Audit accuracy
        if rng.random() < 0.92:
            if c.is_fraudulent:
                self._resolve_claim(c, approved=False, metrics=metrics, by="audit-correct")
            else:
                self._resolve_claim(c, approved=True, metrics=metrics, by="audit-pass")
        else:
            # mistake
            if c.is_fraudulent:
                self._resolve_claim(c, approved=True, metrics=metrics, by="audit-miss")
            else:
                self._resolve_claim(c, approved=False, metrics=metrics, by="audit-fa")

    def _reviewer_step(
        self, knobs: dict[str, float], rng: np.random.Generator, metrics: DailyMetrics
    ) -> None:
        for r in self.reviewers:
            if r.reviewer_id in self._unavailable_reviewers:
                continue
            today_quota = r.effective_speed
            processed = 0
            # Process FIFO but skip claims enqueued today (1-day minimum delay so
            # cycle_time can vary above 1)
            new_queue: list[int] = []
            while r.queue and processed < today_quota:
                cid = r.queue.pop(0)
                c = self.claims[cid]
                if c.status != ClaimStatus.UNDER_REVIEW:
                    continue
                if c.enqueue_day is not None and c.enqueue_day >= self.day:
                    new_queue.append(cid)
                    continue
                outcome = r.process_claim(c, knobs, rng, self.day)
                if outcome == "escalate":
                    c.status = ClaimStatus.ESCALATED
                    c.escalate_day = self.day
                    # Round-robin escalation to managers
                    m_idx = (cid % len(self.managers)) if self.managers else 0
                    if self.managers:
                        self.managers[m_idx].escalation_queue.append(cid)
                else:
                    approved = (outcome == "approve")
                    if approved and c.is_fraudulent:
                        r.recent_fraud_caught = max(0, r.recent_fraud_caught - 1)
                    if (not approved) and c.is_fraudulent:
                        r.recent_fraud_caught += 1
                    # Track reviewer's decision for manager-feedback computation later
                    r._last_decisions.append((cid, approved))  # type: ignore[attr-defined]
                    self._resolve_claim(c, approved=approved, metrics=metrics, by="reviewer")
                processed += 1
            # Re-queue claims that were skipped (enqueued today)
            r.queue = new_queue + r.queue

    def _manager_step(
        self, knobs: dict[str, float], rng: np.random.Generator, metrics: DailyMetrics
    ) -> None:
        for m in self.managers:
            quota = m.daily_capacity
            processed = 0
            new_q: list[int] = []
            while m.escalation_queue and processed < quota:
                cid = m.escalation_queue.pop(0)
                c = self.claims[cid]
                if c.status != ClaimStatus.ESCALATED:
                    continue
                # 1-day delay before manager processes, so escalations add cycle time
                if c.escalate_day is not None and c.escalate_day >= self.day:
                    new_q.append(cid)
                    continue
                # Manager accuracy degraded by pressure
                eff_quality = max(0.5, m.approval_quality - 0.1 * m.pressure_level)
                if rng.random() < eff_quality:
                    approved = not c.is_fraudulent
                else:
                    approved = c.is_fraudulent  # mistake
                # Manager-feedback signal back to assigned reviewer (was reviewer right?)
                if c.assigned_reviewer is not None:
                    r = self.reviewers[c.assigned_reviewer]
                    # The reviewer's escalation decision was correct iff manager's
                    # final outcome differs from a naive auto-approve (i.e. real risk)
                    correct = (not approved) == c.is_fraudulent
                    r._manager_feedback_buf.append(1.0 if correct else -1.0)  # type: ignore[attr-defined]
                self._resolve_claim(c, approved=approved, metrics=metrics, by="manager")
                processed += 1
            m.escalation_queue = new_q + m.escalation_queue

        # Update manager pressure based on backlog
        for m in self.managers:
            backlog = len(m.escalation_queue)
            m.pressure_level = float(np.clip(backlog / max(1, m.daily_capacity * 2), 0.0, 1.0))

    def _appeal_step(self, rng: np.random.Generator, metrics: DailyMetrics) -> None:
        # Recently rejected applicants may appeal: simple model: 5% baseline
        # We scan claims resolved today to keep cost bounded
        recent_rejected = [
            c for c in self.claims.values()
            if c.status == ClaimStatus.REJECTED and c.resolution_day == self.day and not c.appealed
        ]
        for c in recent_rejected:
            base = 0.05
            # Honest applicants whose claim was a false alarm appeal more
            if not c.is_fraudulent:
                base = 0.30
            if rng.random() < base:
                c.appealed = True
                metrics.appeals += 1

    def _sla_step(self, metrics: DailyMetrics) -> None:
        # Count first-time SLA breaches for unresolved claims; flag prevents
        # double counting in _resolve_claim later.
        for c in self.claims.values():
            if c.sla_breach_recorded:
                continue
            if c.status in (ClaimStatus.PENDING, ClaimStatus.UNDER_REVIEW, ClaimStatus.ESCALATED):
                age = self.day - c.submit_day
                if age >= DEFAULT_POLICY["sla_hard_limit"]:
                    metrics.sla_violations += 1
                    c.sla_breach_recorded = True

    def _resolve_claim(
        self, c: Claim, approved: bool, metrics: DailyMetrics, by: str
    ) -> None:
        c.status = ClaimStatus.APPROVED if approved else ClaimStatus.REJECTED
        c.resolution_day = self.day
        cycle = self.day - c.submit_day + 1
        metrics.cycle_times.append(float(cycle))
        # Single source of truth for SLA: only record if not already flagged in _sla_step
        if cycle > DEFAULT_POLICY["sla_hard_limit"] and not c.sla_breach_recorded:
            metrics.sla_violations += 1
            c.sla_breach_recorded = True
        metrics.claims_resolved += 1
        # Track resolved cohort's fraud accounting (cohort-correct denominator
        # for daily leakage_rate)
        if c.is_fraudulent:
            metrics.resolved_fraud_amount += c.amount
            metrics.resolved_fraud_claims += 1
        else:
            metrics.resolved_legitimate_claims += 1
            if not approved:
                metrics.false_alarms += 1
        if approved:
            # Budget impact
            dept = self.departments.get(c.department)
            if dept:
                dept.budget_remaining = max(0.0, dept.budget_remaining - c.amount)
            metrics.approved_amount += c.amount
            if c.is_fraudulent:
                metrics.fraud_missed += 1
                metrics.leakage_amount += c.amount
        else:
            if c.is_fraudulent:
                metrics.fraud_caught += 1
            self.risk_model.record_outcome(c, was_rejected=True, day=self.day)
        # Notify applicant
        applicant = self.applicants[c.applicant_id]
        applicant.update_outcome(c)

    # ------------- Adaptation -------------------------------------------

    def _adaptation_step(self) -> None:
        # Compute aggregate audit intensity signal
        recent_audits = sum(m.audit_count for m in self.daily_log[-3:]) if self.daily_log else 0
        recent_claims = sum(m.claims_submitted for m in self.daily_log[-3:]) if self.daily_log else 0
        global_audit = recent_audits / max(1, recent_claims)

        # Max approved amount among recent honest approvals (proxy threshold)
        recent_approved = [
            c.amount for c in self.claims.values()
            if c.status == ClaimStatus.APPROVED
            and c.resolution_day is not None
            and c.resolution_day >= max(0, self.day - 5)
        ]
        max_amt = max(recent_approved) if recent_approved else 0.0

        for a in self.applicants:
            a.adapt(self.day, global_audit, max_amt)

        # Reviewer adaptation: pass None so daily_update consumes the
        # _manager_feedback_buf populated by _manager_step
        for r in self.reviewers:
            if r.reviewer_id in self._unavailable_reviewers:
                continue
            r.daily_update(manager_feedback=None, day=self.day)

    # ------------- Stress / shock ---------------------------------------

    def _apply_stress_overrides(self, knobs: dict[str, float]) -> bool:
        """Apply isolated interventions on zero-based half-open day intervals."""
        shock_active = False
        self._submission_multiplier = 1.0
        self._burst_multiplier = 1.0
        self._unavailable_reviewers = set()
        self._active_stress_events = []
        for event_id, ev in enumerate(self.config.stress_events):
            start = ev.trigger_day
            end = start + ev.duration
            if start <= self.day < end:
                self._active_stress_events.append(ev.type)
                if ev.type == "policy_shock":
                    knobs["random_audit_ratio"] = max(
                        knobs["random_audit_ratio"],
                        ev.params.get("min_audit_ratio", 0.30),
                    )
                    if event_id not in self._applied_stress_events:
                        for a in self.applicants:
                            a.perceived_audit_intensity = ev.params.get("perceived_intensity", 0.8)
                    shock_active = True
                elif ev.type == "fraud_burst":
                    self._burst_multiplier *= ev.params.get("burst_multiplier", 5.0)
                elif ev.type == "month_end_surge":
                    self._submission_multiplier *= ev.params.get("surge_multiplier", 3.0)
                elif ev.type == "reviewer_shortage":
                    count = int(np.floor(len(self.reviewers) * ev.params.get("unavailable_fraction", 0.4)))
                    count = max(1, min(len(self.reviewers) - 1, count))
                    self._unavailable_reviewers.update(range(count))
                elif ev.type == "budget_shock" and event_id not in self._applied_stress_events:
                    dept = self.departments[int(ev.params.get("department_id", 0))]
                    dept.budget_remaining *= ev.params.get("remaining_fraction", 0.05)
                self._applied_stress_events.add(event_id)
        return shock_active

    # ------------- Window updates ---------------------------------------

    def _targeted_window_increment(self, hit: bool) -> None:
        # Accumulate in today's bucket (created at start of step)
        if self._targeted_today is None:
            self._targeted_today = (0, 0)
        h, t = self._targeted_today
        self._targeted_today = (h + (1 if hit else 0), t + 1)

    def _update_windows(self, m: DailyMetrics) -> None:
        self._fa_window.append((m.false_alarms, m.resolved_legitimate_claims))
        self._appeal_window.append((m.appeals, m.claims_resolved))
        # leakage uses the cohort-correct (resolved) denominator
        self._leak_window.append((m.leakage_amount, m.resolved_fraud_amount))
        self._sla_window.append((m.sla_violations, max(1, m.claims_resolved)))
        # Push today's targeted bucket
        if self._targeted_today is not None:
            self._targeted_window.append(self._targeted_today)
            self._targeted_today = None
        # split-rate counted from new claims today
        split_today = sum(
            1 for cid in [k for k, v in self.claims.items() if v.submit_day == self.day]
            if self.claims[cid].is_split
        )
        self._split_window.append((split_today, max(1, m.claims_submitted)))

    def _rolling_rate(self, window: deque) -> float:
        if not window:
            return 0.0
        num = sum(x[0] for x in window)
        den = sum(x[1] for x in window)
        return float(num / den) if den > 0 else 0.0

    def _compute_morale(self, m: DailyMetrics) -> float:
        overload_frac = float(np.mean([1.0 if r.utilization > 0.8 else 0.0 for r in self.reviewers])) if self.reviewers else 0.0
        fa = m.false_alarms / max(1, m.resolved_legitimate_claims)
        appeal = m.appeals / max(1, m.claims_resolved)
        return float(np.clip(0.3 * overload_frac + 0.3 * fa + 0.4 * appeal, 0.0, 1.0))

    # ------------- Observation ------------------------------------------

    def _make_obs(self, metrics_today: DailyMetrics, shock_active: bool = False) -> np.ndarray:
        # Recent audit ratio (today only, simple)
        denom = max(1, metrics_today.claims_submitted)
        cur_audit = metrics_today.audit_count / denom

        repeat_offender = 0
        if self.applicants:
            repeat_offender = float(
                np.mean([
                    1.0 if a.consecutive_rejections >= 2 else 0.0 for a in self.applicants
                ])
            )

        # Pending claims as Claim objects (only PENDING/UNDER_REVIEW)
        pending = [
            self.claims[cid]
            for cid in self.claims
            if self.claims[cid].status
            in (ClaimStatus.PENDING, ClaimStatus.UNDER_REVIEW, ClaimStatus.ESCALATED)
        ]

        # monthly spend velocity: approved amount over last 7 days vs
        # expected per-week budget allocation
        recent_approved = sum(m.approved_amount for m in self.daily_log[-7:]) if self.daily_log else 0.0
        weekly_budget = (
            sum(d.budget_total for d in self.departments.values())
            * 7.0
            / max(1, self.config.episode_length)
        )
        msv = float(np.clip(recent_approved / max(1.0, weekly_budget), 0.0, 1.0))

        state = {
            "day": self.day,
            "pending_claims": pending,
            "max_queue_size": max(200, self.config.num_applicants),
            "sla_hard_limit": DEFAULT_POLICY["sla_hard_limit"],
            "reviewers": [r for r in self.reviewers if r.reviewer_id not in self._unavailable_reviewers],
            "managers": self.managers,
            "max_escalation": 50,
            "departments": self.departments,
            "monthly_spend_velocity": msv,
            "repeat_offender_ratio": repeat_offender,
            "current_audit_ratio": cur_audit,
            "targeted_hit_rate_7d": self._rolling_rate(self._targeted_window),
            "false_alarm_rate_7d": self._rolling_rate(self._fa_window),
            "applicants": self.applicants,
            "split_rate_7d": self._rolling_rate(self._split_window),
            "appeal_rate_7d": self._rolling_rate(self._appeal_window),
            "leakage_rate_7d": self._rolling_rate(self._leak_window),
            "sla_violation_rate_7d": self._rolling_rate(self._sla_window),
            "policy_shock_active": shock_active,
        }
        return build_observation(state, list(self.rolling_max_buffer))

    # ------------- Render -----------------------------------------------

    def render(self) -> None:
        if not self.daily_log:
            return
        m = self.daily_log[-1]
        print(
            f"day={self.day} | submit={m.claims_submitted} resolved={m.claims_resolved} "
            f"audit={m.audit_count} fraud_caught={m.fraud_caught} fraud_missed={m.fraud_missed} "
            f"leak_rate={m.leakage_rate:.3f} cycle={m.avg_cycle_time:.2f}"
        )
