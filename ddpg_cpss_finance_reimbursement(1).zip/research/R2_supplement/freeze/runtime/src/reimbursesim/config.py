"""Scenario configuration loader for ReimburseSim-CPSS."""

from __future__ import annotations

from dataclasses import dataclass, field
import math
from pathlib import Path
from typing import Any

import yaml


@dataclass
class StressEvent:
    type: str
    trigger_day: int
    duration: int
    params: dict[str, Any] = field(default_factory=dict)


@dataclass
class ScenarioConfig:
    scenario_name: str = "default_quarter"
    episode_length: int = 60
    num_departments: int = 5
    num_applicants: int = 200
    num_reviewers: int = 10
    num_managers: int = 2

    applicant_mix: dict[str, float] = field(
        default_factory=lambda: {
            "honest": 0.60,
            "careless": 0.15,
            "strategic_prober": 0.10,
            "opportunistic_splitter": 0.10,
            "fraudulent_burst": 0.05,
        }
    )
    reviewer_mix: dict[str, float] = field(
        default_factory=lambda: {
            "diligent": 0.40,
            "rubber_stamper": 0.20,
            "risk_averse_escalator": 0.25,
            "adaptive": 0.15,
        }
    )

    budget_per_dept: float = 500_000.0
    claim_rate_per_applicant: float = 0.3
    claim_amount_log_mu: float = 6.0
    claim_amount_log_sigma: float = 0.8
    audit_cap_per_day: int | None = None

    stress_events: list[StressEvent] = field(default_factory=list)

    reward_weights: dict[str, float] = field(
        default_factory=lambda: {
            "w_leak": 1.0,
            "w_cost": 0.3,
            "w_cycle": 0.5,
            "w_fa": 0.2,
            "w_appeal": 0.4,
            "w_morale": 0.2,
            "w_rolling_max": 0.8,
            "w_throughput": 0.3,
        }
    )

    # Adaptation switch for ablation (M0=False sanity, M3=True killer test)
    enable_social_adaptation: bool = True
    rolling_max_buffer_size: int = 20

    random_seed: int | None = None

    def __post_init__(self) -> None:
        if not math.isfinite(self.claim_amount_log_mu) or not math.isfinite(self.claim_amount_log_sigma) or self.claim_amount_log_sigma <= 0:
            raise ValueError("Claim lognormal parameters must be finite with positive sigma")
        if self.audit_cap_per_day is not None and (
            not isinstance(self.audit_cap_per_day, int) or self.audit_cap_per_day < 0
        ):
            raise ValueError("Daily audit cap must be a nonnegative integer or None")
        if min(self.episode_length, self.num_departments, self.num_applicants,
               self.num_reviewers, self.num_managers, self.rolling_max_buffer_size) < 1:
            raise ValueError("Population sizes, episode length and buffer size must be positive")
        if not math.isfinite(self.claim_rate_per_applicant) or self.claim_rate_per_applicant < 0:
            raise ValueError("Claim rate must be finite and nonnegative")
        if not math.isfinite(self.budget_per_dept) or self.budget_per_dept <= 0:
            raise ValueError("Budget must be finite and positive")
        # Validate mixes sum to ~1
        for name, mix in [("applicant_mix", self.applicant_mix), ("reviewer_mix", self.reviewer_mix)]:
            total = sum(mix.values())
            if any(not math.isfinite(v) or v < 0 for v in mix.values()) or abs(total - 1.0) > 1e-3:
                raise ValueError(f"{name} sums to {total}, expected 1.0")

        # Convert stress_events dicts to dataclasses
        self.stress_events = [
            ev if isinstance(ev, StressEvent) else StressEvent(**ev)
            for ev in self.stress_events
        ]
        allowed = {"fraud_burst": {"burst_multiplier"},
                   "month_end_surge": {"surge_multiplier"},
                   "reviewer_shortage": {"unavailable_fraction"},
                   "policy_shock": {"min_audit_ratio", "perceived_intensity"},
                   "budget_shock": {"department_id", "remaining_fraction"}}
        for ev in self.stress_events:
            if ev.type not in allowed or set(ev.params) - allowed[ev.type]:
                raise ValueError(f"Unsupported stress event or parameter: {ev}")
            if ev.trigger_day < 0 or ev.duration < 1 or ev.trigger_day + ev.duration > self.episode_length:
                raise ValueError("Stress intervals must lie within the episode (zero-based days)")
            if ev.type == "reviewer_shortage" and self.num_reviewers < 2:
                raise ValueError("A shortage event requires at least two reviewers")
            for key, value in ev.params.items():
                if not math.isfinite(value):
                    raise ValueError(f"Non-finite event parameter: {key}")
                if key.endswith("multiplier") and value < 1:
                    raise ValueError("Stress multipliers must be at least one")
                if key in {"remaining_fraction", "perceived_intensity"} and not 0 <= value <= 1:
                    raise ValueError(f"{key} must be in [0, 1]")
                if key == "min_audit_ratio" and not 0.05 <= value <= 0.5:
                    raise ValueError("Audit floor must lie within the action range")
                if key == "unavailable_fraction" and not 0 < value < 1:
                    raise ValueError("Shortage fraction must be between zero and one")
                if key == "department_id" and (int(value) != value or not 0 <= value < self.num_departments):
                    raise ValueError("Invalid shock department")


def load_scenario(path: str | Path) -> ScenarioConfig:
    """Load scenario YAML into ScenarioConfig."""
    path = Path(path)
    def read(current: Path, ancestors: set[Path]) -> dict:
        current = current.resolve()
        if current in ancestors:
            raise ValueError("Cyclic scenario inheritance")
        with current.open("r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
        if not isinstance(data, dict):
            raise ValueError("Scenario must be a mapping")
        parent = data.pop("extends", None)
        if parent:
            base = read(current.parent / parent, ancestors | {current})
            base.update(data)
            return base
        return data

    data = read(path, set())
    # Convert nested stress events
    if "stress_events" in data and data["stress_events"]:
        data["stress_events"] = [StressEvent(**ev) for ev in data["stress_events"]]
    return ScenarioConfig(**data)
