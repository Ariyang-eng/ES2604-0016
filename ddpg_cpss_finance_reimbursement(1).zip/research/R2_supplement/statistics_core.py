"""Crossed cluster bootstrap: training seeds are repetitions, not episodes."""
import numpy as np

def checked(a):
    a=np.asarray(a,dtype=float)
    if a.ndim!=2 or a.shape[0] not in [1,5] or a.shape[1]!=100 or not np.isfinite(a).all():raise ValueError('Require one rule or five trainings, each100 finite matched rollouts')
    return a

def tail(a):return np.sort(a,axis=1)[:,-5:].mean(axis=1)

def validate_draws(draws):
    if isinstance(draws,bool) or not isinstance(draws,(int,np.integer)) or draws<100:raise ValueError('At least100 integer bootstrap draws required')

def aligned(rows,metric,training_ids,evaluation_ids):
    """Build explicit seed-keyed matrices; row input order cannot alter pairing."""
    values={}
    for r in rows:
        k=(r['train_seed'],r['eval_seed'])
        if k in values:raise ValueError('Duplicate seed pair')
        values[k]=r[metric]
    expected={(t,e) for t in training_ids for e in evaluation_ids}
    if set(values)!=expected:raise ValueError('Missing or unexpected seed pair')
    return checked([[values[t,e] for e in evaluation_ids] for t in training_ids])

def aggregate(a,draws=5000,seed=7315,tail_metric=False):
    validate_draws(draws);a=checked(a);rng=np.random.default_rng(seed);values=[]
    statistic=lambda x:tail(x).mean() if tail_metric else x.mean()
    for _ in range(draws):
        t=rng.integers(a.shape[0],size=a.shape[0]);e=rng.integers(100,size=100)
        values.append(statistic(a[np.ix_(t,e)]))
    ms=tail(a) if tail_metric else a.mean(axis=1)
    return {'mean':float(statistic(a)),'training_seed_std':float(ms.std(ddof=1)) if len(ms)>1 else None,'pooled_episode_sd':float(a.std(ddof=1)),
            'within_model_episode_sd_mean':float(a.std(axis=1,ddof=1).mean()),
            'ci95':np.quantile(values,[.025,.975]).tolist(),'training_seeds':a.shape[0] if a.shape[0]>1 else 0,'rollouts':int(a.size),'seed_means':ms.tolist()}

def paired(a,b,draws=5000,seed=7315,independent_training=False,tail_metric=False):
    validate_draws(draws);a,b=checked(a),checked(b);rng=np.random.default_rng(seed);values=[]
    statistic=lambda x:tail(x).mean() if tail_metric else x.mean()
    for _ in range(draws):
        e=rng.integers(100,size=100)
        if independent_training:
            ta=rng.integers(a.shape[0],size=a.shape[0]);tb=rng.integers(b.shape[0],size=b.shape[0])
        else:
            common=rng.integers(5,size=5);ta=common if a.shape[0]==5 else np.zeros(5,dtype=int);tb=common if b.shape[0]==5 else np.zeros(5,dtype=int)
        values.append(statistic(a[np.ix_(ta,e)])-statistic(b[np.ix_(tb,e)]))
    am=tail(a) if tail_metric else a.mean(axis=1);bm=tail(b) if tail_metric else b.mean(axis=1)
    result={'delta':float(statistic(a)-statistic(b)),'ci95':np.quantile(values,[.025,.975]).tolist(),
            'left_seed_means':am.tolist(),'right_seed_means':bm.tolist(),'left_training_repetitions':a.shape[0] if a.shape[0]>1 else 0,'right_training_repetitions':b.shape[0] if b.shape[0]>1 else 0,
            'method':'independent training-seed bootstrap with shared rollout resampling' if independent_training else 'paired training-index and shared rollout crossed bootstrap',
            'tail_samples_per_model':5 if tail_metric else None,'draws':draws,'rng_seed':seed,'unadjusted_exploratory':True}
    if not independent_training:result['seed_deltas']=(am-bm).tolist()
    return result
