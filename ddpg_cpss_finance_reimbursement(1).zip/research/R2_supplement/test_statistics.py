import unittest
import numpy as np
from statistics_core import checked,aggregate,paired,tail,aligned
class Statistics(unittest.TestCase):
    def test_no_pseudoreplication(self):
        r=aggregate(np.repeat(np.arange(5.)[:,None],100,axis=1),1000)
        self.assertEqual(r['training_seeds'],5);self.assertEqual(r['rollouts'],500);self.assertGreater(r['ci95'][1]-r['ci95'][0],1)
    def test_shared_pair_cancellation(self):
        a=np.arange(500.).reshape(5,100)
        r=paired(a,a-2,1000);np.testing.assert_allclose(r['ci95'],[2,2])
    def test_rule_not_five_trainings(self):
        r=paired(np.ones((5,100)),np.zeros((1,100)),1000)
        self.assertEqual(r['right_training_repetitions'],0);np.testing.assert_allclose(r['ci95'],[1,1])
    def test_tail_is_per_model_largest_five(self):
        a=np.tile(np.arange(100.),(5,1));np.testing.assert_array_equal(tail(a),[97]*5)
    def test_missing_and_wrong_seed_counts_rejected(self):
        for a in [np.zeros((4,100)),np.zeros((5,99)),np.full((5,100),np.nan)]:
            with self.assertRaises(ValueError):checked(a)
    def test_independent_seed_sensitivity_nonzero(self):
        a=np.repeat(np.arange(5.)[:,None],100,axis=1)
        p=paired(a,a,1000);u=paired(a,a,1000,independent_training=True)
        self.assertEqual(p['ci95'],[0,0]);self.assertGreater(u['ci95'][1],0)
        self.assertNotIn('seed_deltas',u)
    def test_explicit_seed_alignment(self):
        rows=[{'train_seed':t,'eval_seed':e,'x':t*100+e} for t in range(5) for e in range(200,300)]
        a=aligned(rows,'x',list(range(5)),list(range(200,300)))
        np.random.default_rng(1).shuffle(rows);np.testing.assert_array_equal(a,aligned(rows,'x',list(range(5)),list(range(200,300))))
        with self.assertRaises(ValueError):aligned(rows[:-1],'x',list(range(5)),list(range(200,300)))
        with self.assertRaises(ValueError):aligned(rows+[rows[0]],'x',list(range(5)),list(range(200,300)))
    def test_nonconstant_rule_uncertainty(self):
        a=np.repeat(np.arange(5.)[:,None],100,axis=1);b=np.arange(100.)[None,:]
        r=paired(a,b,1000);self.assertLess(r['ci95'][0],r['delta']);self.assertGreater(r['ci95'][1],r['delta'])
    def test_tail_ties_and_outlier(self):
        a=np.ones((5,100));self.assertTrue(np.all(tail(a)==1));a[0,0]=101;self.assertEqual(tail(a)[0],21)
    def test_invalid_draws(self):
        for d in [0,-1,10.5,True]:
            with self.assertRaises(ValueError):aggregate(np.zeros((5,100)),d)
if __name__=='__main__':unittest.main(verbosity=2)
