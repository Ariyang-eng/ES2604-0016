# ReimburseSim CPSS

ReimburseSim CPSS is a Gymnasium-compatible simulator for reinforcement learning in enterprise reimbursement control. This package contains the source and synthetic experimental results for the R2 research snapshot.

Repository: https://github.com/Ariyang-eng/ES2604-0016

## Package Layout

| Directory | Contents |
| --- | --- |
| `research/R2_supplement/freeze/runtime/` | Simulator, configurations, training and evaluation programs, rules, and tests |
| `research/R2_supplement/` | Capacity-constrained training, sensitivity evaluation, results, curves, and statistical scripts |
| `results/primary/` | 184,000 synthetic episode summaries and operating-point, tail, and checkpoint reports |
| `results/verification/` | 180 fixed-policy validation episodes and resource, ablation, and training-seed summaries |
| `environments/` | Recorded CPU and CUDA dependencies |

Model weights and checkpoints are distributed separately, if authorized. They are not needed for the CSV-based statistical analyses. This package does not contain real employee reimbursement records.

## Installation

Use Python 3.10 or later in a virtual environment. On Windows, use a short project path to avoid path-length errors.

```bash
python -m pip install --index-url https://download.pytorch.org/whl/cpu torch==2.5.1+cpu
python -m pip install -r requirements-cpu.txt -r requirements-analysis.txt
python -m pip install --no-deps -e research/R2_supplement/freeze/runtime
```

The original experiments used separate CPU and CUDA environments. Their results should be analyzed separately; changing the inference device may change policy decisions.

See [REPRODUCTION.md](REPRODUCTION.md) for tests, statistical analyses, and training commands, and [DATA_PROVENANCE.md](DATA_PROVENANCE.md) for source and data provenance. `SHA256SUMS.csv` records payload sizes and checksums.

## Release Status and Licensing

This is a local research snapshot pending publication to the repository above. Software and result licensing must be confirmed by the copyright holders before public distribution.
