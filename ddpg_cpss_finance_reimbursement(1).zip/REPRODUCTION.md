# Reproduction

The package supports source-based training and analysis of the supplied results. Repeating saved-model evaluations additionally requires weights, which are not included. The commands below distinguish these workflows.

## Tests

From `research/R2_supplement/freeze/runtime`:

```bash
python -m pytest tests analysis/tests -v -ra
```

From `research/R2_supplement`:

```bash
python -m unittest test_contract test_statistics -v
```

## Statistical Analysis

From `research/R2_supplement`:

```bash
python recompute_summaries.py --input CAP5_EVALUATION_RESULTS.csv --reference CAP5_POLICY_SUMMARY.csv --output reproduced_cap5.csv
python recompute_summaries.py --input R2_SENSITIVITY_RESULTS.csv --reference R2_SENSITIVITY_SUMMARY.csv --output reproduced_sensitivity.csv
python plot_results.py
```

Choose a new output filename for each run. The `--reference` argument selects the recorded random streams for the 5,000 bootstrap draws. Evaluation episodes and independent training seeds remain separate sampling units.

## Training

Training is optional and computationally intensive. It is not required to analyze the supplied result files.

From `research/R2_supplement/freeze/runtime`, an original uncapped training run is:

```bash
python scripts/r1/train.py --variant SAC-Full --seed 0 --timesteps 500000
```

Supported variants are DQN, PPO, DDPG, TD3, SAC-Full, SAC-NoRisk, SAC-NoSocial, and PPO-Quantized. The original comparison uses training seeds 0 through 4.

From `research/R2_supplement`, the separate cap-5 training runs are:

```bash
python worker.py --variant SAC-Full --seed 0 --steps 500000
python worker.py --variant PPO --seed 0 --steps 500000
python worker.py --variant DQN --seed 0 --steps 500000
```

Run each algorithm with seeds 0 through 4 to reproduce the 15-model design. Existing output directories are not overwritten. PPO completes 500,224 steps; SAC-Full and DQN complete 500,000.

Each final model is evaluated on the same 100 seeds, 200 through 299. The capacity comparison contains 1,500 new model-episode evaluations, 1,500 reused transfer-control evaluations, and 100 rule evaluations. Audit counts are dedicated audits per episode, not monetary costs or total review labor.

## Rule Selection

`research/R2_supplement/freeze/runtime/analysis/rules.py` evaluates 108 candidate control vectors using validation seeds 100 through 104. Held-out evaluation uses seeds 200 through 299. Use `--help` for rule-family, capacity, and output options. Test seeds must not be used for rule selection.

## Parameter Sensitivity

Restore the authorized original uncapped-trained models and selected rule inputs, then set `R2_BASELINE_ROOT` to their root directory. From `research/R2_supplement`:

```bash
python sensitivity_portable.py --variant SAC-Full --seed 0 --profile mix_low --device cuda
```

The complete design has seven profiles, four learned families with five models each, and one selected rule: 147 jobs, each with the same 100 evaluation seeds, 2000 through 2099. It uses the original uncapped-trained models, not the 15 additional cap-trained models. Learned-policy inference uses the separate CUDA environment.

## Scope

Complete historical validators require additional model and archive inputs. The supplied compact results support statistical reanalysis; they do not replace those inputs for end-to-end inference. The simulator uses stylized parameters and has not been externally calibrated to a particular enterprise. Shared audit capacity does not establish equal total labor cost, and finite training curves do not prove asymptotic convergence.
